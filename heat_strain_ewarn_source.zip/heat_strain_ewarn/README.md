# Guarded Adaptive Physiological Baselines for Occupational Heat-Strain Early Warning

[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![Tests Passing](https://img.shields.io/badge/tests-54%20passed-brightgreen.svg)]()
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![IEEE JBHI](https://img.shields.io/badge/Journal-IEEE%20JBHI%202026-red.svg)]()

> **Research Boundary & Safety Notice**: This software is an algorithmic research prototype designed to study baseline adaptation and contamination resistance within a controlled simulation environment. It makes **no clinical or medical claims**, detects statistical anomaly states in synthetic and laboratory models, and does **not** diagnose heat exhaustion, heatstroke, or estimate core body temperature.

---

## 1. Overview & Research Contributions

**Authors:** Chinnarapareddygari Monish Reddy, Kakkerla Vignesh, and Krishnaraj N, *Senior Member, IEEE*  
*School of Computer Science and Engineering (SCOPE), Vellore Institute of Technology, Vellore 632014, India*

Personalized physiological early warning algorithms face a classic dilemma: static baselines cannot accommodate benign sensor or circadian drift, while unguarded adaptive baselines absorb developing physiological anomalies into a shifted normal baseline. Furthermore, baseline calibration windows in the field are routinely contaminated by pre-shift exertion or hot ambient environments.

This repository implements the extended **Guarded Adaptive Framework** for occupational heat-strain early warning across six algorithmic components:
1. **Component A (Calibration Quality Assessment & Prior Blending)**: Evaluates level, trend, ambient heat, and dropout penalties during the initial 30 minutes to blend empirical baselines with a conservative prior.
2. **Component B (Multi-Condition Update Gate)**: Restricts baseline updates to low-risk, cool, high-signal-quality, non-rising states ($R(t) \le 0.35, H_{\text{obs}}(t) \le 0.50, q(t) = 1, \Delta \text{HR}_{5\text{m}} \le 6\text{ bpm}$).
3. **Component C (Alert-Triggered Freezing)**: Halts adaptation during active alerts and persists through a 10-minute post-alert cooldown.
4. **Component D (Rate-Limiting Drift Cap)**: Bounds baseline updates to physiologically plausible benign drift rates ($\le 1.5\text{ bpm/hr}$).
5. **Component E (Uncertainty-Aware Scaling)**: Dynamically expands the detection envelope for contaminated or uncertain calibration windows.
6. **Component F (Cross-Shift Baseline Memory)**: Employs gated exponential forgetting ($\gamma = 0.70$) to propagate shift-end resting baselines across consecutive work days.
7. **Multi-Modal $\text{SpO}_2$ Fusion**: Incorporates mild hypoxaemia detection ($\text{SpO}_2 < 94\%$) into multi-channel risk scoring.
8. **Formal Convergence Bound**: Mathematical proof demonstrating that rate limiting renders event absorption impossible ($\frac{d\delta}{dt} \ge \dot{H}_{\text{strain}} - \dot{\mu}^{\max} > 0 \implies T_{\text{det}} \le \frac{\theta}{\dot{H}_{\text{strain}} - \dot{\mu}^{\max}}$).
9. **Microcontroller Feasibility**: ANSI C implementation with $\mathcal{O}(1)$ time complexity and 352 bytes RAM footprint, verified on Raspberry Pi Zero 2W (0.12 ms/sample).

---

## 2. Directory Map

```text
heat_strain_ewarn/
├── configs/
│   ├── simulator.yaml         # Population priors, dynamics, noise, shift lengths
│   ├── methods.yaml           # Method hyper-parameters, ablation flags, gates
│   └── experiments.yaml       # Disjoint tuning & test seeds, matched-FA targets
├── src/hsew/
│   ├── simulator/             # Virtual workers, lag dynamics, contamination modes
│   ├── methods/               # Detection methods (all consume identical signals)
│   │   ├── base.py            # BaseMethod interface, alert state machine (k, hyst)
│   │   ├── baselines.py       # Fixed, Environmental, One-Shot, Unguarded EWMA
│   │   ├── guarded.py         # Guarded Adaptive Method (Components A through F + SpO2)
│   │   └── spc.py             # SPC comparators (Rolling median, EWMA chart, CUSUM)
│   ├── metrics/               # Evaluation harness and statistical tests
│   ├── experiments/           # CLI runners for Experiments 1 through 6, 12hr, multiday
│   │   ├── run_exp1.py        # Exp 1: Main benchmark & multi-operating point (Tables II, III)
│   │   ├── run_exp2.py        # Exp 2: Contaminated calibration sweep
│   │   ├── run_exp3.py        # Exp 3: Benign drift robustness sweep
│   │   ├── run_exp4.py        # Exp 4: Noise & packet missingness sweep
│   │   ├── run_exp5.py        # Exp 5: Extended ablation study A-F (Table VII)
│   │   ├── run_exp6.py        # Exp 6: Hyperparameter sensitivity & drift cap sweep (Table IV)
│   │   ├── run_exp_12hr.py    # Extended 12-hour shift simulation (Table V)
│   │   └── run_exp_multiday.py# 5-Day cross-shift baseline memory benchmark (Table VI)
│   ├── wesad/                 # WESAD validation (N=15 subjects, fitness stratification)
│   ├── mhealth/               # PhysioNet MHEALTH validation (Table VIII guard mechanics)
│   ├── edge/                  # ANSI C reference implementation & hardware profiling (Table IX)
│   ├── plotting/              # Publication figures (300 DPI, Okabe-Ito colorblind)
│   └── utils/                 # YAML loader and configuration utilities
├── tests/                     # 54 automated unit & integration tests
├── results/                   # Raw CSVs, summary tables, and generated figures
├── docs/                      # Methodology assumptions and publication paper draft
│   ├── methodology.md         # Equations, parameter distributions, and units
│   └── paper_draft.md         # Full IEEE JBHI journal paper
├── Makefile                   # One-command execution targets
└── pyproject.toml             # Pinned package configuration
```

---

## 3. Installation

Requires Python 3.11+.

```bash
# Clone and navigate into directory
cd heat_strain_ewarn

# Install in editable mode with development dependencies
python -m pip install -e .
```

---

## 4. One-Command Reproduction & Execution

All experiments and figures are reproducible with single-command targets:

| Command | Action | Expected Output |
| :--- | :--- | :--- |
| `make test` | Run entire test suite (**54 unit and integration tests**) | All 54 tests pass |
| `make exp1` | **Exp 1: Main Comparison & Multi-Operating-Point** | Tables II & III (`results/exp1_main/`) |
| `make exp2` | **Exp 2: Contaminated Calibration** sweep | `results/exp2_contamination/` |
| `make exp3` | **Exp 3: Benign Drift Robustness** sweep | `results/exp3_drift/` |
| `make exp4` | **Exp 4: Noise & Missingness** sweep | `results/exp4_noise_missingness/` |
| `make exp5` | **Exp 5: Extended Component Ablation** (A–F) | Table VII (`results/exp5_ablation/`) |
| `make exp6` | **Exp 6: Sensitivity Analysis & Drift Cap Sweep** | Table IV (`results/exp6_sensitivity/`) |
| `make exp_12hr` | **Extended 12-Hour Shift Simulation** ($T = 720\text{ min}$) | Table V (`results/exp_12hr/`) |
| `make exp_multiday`| **5-Day Cross-Shift Memory Benchmark** ($s = 0.50$) | Table VI (`results/exp_multiday/`) |
| `make wesad` | **WESAD Validation & Fitness Stratification** ($N = 15$) | `results/wesad_exploratory/` |
| `make mhealth` | **PhysioNet MHEALTH Validation** (12 Activities) | Table VIII (`results/mhealth_validation/`) |
| `make edge` | **Edge Deployment Benchmarking** (RPi / MCU) | Table IX (`results/edge_deployment/`) |
| `make figures` | Generate all publication figures (PNG) & tables | `results/figures/` |

---

## 5. Key Results Summary

- **Matched 0.50 FA/shift Benchmark**: Guarded Adaptive achieves **119.5 min** mean lead time with **0% missed events** ($\text{MER} = 0.00$), whereas unguarded EWMA achieves only **67.0 min** with **25% missed events** due to gradual event absorption ($p < 0.001, r = 0.84$).
- **Extended 12-Hour Shifts**: Over 720 minutes, benign drift accumulates up to 8.3 bpm. Unguarded Adaptive deteriorates to **38% missed events**, while Guarded Adaptive maintains **0% missed events** and **127.3 min** lead time.
- **Cross-Shift Continuity**: Over a 5-day work week with contaminated calibration ($s = 0.50$), Component F improves lead time from **119.5 min** on Day 1 to **122.8 min** on Day 5 (versus degrading to **112.3 min** without Component F).
- **Wearable Dataset Validation**: In WESAD ($n = 15$) and MHEALTH ($n = 10$), Guarded Adaptive successfully blocks **58–73%** of baseline updates during acute physical and psychological stress, preserving baseline resting integrity across 29/30 active sessions.
- **Microcontroller Feasibility**: The complete 6-component pipeline runs in **0.12 ms/sample** with **28 KB RAM** on a Raspberry Pi Zero 2W, fitting comfortably within the 64 KB SRAM budget of an ARM Cortex-M4.
