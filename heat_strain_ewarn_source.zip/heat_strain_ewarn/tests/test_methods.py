"""Unit and integration tests for Phase 2 methods and comparators."""

import numpy as np
import pandas as pd
import pytest

from hsew.simulator.workers import sample_worker
from hsew.simulator.runner import simulate_shift
from hsew.utils.config import load_config
from hsew.methods import (
    FixedThresholdMethod,
    EnvironmentalOnlyMethod,
    OneShotPersonalizedMethod,
    UnguardedAdaptiveMethod,
    GuardedAdaptiveMethod,
    RollingMedianMethod,
    EWMAControlChartMethod,
    CUSUMMethod,
    get_method,
)


@pytest.fixture
def sim_data():
    cfg = load_config("configs/simulator.yaml")
    rng = np.random.default_rng(42)
    worker = sample_worker("W_TEST", rng=rng)
    signals_df, labels_df = simulate_shift(
        worker=worker,
        shift_id="S001",
        scenario="ramp",
        seed=42,
        config=cfg,
    )
    return signals_df, labels_df


@pytest.fixture
def methods_config():
    return load_config("configs/methods.yaml")


ALL_METHOD_NAMES = [
    "fixed_threshold",
    "environmental_only",
    "oneshot_personalized",
    "unguarded_adaptive",
    "guarded_adaptive",
    "rolling_median",
    "ewma_control_chart",
    "cusum",
]


@pytest.mark.parametrize("m_name", ALL_METHOD_NAMES)
def test_all_methods_run_and_shapes(m_name, sim_data, methods_config):
    """Test that every method runs and returns arrays of length 480."""
    signals_df, _ = sim_data
    method = get_method(m_name, config=methods_config)
    res = method.run(signals_df)

    assert len(res.risk_score) == 480
    assert len(res.alert_flag) == 480
    assert set(np.unique(res.alert_flag)).issubset({0, 1})
    assert not np.isnan(res.risk_score).all()


@pytest.mark.parametrize("m_name", ALL_METHOD_NAMES)
def test_methods_deterministic(m_name, sim_data, methods_config):
    """Test that all methods are strictly deterministic given identical input."""
    signals_df, _ = sim_data
    method = get_method(m_name, config=methods_config)

    res1 = method.run(signals_df)
    res2 = method.run(signals_df)

    np.testing.assert_array_equal(res1.risk_score, res2.risk_score)
    np.testing.assert_array_equal(res1.alert_flag, res2.alert_flag)


@pytest.mark.parametrize("m_name", ALL_METHOD_NAMES)
def test_methods_reject_labels(m_name, sim_data, methods_config):
    """Ensure that algorithms strictly reject any input containing hidden event labels."""
    signals_df, labels_df = sim_data
    leaked_df = signals_df.copy()
    leaked_df["event_active"] = labels_df["event_active"]

    method = get_method(m_name, config=methods_config)
    with pytest.raises(ValueError, match="Label leakage violation"):
        method.run(leaked_df)


def test_guarded_all_off_equals_unguarded(sim_data, methods_config):
    """CRITICAL TEST: Guarded adaptive with all 5 ablation components off must exactly equal Unguarded."""
    signals_df, _ = sim_data

    unguarded = UnguardedAdaptiveMethod(
        calibration_minutes=30,
        ewma_alpha=0.02,
        w_hr=0.50,
        w_temp=0.30,
        w_heat=0.20,
        threshold=0.55,
        persistence_k=3,
    )

    guarded_off = GuardedAdaptiveMethod(
        calibration_minutes=30,
        ewma_alpha=0.02,
        w_hr=0.50,
        w_temp=0.30,
        w_heat=0.20,
        threshold=0.55,
        persistence_k=3,
        use_quality_score=False,      # Off
        use_update_gate=False,        # Off
        use_freeze_on_warning=False,  # Off
        use_rate_limiter=False,       # Off
        use_uncertainty_scale=False,  # Off
    )

    res_ung = unguarded.run(signals_df)
    res_g_off = guarded_off.run(signals_df)

    # Risk scores, alerts, and baselines must be numerically identical
    np.testing.assert_allclose(res_ung.risk_score, res_g_off.risk_score, atol=1e-12)
    np.testing.assert_array_equal(res_ung.alert_flag, res_g_off.alert_flag)
    np.testing.assert_allclose(
        res_ung.current_baseline["hr"],
        res_g_off.current_baseline["hr"],
        atol=1e-12,
    )
    np.testing.assert_allclose(
        res_ung.current_baseline["skin_temp"],
        res_g_off.current_baseline["skin_temp"],
        atol=1e-12,
    )


def test_guarded_resists_absorption(methods_config):
    """Verify that Guarded adaptation halts baseline updates during developing strain."""
    # Synthetic shift with developing heat strain
    t = np.arange(480)
    hr = np.full(480, 72.0)
    hr[60:] = np.linspace(72.0, 130.0, 420)  # developing elevation
    temp = np.full(480, 33.5)
    temp[60:] = np.linspace(33.5, 37.5, 420)
    heat = np.full(480, 0.2)
    heat[60:] = np.linspace(0.2, 0.9, 420)

    signals_df = pd.DataFrame({
        "worker_id": "W001",
        "minute": t,
        "hr": hr,
        "skin_temp": temp,
        "eda": np.full(480, 2.0),
        "heat_load_observed": heat,
        "quality_flag": np.ones(480, dtype=int),
    })

    unguarded = get_method("unguarded_adaptive", config=methods_config)
    guarded = get_method("guarded_adaptive", config=methods_config)

    res_ung = unguarded.run(signals_df)
    res_grd = guarded.run(signals_df)

    final_ung_hr_base = res_ung.current_baseline["hr"][-1]
    final_grd_hr_base = res_grd.current_baseline["hr"][-1]

    # Unguarded should absorb the strain and drift to very high values (> 90 bpm)
    assert final_ung_hr_base > 95.0, f"Unguarded baseline did not absorb strain: {final_ung_hr_base}"

    # Guarded baseline must remain protected and not drift up to the strain level (< 80 bpm)
    assert final_grd_hr_base < 82.0, f"Guarded baseline was improperly absorbed: {final_grd_hr_base}"


def test_quality_score_penalizes_contamination(methods_config):
    """Component A test: post-exertion contamination reduces calibration quality score."""
    t = np.arange(480)
    # Clean resting calibration
    clean_signals = pd.DataFrame({
        "worker_id": "W001",
        "minute": t,
        "hr": np.full(480, 70.0),
        "skin_temp": np.full(480, 33.0),
        "eda": np.full(480, 2.0),
        "heat_load_observed": np.full(480, 0.15),
        "quality_flag": np.ones(480, dtype=int),
    })

    # Contaminated calibration (elevated HR decaying from 110 bpm, high heat)
    contam_signals = pd.DataFrame({
        "worker_id": "W001",
        "minute": t,
        "hr": np.concatenate([110.0 - np.arange(30) * 1.0, np.full(450, 70.0)]),
        "skin_temp": np.full(480, 34.5),
        "eda": np.full(480, 3.0),
        "heat_load_observed": np.concatenate([np.full(30, 0.75), np.full(450, 0.2)]),
        "quality_flag": np.ones(480, dtype=int),
    })

    guarded = get_method("guarded_adaptive", config=methods_config)

    res_clean = guarded.run(clean_signals)
    res_contam = guarded.run(contam_signals)

    q_clean = res_clean.metadata["calibration_quality"]
    q_contam = res_contam.metadata["calibration_quality"]

    assert q_clean > 0.90, f"Expected high quality for clean baseline, got {q_clean}"
    assert q_contam < 0.60, f"Expected low quality for contaminated baseline, got {q_contam}"
