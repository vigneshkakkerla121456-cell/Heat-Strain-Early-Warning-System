"""Test package imports and version."""

def test_imports():
    import hsew
    import hsew.experiments
    import hsew.methods
    import hsew.metrics
    import hsew.plotting
    import hsew.simulator
    import hsew.utils
    import hsew.wesad

    assert hsew.__version__ == "0.1.0"
