"""Unit and integration tests for Journal Extension additions.

Covers:
1. Component F: Cross-shift baseline memory & gated forgetting.
2. Component I: Multi-modal SpO2 fusion.
3. PhysioNet MHEALTH validation loader & guard-mechanics analysis.
4. Extended 12-hour simulation benchmark.
5. Multi-day simulation benchmark (5 consecutive shifts).
6. Edge deployment benchmarks.
7. Fitness-stratified WESAD analysis.
"""

import numpy as np
import pandas as pd
import pytest

from hsew.methods import GuardedAdaptiveMethod
from hsew.mhealth.loader import generate_mock_mhealth_subject, load_mhealth_subject
from hsew.mhealth.analysis import evaluate_mhealth_guard_mechanics
from hsew.wesad.loader import generate_mock_wesad_subject
from hsew.wesad.analysis import analyze_fitness_stratification
from hsew.experiments.run_exp_12hr import run_12hr_simulation_benchmark
from hsew.experiments.run_exp_multiday import run_multiday_experiment
from hsew.edge.profile_edge import profile_edge_execution


def test_component_f_cross_shift_memory():
    """Verify Component F gated exponential forgetting at shift end."""
    n = 480
    t = np.arange(n)
    # Steady resting signal
    signals_df = pd.DataFrame({
        "worker_id": "W001",
        "minute": t,
        "hr": np.full(n, 80.0),
        "skin_temp": np.full(n, 33.5),
        "eda": np.full(n, 2.0),
        "heat_load_observed": np.full(n, 0.20),
        "quality_flag": np.ones(n, dtype=int),
    })

    # Day 1 with Component F
    method_d1 = GuardedAdaptiveMethod(
        use_cross_shift_memory=True,
        prior_hr=72.0,
        memory_gamma=0.70,
    )
    res_d1 = method_d1.run(signals_df)

    assert "updated_long_term_hr" in res_d1.metadata
    assert "gate_pass_fraction_final_60" in res_d1.metadata
    assert res_d1.metadata["gate_pass_fraction_final_60"] >= 0.60
    assert res_d1.metadata["memory_gated"] is True

    # Check formula: gamma * 72.0 + (1 - gamma) * end_baseline
    end_hr = res_d1.metadata["final_hr_baseline"]
    expected_lt = 0.70 * 72.0 + 0.30 * end_hr
    assert np.isclose(res_d1.metadata["updated_long_term_hr"], expected_lt, atol=1e-3)

    # Day 2: blend empirical calibration with day-1 updated prior
    method_d2 = GuardedAdaptiveMethod(
        use_cross_shift_memory=True,
        prior_hr=72.0,
        long_term_prior_hr=expected_lt,
    )
    res_d2 = method_d2.run(signals_df)
    # Starting baseline should be informed by long-term prior
    assert res_d2.current_baseline["hr"][0] > 72.0


def test_spo2_fusion():
    """Verify multi-modal SpO2 fusion term (Component I, eq 15)."""
    n = 100
    t = np.arange(n)
    signals_normal = pd.DataFrame({
        "worker_id": "W001",
        "minute": t,
        "hr": np.full(n, 75.0),
        "skin_temp": np.full(n, 33.5),
        "eda": np.full(n, 2.0),
        "heat_load_observed": np.full(n, 0.20),
        "quality_flag": np.ones(n, dtype=int),
        "spo2": np.full(n, 98.0),  # normal SpO2 >= 94%
    })

    signals_hypox = signals_normal.copy()
    signals_hypox["spo2"] = np.full(n, 90.0)  # mild hypoxaemia SpO2 < 94%

    method = GuardedAdaptiveMethod(use_spo2=True)
    res_normal = method.run(signals_normal)
    res_hypox = method.run(signals_hypox)

    # Mild hypoxaemia should strictly elevate risk
    assert np.all(res_hypox.risk_score >= res_normal.risk_score)
    # Difference should match eq (15): 0.10 * (94 - 90)/4 = 0.10
    expected_diff = 0.10 * (94.0 - 90.0) / 4.0
    np.testing.assert_allclose(res_hypox.risk_score - res_normal.risk_score, expected_diff, atol=1e-3)


def test_mhealth_loader_and_guard_mechanics():
    """Verify MHEALTH mock stream loading and guard mechanics evaluation."""
    sub = generate_mock_mhealth_subject(subject_id="m01", duration_minutes=150)
    assert len(sub) == 150
    assert set(["hr", "skin_temp", "eda", "activity", "quality_flag"]).issubset(sub.columns)

    # Edge case subject 8 (resting HR 89.2 bpm)
    sub8 = generate_mock_mhealth_subject(subject_id="m08", duration_minutes=150)
    assert np.isclose(sub8["hr"].iloc[0], 89.2, atol=2.0)

    # Test Table VIII evaluation
    subjects = [generate_mock_mhealth_subject(f"m{i:02d}", duration_minutes=150) for i in range(1, 11)]
    tbl_df = evaluate_mhealth_guard_mechanics(subjects)

    assert "Condition" in tbl_df.columns
    assert "Blocked Updates" in tbl_df.columns
    assert "HR Preserved" in tbl_df.columns
    assert len(tbl_df) == 5  # Cycling, Running, Stair Climb, Sitting, Mean (active)


def test_12hr_shift_benchmark():
    """Verify 12-hour extended simulation schema and values."""
    df = run_12hr_simulation_benchmark()
    assert len(df) == 5
    assert "Method" in df.columns
    assert "Lead (min)" in df.columns
    # Guarded must have 0% missed events (MER = 0.00)
    guarded_row = df[df["Method"] == "Guarded Adaptive"].iloc[0]
    assert guarded_row["MER"] == 0.00
    assert guarded_row["EWR"] == 1.00


def test_multiday_experiment():
    """Verify 5-day memory benchmark schema."""
    df = run_multiday_experiment()
    assert len(df) == 2  # Without F vs With F
    assert "Day 5" in df.columns
    with_f_day5 = df[df["Variant"].str.contains("With F")]["Day 5"].iloc[0]
    without_f_day5 = df[df["Variant"].str.contains("Without F")]["Day 5"].iloc[0]
    # Component F must show superior lead time by Day 5
    assert with_f_day5 > without_f_day5


def test_edge_profiling():
    """Verify edge profiling execution and table output."""
    df = profile_edge_execution(n_samples=60)
    assert len(df) == 4
    assert "Platform" in df.columns
    assert "Peak RAM" in df.columns


def test_fitness_stratification():
    """Verify WESAD cross-population stratification by fitness."""
    subs = [generate_mock_wesad_subject(f"S{i:02d}", duration_minutes=120) for i in range(2, 17)]
    df = analyze_fitness_stratification(subs)
    assert len(df) == 3
    assert "Stratum" in df.columns
    assert "Lead-time proxy" in df.columns

