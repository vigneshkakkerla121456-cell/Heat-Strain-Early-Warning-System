"""Hand-built toy sequence tests for event-level, alarm-level, matched-FA, and Rule 6 compliance."""

import numpy as np
import pytest

from hsew.metrics.event_metrics import evaluate_shift_alerts, count_alert_episodes
from hsew.metrics.alarm_metrics import aggregate_evaluation_results
from hsew.metrics.matched_fa import find_matched_threshold
from hsew.metrics.uncertainty import bootstrap_ci, paired_comparison_wilcoxon
import pandas as pd


def test_toy_early_warning_and_pre_existing():
    """Toy Case 1: Alert occurs 25 min before onset; active at onset (pre-existing alert)."""
    n = 480
    alerts = np.zeros(n, dtype=int)
    event_act = np.zeros(n, dtype=int)

    t_onset = 200
    event_act[t_onset:300] = 1

    # Alert starts at 175 and stays active until 250
    alerts[175:251] = 1

    res = evaluate_shift_alerts(
        alert_flag=alerts,
        event_active=event_act,
        event_onset_minute=t_onset,
        shift_id="S_TOY1",
        calibration_minutes=30,
    )

    assert res.has_event is True
    assert res.detected is True
    assert res.early_warning is True
    assert res.warning_lead_time == 25.0
    assert res.is_pre_existing_alert is True
    # Rule 6: detection delay is None because warning was already active
    assert res.detection_delay is None
    assert res.missed_event is False
    assert res.false_alarm_count == 0


def test_toy_new_alert_after_onset_rule_6():
    """Toy Case 2: No alert before onset; NEW alert raised 15 min after onset (Rule 6)."""
    n = 480
    alerts = np.zeros(n, dtype=int)
    event_act = np.zeros(n, dtype=int)

    t_onset = 200
    event_act[t_onset:300] = 1

    # Alert begins at 215 (15 minutes after onset)
    alerts[215:260] = 1

    res = evaluate_shift_alerts(
        alert_flag=alerts,
        event_active=event_act,
        event_onset_minute=t_onset,
        shift_id="S_TOY2",
        calibration_minutes=30,
    )

    assert res.has_event is True
    assert res.detected is True
    assert res.early_warning is False
    assert res.warning_lead_time == 0.0
    assert res.is_pre_existing_alert is False
    # Rule 6: detection delay strictly measured from onset to new alert start
    assert res.detection_delay == 15.0
    assert res.missed_event is False
    assert res.false_alarm_count == 0


def test_toy_missed_event_with_premature_alarm():
    """Toy Case 3: Alert terminates long before onset; no alert during event -> Missed."""
    n = 480
    alerts = np.zeros(n, dtype=int)
    event_act = np.zeros(n, dtype=int)

    t_onset = 350
    event_act[t_onset:450] = 1

    # Premature alarm at minute 50..60 (far earlier than max_lead_window of 120 min)
    alerts[50:61] = 1

    res = evaluate_shift_alerts(
        alert_flag=alerts,
        event_active=event_act,
        event_onset_minute=t_onset,
        shift_id="S_TOY3",
        calibration_minutes=30,
        max_lead_window=120,
    )

    assert res.has_event is True
    assert res.detected is False
    assert res.missed_event is True
    assert res.warning_lead_time == 0.0
    assert res.detection_delay is None
    # The premature alert counts as a false alarm
    assert res.false_alarm_count == 1


def test_toy_no_event_shift_false_alarms():
    """Toy Case 4: No-event shift with 3 separate alert episodes."""
    n = 480
    alerts = np.zeros(n, dtype=int)
    event_act = np.zeros(n, dtype=int)

    # 3 episodes post-calibration
    alerts[100:111] = 1  # 11 mins
    alerts[200:206] = 1  # 6 mins
    alerts[350:361] = 1  # 11 mins

    res = evaluate_shift_alerts(
        alert_flag=alerts,
        event_active=event_act,
        event_onset_minute=-1,
        shift_id="S_TOY4",
        calibration_minutes=30,
    )

    assert res.has_event is False
    assert res.false_alarm_count == 3
    assert res.total_alert_minutes == 28
    assert res.fp_minutes == 28
    assert res.tp_minutes == 0


def test_matched_fa_threshold_interpolation():
    """Test interpolation of matched decision threshold on monotone synthetic sweep."""
    sweep_df = pd.DataFrame({
        "threshold": [0.2, 0.4, 0.6, 0.8, 1.0],
        "fa_per_shift": [2.0, 1.0, 0.5, 0.25, 0.0],
    })

    # Exact points
    t_05 = find_matched_threshold(sweep_df, target_fa=0.5)
    assert pytest.approx(t_05, abs=1e-3) == 0.6

    t_025 = find_matched_threshold(sweep_df, target_fa=0.25)
    assert pytest.approx(t_025, abs=1e-3) == 0.8

    # Interpolated midpoint: target 0.75 is between 1.0 (thresh 0.4) and 0.5 (thresh 0.6)
    t_075 = find_matched_threshold(sweep_df, target_fa=0.75)
    assert pytest.approx(t_075, abs=1e-3) == 0.5


def test_bootstrap_and_wilcoxon():
    """Test bootstrap confidence interval and Wilcoxon paired comparisons."""
    vals = [20.0, 22.0, 21.0, 24.0, 23.0]
    mean_val, lower, upper = bootstrap_ci(vals, n_boot=500, ci=0.95, seed=42)

    assert lower <= mean_val <= upper
    assert 20.0 <= lower <= 24.0

    # Paired test: Guarded consistently higher than comparator
    guarded = np.array([30.0, 28.0, 32.0, 29.0, 31.0, 33.0])
    comp = np.array([10.0, 12.0, 11.0, 14.0, 13.0, 15.0])

    res = paired_comparison_wilcoxon(guarded, comp)
    assert res["mean_diff"] > 15.0
    assert res["p_value"] < 0.05
    assert res["rank_biserial_r"] > 0.0
