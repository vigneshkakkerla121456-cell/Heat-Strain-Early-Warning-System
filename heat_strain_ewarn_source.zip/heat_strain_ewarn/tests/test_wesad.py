"""Unit tests for Phase 5 WESAD loader and exploratory analysis."""

import numpy as np
import pandas as pd
import pytest

from hsew.wesad.loader import generate_mock_wesad_subject, load_wesad_subject
from hsew.wesad.analysis import (
    analyze_intersubject_variability,
    analyze_baseline_evolution,
    run_pseudo_contamination_test,
)


def test_mock_wesad_schema_and_values():
    """Verify mock WESAD stream matches Empatica E4 schema and length."""
    df = generate_mock_wesad_subject("S02", duration_minutes=120, seed=42)

    assert len(df) == 120
    expected_cols = {"subject_id", "minute", "hr", "skin_temp", "eda", "label", "quality_flag"}
    assert expected_cols.issubset(df.columns)

    # Resting baseline must be physiologically plausible
    valid_hr = df["hr"].dropna()
    assert (valid_hr >= 45.0).all() and (valid_hr <= 160.0).all()


def test_wesad_variability_analysis():
    """Verify Analysis 1 calculates inter-subject baseline statistics."""
    s2 = generate_mock_wesad_subject("S02", seed=10)
    s3 = generate_mock_wesad_subject("S03", seed=20)
    comb = pd.concat([s2, s3], ignore_index=True)

    var_df = analyze_intersubject_variability(comb)
    assert len(var_df) == 2
    assert "baseline_hr_mean" in var_df.columns
    assert "baseline_temp_mean" in var_df.columns

    # Inter-subject means should reflect individuality
    assert var_df.loc[0, "baseline_hr_mean"] != var_df.loc[1, "baseline_hr_mean"]


def test_wesad_baseline_evolution_and_blocking():
    """Verify Analysis 2 runs methods and records blocked adaptation minutes."""
    s2 = generate_mock_wesad_subject("S02", seed=10)
    evol_df = analyze_baseline_evolution([s2])

    assert len(evol_df) == 1
    assert "guarded_updates_blocked_minutes" in evol_df.columns
    # Due to stress condition, Guarded should block updates for a non-zero number of minutes
    assert evol_df["guarded_updates_blocked_minutes"].iloc[0] > 0


def test_wesad_pseudo_contamination():
    """Verify Analysis 3 pseudo-contamination test evaluates all 3 methods."""
    s2 = generate_mock_wesad_subject("S02", seed=10)
    pseudo_df = run_pseudo_contamination_test([s2])

    assert len(pseudo_df) == 3  # One-shot, Unguarded, Guarded
    methods = set(pseudo_df["method"])
    assert methods == {"oneshot_personalized", "unguarded_adaptive", "guarded_adaptive"}
