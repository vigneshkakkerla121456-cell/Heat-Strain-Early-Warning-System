"""Unit and smoke tests for Phase 4 experiment runners and disjoint seeds."""

from pathlib import Path
import pytest

from hsew.utils.config import load_config
from hsew.experiments.experiment_base import generate_experiment_dataset


def test_disjoint_seeds():
    """Verify Rule 4: Tuning seeds and test seeds are strictly disjoint."""
    cfg = load_config("configs/experiments.yaml")
    tuning_seeds = set(cfg["seeds"]["tuning_seeds"])
    test_seeds = set(cfg["seeds"]["test_seeds"])

    overlap = tuning_seeds.intersection(test_seeds)
    assert len(overlap) == 0, f"Disjoint seed violation: overlapping seeds found {overlap}"
    assert len(tuning_seeds) >= 5, "Expected at least 5 tuning seeds"
    assert len(test_seeds) >= 20, "Expected at least 20 test seeds"


def test_exp1_smoke_run(tmp_path):
    """Smoke test running Experiment 1 pipeline end-to-end."""
    import subprocess
    import sys

    out_dir = tmp_path / "exp1_test"
    cmd = [
        sys.executable,
        "-m", "hsew.experiments.run_exp1",
        "--config", "configs/experiments.yaml",
        "--out_dir", str(out_dir),
        "--fast",
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"run_exp1 failed:\n{res.stderr}\n{res.stdout}"

    summary_file = out_dir / "summary.csv"
    assert summary_file.exists()
    assert summary_file.stat().st_size > 50


def test_exp5_ablation_smoke_run(tmp_path):
    """Smoke test running Experiment 5 Ablation study end-to-end."""
    import subprocess
    import sys

    out_dir = tmp_path / "exp5_test"
    cmd = [
        sys.executable,
        "-m", "hsew.experiments.run_exp5",
        "--config", "configs/experiments.yaml",
        "--out_dir", str(out_dir),
        "--fast",
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"run_exp5 failed:\n{res.stderr}\n{res.stdout}"

    summary_file = out_dir / "summary.csv"
    assert summary_file.exists()
    assert summary_file.stat().st_size > 50
