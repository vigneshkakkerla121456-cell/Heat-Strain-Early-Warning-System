"""Unit and integration tests for Phase 1 simulator."""

import numpy as np
import pandas as pd
import pytest

from hsew.simulator.workers import sample_worker, sample_population, VirtualWorker
from hsew.simulator.environment import create_environment_profile
from hsew.simulator.runner import simulate_shift, simulate_cohort
from hsew.utils.config import load_config


@pytest.fixture
def base_config():
    return load_config("configs/simulator.yaml")


@pytest.fixture
def test_worker():
    rng = np.random.default_rng(123)
    return sample_worker("W_TEST", rng=rng)


def test_simulation_shapes(test_worker, base_config):
    """Test that simulated shifts produce correct row counts and schema."""
    signals_df, labels_df = simulate_shift(
        worker=test_worker,
        shift_id="S001",
        scenario="ramp",
        seed=42,
        config=base_config,
    )

    assert len(signals_df) == 480
    assert len(labels_df) == 480

    expected_signals_cols = {
        "worker_id", "shift_id", "minute", "hr", "skin_temp",
        "eda", "heat_load_observed", "quality_flag"
    }
    expected_labels_cols = {
        "worker_id", "shift_id", "minute", "event_present",
        "event_onset_minute", "event_active"
    }

    assert expected_signals_cols.issubset(signals_df.columns)
    assert expected_labels_cols.issubset(labels_df.columns)


def test_seed_reproducibility(test_worker, base_config):
    """Test that identical seeds generate bit-for-bit identical signals and labels."""
    sig1, lbl1 = simulate_shift(test_worker, "S001", scenario="ramp", seed=999, config=base_config)
    sig2, lbl2 = simulate_shift(test_worker, "S001", scenario="ramp", seed=999, config=base_config)

    pd.testing.assert_frame_equal(sig1, sig2)
    pd.testing.assert_frame_equal(lbl1, lbl2)

    # Different seeds must produce different results
    sig3, _ = simulate_shift(test_worker, "S001", scenario="ramp", seed=1000, config=base_config)
    assert not sig1["hr"].equals(sig3["hr"])


def test_no_label_leakage(test_worker, base_config):
    """Verify that labels, onset times, and latent strain never leak into the signals table."""
    signals_df, _ = simulate_shift(test_worker, "S001", scenario="ramp", seed=42, config=base_config)

    for col in signals_df.columns:
        col_lower = col.lower()
        assert "event" not in col_lower, f"Leaked 'event' in signals column: {col}"
        assert "onset" not in col_lower, f"Leaked 'onset' in signals column: {col}"
        assert "label" not in col_lower, f"Leaked 'label' in signals column: {col}"
        assert "strain" not in col_lower, f"Leaked 'strain' in signals column: {col}"


def test_no_event_shifts(test_worker, base_config):
    """Verify that cool shifts produce no heat-strain events."""
    _, labels_df = simulate_shift(
        worker=test_worker,
        shift_id="S_COOL",
        scenario="cool",
        seed=42,
        config=base_config,
    )

    assert not labels_df["event_present"].any()
    assert (labels_df["event_onset_minute"] == -1).all()
    assert (labels_df["event_active"] == 0).all()


def test_contamination_shifts_calibration_mean(test_worker, base_config):
    """Verify that contamination modes shift calibration baseline statistics as expected."""
    # Clean shift
    sig_clean, _ = simulate_shift(
        worker=test_worker,
        shift_id="S_CLEAN",
        scenario="cool",
        contamination_mode="clean",
        contamination_strength=0.0,
        seed=42,
        config=base_config,
    )

    # Post-exertion contamination
    sig_post_ex, _ = simulate_shift(
        worker=test_worker,
        shift_id="S_EX",
        scenario="cool",
        contamination_mode="post_exertion",
        contamination_strength=1.0,
        seed=42,
        config=base_config,
    )

    # Already-hot contamination
    sig_hot, _ = simulate_shift(
        worker=test_worker,
        shift_id="S_HOT",
        scenario="cool",
        contamination_mode="already_hot",
        contamination_strength=1.0,
        seed=42,
        config=base_config,
    )

    cal_clean_hr = sig_clean.loc[:29, "hr"].dropna().mean()
    cal_ex_hr = sig_post_ex.loc[:29, "hr"].dropna().mean()
    cal_clean_temp = sig_clean.loc[:29, "skin_temp"].dropna().mean()
    cal_hot_temp = sig_hot.loc[:29, "skin_temp"].dropna().mean()

    # Post-exertion should elevate mean calibration HR significantly (> 5 bpm)
    assert cal_ex_hr > cal_clean_hr + 5.0, f"Post-exertion HR {cal_ex_hr} not elevated vs clean {cal_clean_hr}"

    # Already-hot should elevate mean calibration skin temperature (> 0.8 deg C)
    assert cal_hot_temp > cal_clean_temp + 0.8, f"Already-hot temp {cal_hot_temp} not elevated vs clean {cal_clean_temp}"


def test_quality_flags_and_missingness(test_worker, base_config):
    """Verify that quality flags accurately indicate dropped/missing values."""
    signals_df, _ = simulate_shift(
        worker=test_worker,
        shift_id="S_MISSING",
        scenario="ramp",
        seed=77,
        config=base_config,
    )

    # Should have some dropped readings
    missing_mask = signals_df["quality_flag"] == 0
    assert missing_mask.sum() > 0, "Expected some missing readings in 480 minutes"

    # Dropped readings must have NaN HR and NaN skin_temp
    assert signals_df.loc[missing_mask, "hr"].isna().all()
    assert signals_df.loc[missing_mask, "skin_temp"].isna().all()

    # Valid readings must have numeric HR
    valid_mask = signals_df["quality_flag"] == 1
    assert signals_df.loc[valid_mask, "hr"].notna().all()
