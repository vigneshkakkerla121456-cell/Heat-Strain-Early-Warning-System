"""CLI runner for WESAD exploratory wearable analysis."""

import argparse
from pathlib import Path
import pandas as pd

from hsew.wesad.loader import generate_mock_wesad_subject, load_wesad_subject
from hsew.wesad.analysis import (
    analyze_intersubject_variability,
    analyze_baseline_evolution,
    run_pseudo_contamination_test,
    analyze_fitness_stratification,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run WESAD Exploratory Analysis (Not Heat Strain Ground Truth)."
    )
    parser.add_argument(
        "--data_dir",
        type=str,
        default="data/wesad",
        help="Path to directory containing WESAD subject files.",
    )
    parser.add_argument(
        "--out_dir",
        type=str,
        default="results/wesad_exploratory",
        help="Path to save output CSVs.",
    )
    parser.add_argument(
        "--num_subjects",
        type=int,
        default=15,
        help="Number of subjects to evaluate (default 15).",
    )
    args = parser.parse_args()

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print("==========================================================================")
    print("WESAD EXPLORATORY ANALYSIS (REAL WEARABLE SIGNALS: EMPATICA E4, N=15)")
    print("NOTE: Stress/affect dataset for baseline dynamics study, NOT heat strain.")
    print("==========================================================================")

    # 1. Load subjects (S02 through S16, N=15)
    subjects_data = []
    for i in range(2, 2 + args.num_subjects):
        sub_id = f"S{i:02d}"
        sub_df = load_wesad_subject(args.data_dir, subject_id=sub_id)
        subjects_data.append(sub_df)

    combined_df = pd.concat(subjects_data, ignore_index=True)

    # 2. Analysis 1: Inter-subject baseline variability
    print("\nRunning Analysis 1: Inter-subject baseline variability (N=15)...")
    var_df = analyze_intersubject_variability(combined_df)
    var_csv = out_path / "baseline_variability.csv"
    var_df.to_csv(var_csv, index=False)
    print(f"Saved: {var_csv}")

    # 3. Analysis 2: Baseline evolution & gate blocking
    print("\nRunning Analysis 2: Baseline adaptation and gate blocking...")
    evol_df = analyze_baseline_evolution(subjects_data)
    evol_csv = out_path / "baseline_evolution.csv"
    evol_df.to_csv(evol_csv, index=False)
    print(f"Saved: {evol_csv}")

    # 4. Analysis 3: Pseudo-contamination test
    print("\nRunning Analysis 3: Pseudo-contamination stress transition test...")
    pseudo_df = run_pseudo_contamination_test(subjects_data)
    pseudo_csv = out_path / "pseudo_contamination.csv"
    pseudo_df.to_csv(pseudo_csv, index=False)
    print(f"Saved: {pseudo_csv}")

    # 5. Analysis 4: Cross-population stratification by fitness level (Section V-I)
    print("\nRunning Analysis 4: Cross-population stratification by fitness level...")
    strat_df = analyze_fitness_stratification(subjects_data)
    strat_csv = out_path / "cross_population_stratification.csv"
    strat_df.to_csv(strat_csv, index=False)
    print(f"Saved: {strat_csv}")
    print("\n" + strat_df.to_string(index=False))

    print("\n=== WESAD Exploratory Analysis Completed Successfully ===")


if __name__ == "__main__":
    main()
