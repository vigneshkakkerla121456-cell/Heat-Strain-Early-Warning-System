"""Generate publication-quality, color-rich figures and markdown tables for IEEE JBHI."""

from pathlib import Path
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd

# Publication typography & styling
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 8.5,
    "figure.titlesize": 12,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": False,
})

# Modern vibrant publication palette (IEEE JBHI style)
PALETTE = {
    "guarded": "#00897B",        # Deep Teal / Emerald (Proposed Guarded)
    "unguarded": "#E53935",      # Vibrant Crimson Red (Unguarded)
    "oneshot": "#1E88E5",        # Sapphire Royal Blue (One-Shot)
    "fixed": "#37474F",          # Dark Slate Charcoal (Fixed Threshold)
    "environmental": "#FB8C00",  # Warm Amber / Orange (Environmental Only)
    "rolling_median": "#00ACC1", # Cyan / Ocean Blue (Rolling Median)
    "ewma_chart": "#8E24AA",     # Deep Amethyst Purple (EWMA Chart)
    "cusum": "#6D4C41",          # Bronze Brown (CUSUM)
    "memory_f": "#3949AB",       # Indigo (Component F Memory)
    "neutral_line": "#78909C",   # Blue-Grey for observed signals
    "event_fill": "#FFB74D",     # Light Amber for true event shading
    "calib_fill": "#ECEFF1",     # Light Slate for calibration window
    "nominal_fill": "#E0F2F1",   # Soft Mint for nominal periods
    "stress_fill": "#FFEBEE",    # Soft Rose for stress window
}


def df_to_markdown_table(df: pd.DataFrame) -> str:
    """Format DataFrame as standard Markdown table without external dependencies."""
    headers = [str(col) for col in df.columns]
    lines = ["| " + " | ".join(headers) + " |"]
    lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
    for _, row in df.iterrows():
        vals = [
            f"{val:.3f}" if isinstance(val, (float, np.floating)) else str(val)
            for val in row
        ]
        lines.append("| " + " | ".join(vals) + " |")
    return "\n".join(lines) + "\n"


def plot_fig1_pipeline_diagram(out_path: Path) -> None:
    """Figure 1: Extended 6-Component Guarded Adaptive Pipeline Architecture."""
    fig, ax = plt.subplots(figsize=(11, 5.0))
    ax.axis("off")

    boxes = [
        ("Observable Inputs\n(HR, T_skin, EDA,\nHeat Load, SpO2)", (0.04, 0.52), 0.20, 0.38, PALETTE["oneshot"]),
        ("Components A & F\nCalibration Quality (Q)\n& Long-Term Prior\n(Cross-Shift Memory)", (0.28, 0.52), 0.22, 0.38, PALETTE["memory_f"]),
        ("Guarded Adaptation\n(B: Multi-Condition Gate\nC: Freeze on Warning\nD: 1.5 bpm/hr Drift Cap\nE: Uncertainty Scaling)", (0.54, 0.52), 0.25, 0.38, PALETTE["guarded"]),
        ("Decision & Alert\nState Machine\n(k=3 min persist,\nHysteresis Cooldown)", (0.83, 0.52), 0.15, 0.38, PALETTE["unguarded"]),
    ]

    for title, (x, y), w, h, col in boxes:
        rect = patches.FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.02,rounding_size=0.03",
            ec=col, fc=col, alpha=0.12, lw=2.2
        )
        ax.add_patch(rect)
        rect_border = patches.FancyBboxPatch(
            (x, y), w, h,
            boxstyle="round,pad=0.02,rounding_size=0.03",
            ec=col, fc="none", lw=2.2
        )
        ax.add_patch(rect_border)
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", weight="bold", color="#1A237E" if col == PALETTE["memory_f"] else ("#004D40" if col == PALETTE["guarded"] else "#212121"), fontsize=9.2)

    # Connecting arrows
    arrow_props = dict(facecolor="#455A64", edgecolor="#455A64", width=2.0, headwidth=8, headlength=8)
    ax.annotate("", xy=(0.28, 0.71), xytext=(0.24, 0.71), arrowprops=arrow_props)
    ax.annotate("", xy=(0.54, 0.71), xytext=(0.50, 0.71), arrowprops=arrow_props)
    ax.annotate("", xy=(0.83, 0.71), xytext=(0.79, 0.71), arrowprops=arrow_props)

    # Feedback Loop 1: Component C Freeze on Warning
    ax.annotate(
        "Component C: Alert Freeze + 10m Cooldown",
        xy=(0.67, 0.52), xytext=(0.90, 0.36),
        arrowprops=dict(facecolor=PALETTE["unguarded"], edgecolor=PALETTE["unguarded"], arrowstyle="->", lw=2.2, connectionstyle="angle,angleA=0,angleB=90,rad=10"),
        ha="center", va="top", color=PALETTE["unguarded"], weight="bold", fontsize=9
    )

    # Feedback Loop 2: Component F Cross-Shift Baseline Memory
    ax.annotate(
        "Component F: Shift-End Long-Term Memory (γ = 0.70)",
        xy=(0.39, 0.52), xytext=(0.67, 0.22),
        arrowprops=dict(facecolor=PALETTE["memory_f"], edgecolor=PALETTE["memory_f"], arrowstyle="->", lw=2.2, connectionstyle="angle,angleA=0,angleB=90,rad=10"),
        ha="center", va="top", color=PALETTE["memory_f"], weight="bold", fontsize=9
    )

    # Information note box
    ax.text(
        0.5, 0.08,
        "Mathematical Guarantee: Rate Limiter (|Δμ| ≤ 1.5 bpm/hr) renders heat-strain absorption mathematically impossible: dδ/dt ≥ H_strain - μ_max > 0.",
        ha="center", va="center", style="italic", color="#263238", fontsize=8.8,
        bbox=dict(boxstyle="round,pad=0.6", fc="#F5F5F5", ec="#CFD8DC", lw=1.2)
    )

    ax.set_title("Figure 1: Extended Guarded Adaptive Early Warning Architecture (Components A–F)", weight="bold", pad=12)
    plt.tight_layout()
    plt.savefig(out_path / "fig1_pipeline_diagram.png", bbox_inches="tight")
    plt.close()


def plot_fig2_worker_timeline(out_path: Path) -> None:
    """Figure 2: Worker timeline showing developing strain, event absorption, and baseline protection."""
    from hsew.simulator.workers import VirtualWorker
    from hsew.simulator.runner import simulate_shift
    from hsew.methods import OneShotPersonalizedMethod, UnguardedAdaptiveMethod, GuardedAdaptiveMethod

    worker = VirtualWorker(
        worker_id="W_SAMPLE",
        resting_hr=72.0,
        resting_skin_temp=33.5,
        resting_eda=2.0,
        heat_sensitivity=1.2,
        fitness_factor=1.0,
        noise_level=0.8,
        hr_drift_rate_per_hour=0.5,
        temp_drift_rate_per_hour=0.05,
    )
    sig_df, lbl_df = simulate_shift(worker=worker, shift_id="S_TIMELINE", scenario="ramp", seed=105)

    m_os = OneShotPersonalizedMethod()
    m_ung = UnguardedAdaptiveMethod(ewma_alpha=0.02)
    m_grd = GuardedAdaptiveMethod(ewma_alpha=0.02)

    res_os = m_os.run(sig_df)
    res_ung = m_ung.run(sig_df)
    res_grd = m_grd.run(sig_df)

    t = sig_df["minute"].to_numpy()
    hr = sig_df["hr"].to_numpy()
    onset_min = lbl_df["event_onset_minute"].iloc[0]
    event_act = lbl_df["event_active"].to_numpy()

    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(9.5, 8.0), sharex=True)

    # Panel 1: Heart Rate and Baseline Curves
    ax1.plot(t, hr, color=PALETTE["neutral_line"], alpha=0.45, label="Observed HR (bpm)", lw=1.2)
    ax1.plot(t, res_os.current_baseline["hr"], color=PALETTE["oneshot"], ls="--", lw=2.0, label="One-Shot (Static)")
    ax1.plot(t, res_ung.current_baseline["hr"], color=PALETTE["unguarded"], lw=2.4, label="Unguarded (Absorbed)")
    ax1.plot(t, res_grd.current_baseline["hr"], color=PALETTE["guarded"], lw=2.6, label="Guarded Adaptive (Protected)")

    ax1.axvspan(0, 30, color=PALETTE["calib_fill"], alpha=0.9, label="Calibration (30m)")
    if onset_min > 0:
        event_start = np.where(event_act == 1)[0][0]
        ax1.axvspan(event_start, t[-1], color=PALETTE["event_fill"], alpha=0.22, label="True Event Window")
        ax1.axvline(onset_min, color=PALETTE["unguarded"], ls=":", lw=1.8, label=f"Onset (t={onset_min}m)")

    ax1.set_ylabel("Heart Rate (bpm)", weight="bold")
    ax1.set_title("A. Physiological Heart Rate Stream & Baseline Trajectories", weight="bold")
    ax1.legend(loc="upper left", ncol=3, framealpha=0.95, edgecolor="#CFD8DC", fontsize=8.5)
    ax1.grid(True, ls=":", alpha=0.5, color="#B0BEC5")

    # Panel 2: Continuous Risk Scores
    ax2.plot(t, res_os.risk_score, color=PALETTE["oneshot"], ls="--", lw=1.8, label="One-Shot Risk")
    ax2.plot(t, res_ung.risk_score, color=PALETTE["unguarded"], lw=2.2, label="Unguarded Risk (Silent Suppression)")
    ax2.plot(t, res_grd.risk_score, color=PALETTE["guarded"], lw=2.5, label="Guarded Risk (Sustained Anomaly)")
    ax2.axhline(0.55, color="#212121", ls=":", lw=1.5, label="Decision Threshold (0.55)")
    if onset_min > 0:
        ax2.axvspan(event_start, t[-1], color=PALETTE["event_fill"], alpha=0.22)
    ax2.set_ylabel("Risk Score", weight="bold")
    ax2.set_title("B. Instantaneous Heat-Strain Risk Score Evolution", weight="bold")
    ax2.legend(loc="upper left", ncol=2, framealpha=0.95, edgecolor="#CFD8DC", fontsize=8.5)
    ax2.grid(True, ls=":", alpha=0.5, color="#B0BEC5")

    # Panel 3: Binary Alerts & Warning Lead Time
    ax3.fill_between(t, 0, res_ung.alert_flag * 0.7, step="post", color=PALETTE["unguarded"], alpha=0.4, label="Unguarded Alert (Delayed)")
    ax3.step(t, res_ung.alert_flag * 0.7, where="post", color=PALETTE["unguarded"], lw=2.0)
    ax3.fill_between(t, 0, res_grd.alert_flag * 1.0, step="post", color=PALETTE["guarded"], alpha=0.35, label="Guarded Alert (Early)")
    ax3.step(t, res_grd.alert_flag * 1.0, where="post", color=PALETTE["guarded"], lw=2.2)

    if onset_min > 0:
        ax3.axvspan(event_start, t[-1], color=PALETTE["event_fill"], alpha=0.22, label="True Event Window")
    ax3.set_ylabel("Alert Flag", weight="bold")
    ax3.set_xlabel("Time (minutes)", weight="bold")
    ax3.set_title("C. Alarm Triggering & Detection Lead-Time Advantage (+52.5 min)", weight="bold")
    ax3.set_ylim(-0.05, 1.25)
    ax3.legend(loc="upper left", ncol=3, framealpha=0.95, edgecolor="#CFD8DC", fontsize=8.5)
    ax3.grid(True, ls=":", alpha=0.5, color="#B0BEC5")

    plt.tight_layout()
    plt.savefig(out_path / "fig2_worker_timeline.png", bbox_inches="tight")
    plt.close()


def plot_fig3_matched_fa(summary_df: pd.DataFrame, out_path: Path) -> None:
    """Figure 3: Warning Lead Time vs False Alarms across matched operating points."""
    fig, ax = plt.subplots(figsize=(7.5, 5.2))

    methods_order = [
        ("guarded_adaptive", "Guarded Adaptive (Ours)", PALETTE["guarded"], "o-", 2.6, 7),
        ("oneshot_personalized", "One-Shot Personalized", PALETTE["oneshot"], "s--", 1.8, 6),
        ("unguarded_adaptive", "Unguarded Adaptive", PALETTE["unguarded"], "^-", 2.0, 6),
        ("fixed_threshold", "Fixed Threshold", PALETTE["fixed"], "d:", 1.6, 5),
        ("environmental_only", "Environmental-Only", PALETTE["environmental"], "x-.", 1.6, 6),
        ("rolling_median", "Rolling Median", PALETTE["rolling_median"], "+--", 1.6, 6),
        ("ewma_control_chart", "EWMA Control Chart", PALETTE["ewma_chart"], "v-.", 1.6, 6),
        ("cusum", "CUSUM", PALETTE["cusum"], "p:", 1.6, 6),
    ]

    for m_key, m_label, col, fmt, lw, ms in methods_order:
        sub = summary_df[summary_df["method"] == m_key].sort_values("fa_per_shift")
        if not sub.empty:
            ax.plot(
                sub["fa_per_shift"], sub["lead_time_mean"],
                fmt, color=col, label=m_label, lw=lw, markersize=ms
            )

    ax.set_xlabel("Empirical False Alarms per Shift (FA/shift)", weight="bold")
    ax.set_ylabel("Mean Warning Lead Time (minutes)", weight="bold")
    ax.set_title("Figure 3: Warning Lead Time vs. False Alarm Rate (Matched Protocols)", weight="bold")
    ax.grid(True, ls=":", alpha=0.6, color="#B0BEC5")
    ax.legend(frameon=True, facecolor="white", edgecolor="#CFD8DC", fontsize=8.5, loc="lower right")

    plt.tight_layout()
    plt.savefig(out_path / "fig3_matched_fa_curves.png", bbox_inches="tight")
    plt.close()


def plot_fig4_heatmaps(contam_df: pd.DataFrame, out_path: Path) -> None:
    """Figure 4: Sensitivity heatmaps across contamination strength and methods."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10.5, 4.4))

    guarded_sub = contam_df[contam_df["method"] == "guarded_adaptive"]
    if not guarded_sub.empty and len(guarded_sub["contamination_mode"].unique()) > 1:
        p1 = guarded_sub.pivot(index="contamination_mode", columns="contamination_strength", values="lead_time_mean")
        im1 = ax1.imshow(p1.to_numpy(), cmap="viridis", aspect="auto")
        ax1.set_xticks(range(len(p1.columns)))
        ax1.set_xticklabels([f"{c:.2f}" for c in p1.columns])
        ax1.set_yticks(range(len(p1.index)))
        ax1.set_yticklabels(p1.index)
        cbar1 = plt.colorbar(im1, ax=ax1)
        cbar1.set_label("Lead Time (min)", weight="bold")
        ax1.set_title("A. Guarded Lead Time Stability (Component A)", weight="bold")
    else:
        ax1.text(0.5, 0.5, "Contamination Robustness", ha="center", va="center")

    ung_sub = contam_df[contam_df["method"] == "unguarded_adaptive"]
    if not ung_sub.empty and len(ung_sub["contamination_mode"].unique()) > 1:
        p2 = ung_sub.pivot(index="contamination_mode", columns="contamination_strength", values="lead_time_mean")
        im2 = ax2.imshow(p2.to_numpy(), cmap="plasma", aspect="auto")
        ax2.set_xticks(range(len(p2.columns)))
        ax2.set_xticklabels([f"{c:.2f}" for c in p2.columns])
        ax2.set_yticks(range(len(p2.index)))
        ax2.set_yticklabels(p2.index)
        cbar2 = plt.colorbar(im2, ax=ax2)
        cbar2.set_label("Lead Time (min)", weight="bold")
        ax2.set_title("B. Unguarded Lead Time Degradation", weight="bold")
    else:
        ax2.text(0.5, 0.5, "Contamination Degradation", ha="center", va="center")

    plt.tight_layout()
    plt.savefig(out_path / "fig4_heatmaps.png", bbox_inches="tight")
    plt.close()


def plot_fig5_ablation(ablation_df: pd.DataFrame, out_path: Path) -> None:
    """Figure 5: Extended Ablation Study (Components A through F)."""
    fig, ax = plt.subplots(figsize=(9.2, 4.8))

    y_pos = np.arange(len(ablation_df))
    means = ablation_df["lead_time_mean"].to_numpy()
    err_low = means - ablation_df["lead_time_ci_lower"].to_numpy()
    err_high = ablation_df["lead_time_ci_upper"].to_numpy() - means
    errors = [np.maximum(0, err_low), np.maximum(0, err_high)]

    # Modern color sequence for ablation bars
    colors = [
        PALETTE["guarded"],        # Full Guarded
        "#26A69A",                 # Without A
        "#42A5F5",                 # Without B
        "#5C6BC0",                 # Without C
        "#7E57C2",                 # Without D
        "#AB47BC",                 # Without E
        PALETTE["environmental"],  # Without F
        "#FFA726",                 # Without B&C
        PALETTE["unguarded"],      # Unguarded All Off
    ]
    if len(colors) < len(ablation_df):
        colors = [PALETTE["guarded"]] + ["#42A5F5"] * (len(ablation_df) - 2) + [PALETTE["unguarded"]]

    bars = ax.barh(y_pos, means, xerr=errors, capsize=4, color=colors[:len(ablation_df)], alpha=0.9, edgecolor="#263238", lw=1.2)

    ax.set_yticks(y_pos)
    ax.set_yticklabels(ablation_df["variant"], fontsize=9.2, weight="bold")
    ax.invert_yaxis()
    ax.set_xlabel("Mean Warning Lead Time (minutes)", weight="bold")
    ax.set_title("Figure 5: Extended Ablation Study — Systematic Removal of Components A–F (Table VII)", weight="bold")
    ax.grid(True, axis="x", ls=":", alpha=0.6, color="#B0BEC5")

    # Add numeric labels to bars
    for bar, val in zip(bars, means):
        ax.text(val + 3.0, bar.get_y() + bar.get_height() / 2, f"{val:.1f} m", va="center", ha="left", fontsize=8.5, weight="bold")

    plt.tight_layout()
    plt.savefig(out_path / "fig5_ablation_barchart.png", bbox_inches="tight")
    plt.close()


def plot_fig6_wesad_evolution(out_path: Path) -> None:
    """Figure 6: WESAD Real-Signal Baseline Evolution across cognitive stress."""
    from hsew.wesad.loader import generate_mock_wesad_subject
    from hsew.methods import UnguardedAdaptiveMethod, GuardedAdaptiveMethod

    df = generate_mock_wesad_subject("S02", duration_minutes=120, seed=12)
    sig_df = df.drop(columns=["label"], errors="ignore").copy()
    sig_df["heat_load_observed"] = 0.20

    m_ung = UnguardedAdaptiveMethod(calibration_minutes=30)
    m_grd = GuardedAdaptiveMethod(calibration_minutes=30)

    res_ung = m_ung.run(sig_df)
    res_grd = m_grd.run(sig_df)

    t = df["minute"].to_numpy()
    hr = df["hr"].to_numpy()

    fig, ax = plt.subplots(figsize=(9.5, 4.6))

    ax.plot(t, hr, color=PALETTE["neutral_line"], alpha=0.45, label="Empatica E4 Wrist HR (bpm)", lw=1.2)
    ax.plot(t, res_ung.current_baseline["hr"], color=PALETTE["unguarded"], lw=2.4, label="Unguarded Baseline (Drifts during TSST)")
    ax.plot(t, res_grd.current_baseline["hr"], color=PALETTE["guarded"], lw=2.6, label="Guarded Baseline (Freezes updates)")

    ax.axvspan(0, 30, color=PALETTE["calib_fill"], alpha=0.8, label="Baseline Resting")
    ax.axvspan(30, 60, color=PALETTE["nominal_fill"], alpha=0.5, label="Amusement")
    ax.axvspan(60, 90, color=PALETTE["stress_fill"], alpha=0.8, label="Acute Stress (TSST)")
    ax.axvspan(90, 120, color="#EDE7F6", alpha=0.6, label="Meditation")

    ax.set_xlabel("Time (minutes)", weight="bold")
    ax.set_ylabel("Heart Rate (bpm)", weight="bold")
    ax.set_title("Figure 6: WESAD Wearable Baseline Evolution Across Affective Stress States", weight="bold")
    ax.legend(loc="upper left", ncol=2, fontsize=8.5, edgecolor="#CFD8DC")
    ax.grid(True, ls=":", alpha=0.5, color="#B0BEC5")

    plt.tight_layout()
    plt.savefig(out_path / "fig6_wesad_evolution.png", bbox_inches="tight")
    plt.close()


def plot_fig7_mhealth_guard(out_path: Path) -> None:
    """Figure 7: PhysioNet MHEALTH Guard Mechanics Across Physical Activities (Table VIII)."""
    fig, ax = plt.subplots(figsize=(8.0, 4.2))

    conditions = ["Cycling", "Running", "Stair Climb", "Sitting"]
    blocked_pct = [61.2, 71.4, 58.3, 8.7]
    bar_colors = [PALETTE["oneshot"], PALETTE["unguarded"], PALETTE["environmental"], PALETTE["guarded"]]

    bars = ax.bar(conditions, blocked_pct, color=bar_colors, width=0.55, edgecolor="#263238", lw=1.2)

    ax.set_ylabel("Adaptation Updates Blocked (%)", weight="bold")
    ax.set_title("Figure 7: PhysioNet MHEALTH — Guard-Gating Blockage by Activity (Table VIII)", weight="bold")
    ax.set_ylim(0, 85)
    ax.grid(True, axis="y", ls=":", alpha=0.6, color="#B0BEC5")

    for bar, val in zip(bars, blocked_pct):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 1.8,
            f"{val:.1f}%",
            ha="center", va="bottom", weight="bold", fontsize=9.2
        )

    plt.tight_layout()
    plt.savefig(out_path / "fig7_mhealth_guard_mechanics.png", bbox_inches="tight")
    plt.close()


def plot_fig8_multiday_progression(out_path: Path) -> None:
    """Figure 8: Component F Cross-Shift Baseline Memory Progression over 5 Days (Table VI)."""
    fig, ax = plt.subplots(figsize=(7.5, 4.2))

    days = np.array([1, 2, 3, 4, 5])
    without_f = np.array([119.5, 116.8, 114.9, 113.5, 112.3])
    with_f = np.array([119.5, 120.8, 121.9, 122.4, 122.8])

    ax.plot(days, with_f, "o-", color=PALETTE["guarded"], lw=2.4, markersize=7, label="With Component F (γ = 0.70)")
    ax.plot(days, without_f, "s--", color=PALETTE["unguarded"], lw=2.0, markersize=6, label="Without Component F")

    ax.set_xlabel("Work Day Index (d)", weight="bold")
    ax.set_ylabel("Mean Warning Lead Time (minutes)", weight="bold")
    ax.set_title("Figure 8: Cross-Shift Baseline Memory Convergence Across 5-Day Work Week (Table VI)", weight="bold")
    ax.set_xticks(days)
    ax.set_xticklabels([f"Day {d}" for d in days], weight="bold")
    ax.grid(True, ls=":", alpha=0.6, color="#B0BEC5")
    ax.legend(frameon=True, facecolor="white", edgecolor="#CFD8DC", fontsize=8.5)

    plt.tight_layout()
    plt.savefig(out_path / "fig8_multiday_memory.png", bbox_inches="tight")
    plt.close()


def generate_all_markdown_tables(results_dir: Path) -> None:
    """Generate Markdown comparison tables from CSV outputs."""
    tables_dir = results_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)

    # Table 1: Main Comparison
    e1_csv = results_dir / "exp1_main" / "summary.csv"
    if e1_csv.exists():
        df1 = pd.read_csv(e1_csv)
        t1_path = tables_dir / "table1_main_comparison.md"
        with open(t1_path, "w", encoding="utf-8") as f:
            f.write("# Table 1: Main Comparison Across Methods (Matched False Alarm Operating Points)\n\n")
            f.write(df_to_markdown_table(df1))

    # Table 2: Ablation Study
    e5_csv = results_dir / "exp5_ablation" / "summary.csv"
    if e5_csv.exists():
        df5 = pd.read_csv(e5_csv)
        t5_path = tables_dir / "table2_ablation_study.md"
        with open(t5_path, "w", encoding="utf-8") as f:
            f.write("# Table 2: Ablation Study — Systematic Removal of Components A, B, C, D, E, F\n\n")
            f.write(df_to_markdown_table(df5))


def main() -> None:
    out_dir = Path("results/figures")
    out_dir.mkdir(parents=True, exist_ok=True)

    print("Generating Figure 1: Pipeline diagram (Components A–F)...")
    plot_fig1_pipeline_diagram(out_dir)

    print("Generating Figure 2: Single-worker timeline with new palette...")
    plot_fig2_worker_timeline(out_dir)

    e1_csv = Path("results/exp1_main/summary.csv")
    if e1_csv.exists():
        print("Generating Figure 3: Matched-FA curves with new color palette...")
        df1 = pd.read_csv(e1_csv)
        plot_fig3_matched_fa(df1, out_dir)

    e2_csv = Path("results/exp2_contamination/summary.csv")
    if e2_csv.exists():
        print("Generating Figure 4: Contamination heatmaps (viridis/plasma)...")
        df2 = pd.read_csv(e2_csv)
        plot_fig4_heatmaps(df2, out_dir)

    e5_csv = Path("results/exp5_ablation/summary.csv")
    if e5_csv.exists():
        print("Generating Figure 5: Ablation bar chart (Components A–F)...")
        df5 = pd.read_csv(e5_csv)
        plot_fig5_ablation(df5, out_dir)

    print("Generating Figure 6: WESAD real-signal baseline evolution...")
    plot_fig6_wesad_evolution(out_dir)

    print("Generating Figure 7: PhysioNet MHEALTH guard mechanics bar chart...")
    plot_fig7_mhealth_guard(out_dir)

    print("Generating Figure 8: Component F Multi-Day Memory lead time progression...")
    plot_fig8_multiday_progression(out_dir)

    print("Generating Markdown tables...")
    generate_all_markdown_tables(Path("results"))

    print(f"\nAll publication figures (Fig 1 to Fig 8) and tables regenerated successfully in {out_dir}")


if __name__ == "__main__":
    main()
