"""Early warning methods subpackage."""

from typing import Any, Dict, Optional

from hsew.methods.base import BaseMethod, MethodResult, apply_alert_logic
from hsew.methods.baselines import (
    FixedThresholdMethod,
    EnvironmentalOnlyMethod,
    OneShotPersonalizedMethod,
    UnguardedAdaptiveMethod,
)
from hsew.methods.guarded import GuardedAdaptiveMethod, evaluate_calibration_quality
from hsew.methods.spc import (
    RollingMedianMethod,
    EWMAControlChartMethod,
    CUSUMMethod,
)


def get_method(
    name: str,
    config: Optional[Dict[str, Any]] = None,
    **kwargs,
) -> BaseMethod:
    """Factory function to instantiate an early warning method by name."""
    cfg = config or {}
    common_cfg = cfg.get("common", {})
    k = common_cfg.get("persistence_k", 3)
    hyst = common_cfg.get("hysteresis_ratio", 0.8)
    cooldown = common_cfg.get("cooldown_minutes", 10)

    method_key = name.lower()

    if method_key in ("fixed", "fixed_threshold"):
        sub_cfg = cfg.get("fixed_threshold", {})
        return FixedThresholdMethod(
            hr_threshold=sub_cfg.get("hr_threshold", 110.0),
            temp_threshold=sub_cfg.get("temp_threshold", 36.0),
            heat_load_threshold=sub_cfg.get("heat_load_threshold", 0.70),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("env_only", "environmental_only"):
        sub_cfg = cfg.get("environmental_only", {})
        return EnvironmentalOnlyMethod(
            threshold=sub_cfg.get("heat_load_threshold", 0.65),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("oneshot", "oneshot_personalized"):
        sub_cfg = cfg.get("oneshot_personalized", {})
        weights = sub_cfg.get("weights", {})
        return OneShotPersonalizedMethod(
            calibration_minutes=sub_cfg.get("calibration_minutes", 30),
            w_hr=weights.get("hr", 0.5),
            w_temp=weights.get("temp", 0.3),
            w_heat=weights.get("heat_load", 0.2),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("unguarded", "unguarded_adaptive"):
        sub_cfg = cfg.get("unguarded_adaptive", {})
        weights = sub_cfg.get("weights", {})
        return UnguardedAdaptiveMethod(
            calibration_minutes=sub_cfg.get("calibration_minutes", 30),
            ewma_alpha=sub_cfg.get("ewma_alpha", 0.02),
            w_hr=weights.get("hr", 0.5),
            w_temp=weights.get("temp", 0.3),
            w_heat=weights.get("heat_load", 0.2),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("guarded", "guarded_adaptive"):
        sub_cfg = cfg.get("guarded_adaptive", {})
        weights = sub_cfg.get("weights", {})
        return GuardedAdaptiveMethod(
            calibration_minutes=sub_cfg.get("calibration_minutes", 30),
            ewma_alpha=sub_cfg.get("ewma_alpha", 0.02),
            w_hr=weights.get("hr", 0.5),
            w_temp=weights.get("temp", 0.3),
            w_heat=weights.get("heat_load", 0.2),
            use_quality_score=sub_cfg.get("use_quality_score", True),
            use_update_gate=sub_cfg.get("use_update_gate", True),
            use_freeze_on_warning=sub_cfg.get("use_freeze_on_warning", True),
            use_rate_limiter=sub_cfg.get("use_rate_limiter", True),
            use_uncertainty_scale=sub_cfg.get("use_uncertainty_scale", True),
            use_cross_shift_memory=sub_cfg.get("use_cross_shift_memory", False),
            gate_max_risk=sub_cfg.get("gate_max_risk", 0.35),
            gate_max_heat_load=sub_cfg.get("gate_max_heat_load", 0.50),
            drift_cap_hr_per_hour=sub_cfg.get("drift_cap_hr_per_hour", 1.5),
            drift_cap_temp_per_hour=sub_cfg.get("drift_cap_temp_per_hour", 0.15),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("rolling_median", "rolling"):
        sub_cfg = cfg.get("robust_comparators", {})
        return RollingMedianMethod(
            window_size=sub_cfg.get("rolling_median_window", 60),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("ewma_chart", "ewma_control_chart"):
        sub_cfg = cfg.get("robust_comparators", {})
        return EWMAControlChartMethod(
            lambd=sub_cfg.get("ewma_control_chart_lambda", 0.05),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    elif method_key in ("cusum",):
        sub_cfg = cfg.get("robust_comparators", {})
        return CUSUMMethod(
            k=sub_cfg.get("cusum_k", 0.5),
            h=sub_cfg.get("cusum_h", 4.0),
            persistence_k=k,
            hysteresis_ratio=hyst,
            cooldown_minutes=cooldown,
            **kwargs,
        )

    else:
        raise ValueError(f"Unknown method name: {name}")


__all__ = [
    "BaseMethod",
    "MethodResult",
    "apply_alert_logic",
    "FixedThresholdMethod",
    "EnvironmentalOnlyMethod",
    "OneShotPersonalizedMethod",
    "UnguardedAdaptiveMethod",
    "GuardedAdaptiveMethod",
    "evaluate_calibration_quality",
    "RollingMedianMethod",
    "EWMAControlChartMethod",
    "CUSUMMethod",
    "get_method",
]
