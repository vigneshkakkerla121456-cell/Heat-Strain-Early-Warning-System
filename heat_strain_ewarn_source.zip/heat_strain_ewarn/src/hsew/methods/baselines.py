"""Standard early warning baseline methods: Fixed, Environmental-Only, One-Shot, and Unguarded Adaptive."""

from typing import Any, Dict, Optional
import numpy as np
import pandas as pd
from scipy import stats

from hsew.methods.base import BaseMethod, MethodResult, apply_alert_logic


class FixedThresholdMethod(BaseMethod):
    """Universal threshold method using non-personalized industrial/clinical limits."""

    def __init__(
        self,
        name: str = "fixed_threshold",
        hr_threshold: float = 110.0,
        temp_threshold: float = 36.0,
        heat_load_threshold: float = 0.70,
        threshold: float = 0.75,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.hr_threshold = hr_threshold
        self.temp_threshold = temp_threshold
        self.heat_load_threshold = heat_load_threshold

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        hr = signals_df["hr"].to_numpy(dtype=float)
        temp = signals_df["skin_temp"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)

        # Normalized fixed strain score
        hr_norm = np.clip((hr - 75.0) / (self.hr_threshold - 75.0), 0.0, 1.5)
        temp_norm = np.clip((temp - 33.5) / (self.temp_threshold - 33.5), 0.0, 1.5)
        heat_norm = np.clip(heat / self.heat_load_threshold, 0.0, 1.5)

        # Composite risk score is the maximum of the physiological and ambient drives
        risk = 0.45 * np.nan_to_num(hr_norm, nan=0.0) + \
               0.35 * np.nan_to_num(temp_norm, nan=0.0) + \
               0.20 * np.nan_to_num(heat_norm, nan=0.0)

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={
                "hr": np.full(n, 75.0),
                "skin_temp": np.full(n, 33.5),
            },
            metadata={"threshold_used": thresh},
        )


class EnvironmentalOnlyMethod(BaseMethod):
    """Comparator alerting strictly on environmental heat-load index without physiological data."""

    def __init__(
        self,
        name: str = "environmental_only",
        threshold: float = 0.65,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)
        risk = np.nan_to_num(heat, nan=0.0)

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={},
            metadata={"threshold_used": thresh},
        )


class OneShotPersonalizedMethod(BaseMethod):
    """Personalized baseline extracted robustly during calibration and frozen for the shift."""

    def __init__(
        self,
        name: str = "oneshot_personalized",
        calibration_minutes: int = 30,
        w_hr: float = 0.50,
        w_temp: float = 0.30,
        w_heat: float = 0.20,
        threshold: float = 0.55,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.calibration_minutes = calibration_minutes
        self.w_hr = w_hr
        self.w_temp = w_temp
        self.w_heat = w_heat

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        cal_len = min(self.calibration_minutes, n)

        hr = signals_df["hr"].to_numpy(dtype=float)
        temp = signals_df["skin_temp"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)

        # Calibration window robust statistics (median and MAD)
        cal_hr = hr[:cal_len][~np.isnan(hr[:cal_len])]
        cal_temp = temp[:cal_len][~np.isnan(temp[:cal_len])]

        hr_base = float(np.median(cal_hr)) if len(cal_hr) > 0 else 72.0
        hr_mad = float(stats.median_abs_deviation(cal_hr, scale="normal")) if len(cal_hr) > 3 else 3.0
        hr_scale = max(hr_mad * 3.0, 10.0)

        temp_base = float(np.median(cal_temp)) if len(cal_temp) > 0 else 33.5
        temp_mad = float(stats.median_abs_deviation(cal_temp, scale="normal")) if len(cal_temp) > 3 else 0.2
        temp_scale = max(temp_mad * 3.0, 0.8)

        # Deviation from frozen baseline
        hr_dev = np.clip((hr - hr_base) / hr_scale, 0.0, 2.0)
        temp_dev = np.clip((temp - temp_base) / temp_scale, 0.0, 2.0)
        heat_dev = np.clip(heat, 0.0, 1.0)

        risk = (
            self.w_hr * np.nan_to_num(hr_dev, nan=0.0) +
            self.w_temp * np.nan_to_num(temp_dev, nan=0.0) +
            self.w_heat * np.nan_to_num(heat_dev, nan=0.0)
        )

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={
                "hr": np.full(n, hr_base),
                "skin_temp": np.full(n, temp_base),
            },
            metadata={
                "hr_base": hr_base,
                "temp_base": temp_base,
                "hr_scale": hr_scale,
                "temp_scale": temp_scale,
                "threshold_used": thresh,
            },
        )


class UnguardedAdaptiveMethod(BaseMethod):
    """Adaptive baseline updating continuously via EWMA without safeguards."""

    def __init__(
        self,
        name: str = "unguarded_adaptive",
        calibration_minutes: int = 30,
        ewma_alpha: float = 0.02,
        w_hr: float = 0.50,
        w_temp: float = 0.30,
        w_heat: float = 0.20,
        threshold: float = 0.55,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.calibration_minutes = calibration_minutes
        self.ewma_alpha = ewma_alpha
        self.w_hr = w_hr
        self.w_temp = w_temp
        self.w_heat = w_heat

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        cal_len = min(self.calibration_minutes, n)

        hr = signals_df["hr"].to_numpy(dtype=float)
        temp = signals_df["skin_temp"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)
        qflags = signals_df["quality_flag"].to_numpy(dtype=int)

        # Calibration window initial baselines
        cal_hr = hr[:cal_len][~np.isnan(hr[:cal_len])]
        cal_temp = temp[:cal_len][~np.isnan(temp[:cal_len])]

        curr_hr_base = float(np.median(cal_hr)) if len(cal_hr) > 0 else 72.0
        hr_mad = float(stats.median_abs_deviation(cal_hr, scale="normal")) if len(cal_hr) > 3 else 3.0
        hr_scale = max(hr_mad * 3.0, 10.0)

        curr_temp_base = float(np.median(cal_temp)) if len(cal_temp) > 0 else 33.5
        temp_mad = float(stats.median_abs_deviation(cal_temp, scale="normal")) if len(cal_temp) > 3 else 0.2
        temp_scale = max(temp_mad * 3.0, 0.8)

        hr_baseline_series = np.zeros(n, dtype=float)
        temp_baseline_series = np.zeros(n, dtype=float)
        risk = np.zeros(n, dtype=float)

        for t in range(n):
            hr_baseline_series[t] = curr_hr_base
            temp_baseline_series[t] = curr_temp_base

            # Compute current risk deviation
            hr_t = hr[t] if not np.isnan(hr[t]) else curr_hr_base
            temp_t = temp[t] if not np.isnan(temp[t]) else curr_temp_base
            heat_t = heat[t] if not np.isnan(heat[t]) else 0.0

            z_hr = np.clip((hr_t - curr_hr_base) / hr_scale, 0.0, 2.0)
            z_temp = np.clip((temp_t - curr_temp_base) / temp_scale, 0.0, 2.0)

            risk[t] = (
                self.w_hr * z_hr +
                self.w_temp * z_temp +
                self.w_heat * np.clip(heat_t, 0.0, 1.0)
            )

            # Continuous unguarded update after calibration period
            if t >= cal_len and qflags[t] == 1:
                if not np.isnan(hr[t]):
                    curr_hr_base = (1.0 - self.ewma_alpha) * curr_hr_base + self.ewma_alpha * hr[t]
                if not np.isnan(temp[t]):
                    curr_temp_base = (1.0 - self.ewma_alpha) * curr_temp_base + self.ewma_alpha * temp[t]

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={
                "hr": hr_baseline_series,
                "skin_temp": temp_baseline_series,
            },
            metadata={
                "hr_scale": hr_scale,
                "temp_scale": temp_scale,
                "threshold_used": thresh,
            },
        )
