"""Base interfaces, data structures, and alert logic for early warning methods."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
import numpy as np
import pandas as pd


@dataclass
class MethodResult:
    """Standardized output of any early warning method.

    Attributes
    ----------
    risk_score : np.ndarray
        Per-minute risk score (higher indicates greater strain risk).
    alert_flag : np.ndarray
        Per-minute binary alert flag (1 for alert active, 0 otherwise).
    current_baseline : Dict[str, np.ndarray]
        Per-minute baseline trajectory for tracked signals (e.g. 'hr', 'temp').
    metadata : Dict[str, Any]
        Method-specific diagnostics (e.g., quality score, gate status, uncertainty).
    """
    risk_score: np.ndarray
    alert_flag: np.ndarray
    current_baseline: Dict[str, np.ndarray] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


def apply_alert_logic(
    risk_score: np.ndarray,
    threshold: float,
    persistence_k: int = 3,
    hysteresis_ratio: float = 0.8,
) -> np.ndarray:
    """Convert a continuous risk score time series into binary alerts.

    Parameters
    ----------
    risk_score : np.ndarray
        Continuous per-minute risk index.
    threshold : float
        Decision threshold for declaring an alert.
    persistence_k : int
        Number of consecutive minutes risk must equal or exceed threshold before alert triggers.
    hysteresis_ratio : float
        Fraction of threshold below which risk must fall before an active alert is cleared.

    Returns
    -------
    alert_flag : np.ndarray
        Binary 0/1 array of length N.
    """
    n = len(risk_score)
    alerts = np.zeros(n, dtype=int)
    clear_threshold = threshold * hysteresis_ratio

    is_alerting = False
    consecutive_high_count = 0

    for t in range(n):
        val = risk_score[t]
        if np.isnan(val):
            # Missing reading doesn't trigger new alert; if alerting, maintains state
            consecutive_high_count = 0
            if is_alerting:
                alerts[t] = 1
            continue

        if not is_alerting:
            if val >= threshold:
                consecutive_high_count += 1
                if consecutive_high_count >= persistence_k:
                    is_alerting = True
                    alerts[t] = 1
                    consecutive_high_count = 0
            else:
                consecutive_high_count = 0
        else:
            if val < clear_threshold:
                is_alerting = False
                consecutive_high_count = 0
                alerts[t] = 0
            else:
                alerts[t] = 1

    return alerts


class BaseMethod(ABC):
    """Abstract base class for all early warning algorithms.

    Guarantees strict signal isolation: methods never receive or inspect event labels.
    """

    def __init__(
        self,
        name: str,
        threshold: float = 0.5,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        self.name = name
        self.threshold = threshold
        self.persistence_k = persistence_k
        self.hysteresis_ratio = hysteresis_ratio
        self.cooldown_minutes = cooldown_minutes

    def validate_input(self, signals_df: pd.DataFrame) -> None:
        """Ensure input DataFrame contains only observable signals and zero label leakage."""
        forbidden_terms = {"event", "onset", "label", "strain"}
        for col in signals_df.columns:
            for term in forbidden_terms:
                if term in col.lower():
                    raise ValueError(
                        f"Label leakage violation: column '{col}' is not permitted in algorithm input."
                    )

    @abstractmethod
    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        """Run the detection algorithm on an observable signals DataFrame.

        Parameters
        ----------
        signals_df : pd.DataFrame
            Observable time series for one shift with columns:
            minute, hr, skin_temp, eda, heat_load_observed, quality_flag.
        threshold : float, optional
            Override threshold (e.g. during matched-FA threshold sweeps).

        Returns
        -------
        MethodResult
            Contains per-minute risk_score, alert_flag, current_baseline, and metadata.
        """
        pass
