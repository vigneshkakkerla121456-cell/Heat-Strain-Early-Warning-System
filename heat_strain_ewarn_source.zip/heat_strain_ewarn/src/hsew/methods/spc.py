"""Statistical Process Control (SPC) and robust baseline comparators."""

from typing import Any, Dict, Optional
import numpy as np
import pandas as pd
from scipy import stats

from hsew.methods.base import BaseMethod, MethodResult, apply_alert_logic


class RollingMedianMethod(BaseMethod):
    """Robust rolling window median and MAD baseline method."""

    def __init__(
        self,
        name: str = "rolling_median",
        window_size: int = 60,
        w_hr: float = 0.50,
        w_temp: float = 0.30,
        w_heat: float = 0.20,
        threshold: float = 0.55,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.window_size = window_size
        self.w_hr = w_hr
        self.w_temp = w_temp
        self.w_heat = w_heat

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        hr = signals_df["hr"].to_numpy(dtype=float)
        temp = signals_df["skin_temp"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)

        hr_base = np.zeros(n, dtype=float)
        temp_base = np.zeros(n, dtype=float)
        risk = np.zeros(n, dtype=float)

        # Initial baseline from first available values
        init_hr = np.nanmedian(hr[:30]) if not np.isnan(hr[:30]).all() else 72.0
        init_temp = np.nanmedian(temp[:30]) if not np.isnan(temp[:30]).all() else 33.5

        for t in range(n):
            w_start = max(0, t - self.window_size + 1)
            win_hr = hr[w_start:t+1][~np.isnan(hr[w_start:t+1])]
            win_temp = temp[w_start:t+1][~np.isnan(temp[w_start:t+1])]

            med_hr = float(np.median(win_hr)) if len(win_hr) > 0 else init_hr
            med_temp = float(np.median(win_temp)) if len(win_temp) > 0 else init_temp

            hr_base[t] = med_hr
            temp_base[t] = med_temp

            hr_t = hr[t] if not np.isnan(hr[t]) else med_hr
            temp_t = temp[t] if not np.isnan(temp[t]) else med_temp
            heat_t = heat[t] if not np.isnan(heat[t]) else 0.0

            z_hr = np.clip((hr_t - med_hr) / 15.0, 0.0, 2.0)
            z_temp = np.clip((temp_t - med_temp) / 1.0, 0.0, 2.0)

            risk[t] = (
                self.w_hr * z_hr +
                self.w_temp * z_temp +
                self.w_heat * np.clip(heat_t, 0.0, 1.0)
            )

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={"hr": hr_base, "skin_temp": temp_base},
            metadata={"threshold_used": thresh},
        )


class EWMAControlChartMethod(BaseMethod):
    """Statistical Process Control (SPC) EWMA control chart comparator."""

    def __init__(
        self,
        name: str = "ewma_control_chart",
        calibration_minutes: int = 30,
        lambd: float = 0.05,
        threshold: float = 0.50,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.calibration_minutes = calibration_minutes
        self.lambd = lambd

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        cal_len = min(self.calibration_minutes, n)
        hr = signals_df["hr"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)

        cal_hr = hr[:cal_len][~np.isnan(hr[:cal_len])]
        mu0 = float(np.mean(cal_hr)) if len(cal_hr) > 0 else 72.0
        sigma0 = float(np.std(cal_hr)) if len(cal_hr) > 3 else 3.0
        sigma0 = max(sigma0, 2.0)

        ewma_stat = 0.0
        risk = np.zeros(n, dtype=float)
        hr_base = np.full(n, mu0)

        for t in range(n):
            hr_t = hr[t] if not np.isnan(hr[t]) else mu0
            heat_t = heat[t] if not np.isnan(heat[t]) else 0.0

            z_t = (hr_t - mu0) / sigma0
            ewma_stat = self.lambd * z_t + (1.0 - self.lambd) * ewma_stat

            # Scaled normalized control statistic
            stat_risk = max(0.0, ewma_stat / 3.0)
            risk[t] = 0.75 * np.clip(stat_risk, 0.0, 1.5) + 0.25 * np.clip(heat_t, 0.0, 1.0)

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={"hr": hr_base},
            metadata={"threshold_used": thresh, "mu0": mu0, "sigma0": sigma0},
        )


class CUSUMMethod(BaseMethod):
    """Tabular Cumulative Sum (CUSUM) control chart comparator for upward mean shifts."""

    def __init__(
        self,
        name: str = "cusum",
        calibration_minutes: int = 30,
        k: float = 0.5,
        h: float = 4.0,
        threshold: float = 0.50,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.calibration_minutes = calibration_minutes
        self.k = k  # allowance / slack parameter
        self.h = h  # decision interval

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        cal_len = min(self.calibration_minutes, n)
        hr = signals_df["hr"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)

        cal_hr = hr[:cal_len][~np.isnan(hr[:cal_len])]
        mu0 = float(np.mean(cal_hr)) if len(cal_hr) > 0 else 72.0
        sigma0 = float(np.std(cal_hr)) if len(cal_hr) > 3 else 3.0
        sigma0 = max(sigma0, 2.0)

        cusum_pos = 0.0
        risk = np.zeros(n, dtype=float)
        hr_base = np.full(n, mu0)

        for t in range(n):
            hr_t = hr[t] if not np.isnan(hr[t]) else mu0
            heat_t = heat[t] if not np.isnan(heat[t]) else 0.0

            z_t = (hr_t - mu0) / sigma0
            cusum_pos = max(0.0, cusum_pos + z_t - self.k)

            # Normalized by decision interval h
            norm_cusum = cusum_pos / max(self.h, 1e-3)
            risk[t] = 0.75 * np.clip(norm_cusum, 0.0, 2.0) + 0.25 * np.clip(heat_t, 0.0, 1.0)

        alerts = apply_alert_logic(
            risk_score=risk,
            threshold=thresh,
            persistence_k=self.persistence_k,
            hysteresis_ratio=self.hysteresis_ratio,
        )

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={"hr": hr_base},
            metadata={"threshold_used": thresh, "mu0": mu0, "sigma0": sigma0},
        )
