"""Guarded Adaptive Early Warning Method with modular ablation components."""

from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple
import numpy as np
import pandas as pd
from scipy import stats

from hsew.methods.base import BaseMethod, MethodResult, apply_alert_logic


@dataclass
class CalibrationQualityResult:
    """Diagnostic outputs from Component A (Calibration Quality Assessment)."""
    quality_score: float         # in [0, 1], where 1 is pristine resting baseline
    slope_hr: float              # bpm / min slope during calibration
    level_penalty: float         # penalty for deviation from plausible resting range
    heat_penalty: float          # penalty for ambient heat during calibration
    missing_fraction: float      # fraction of missing minutes during calibration
    uncertainty_multiplier: float  # factor >= 1.0 to scale baseline dispersion


def evaluate_calibration_quality(
    hr: np.ndarray,
    temp: np.ndarray,
    heat: np.ndarray,
    qflags: np.ndarray,
    cal_len: int = 30,
    prior_hr: float = 72.0,
    prior_temp: float = 33.5,
) -> CalibrationQualityResult:
    """Component A: Compute calibration quality score from first cal_len minutes.

    Evaluates:
    1. Level penalty: resting HR should plausibly be in [55, 90] bpm.
    2. Trend penalty: resting HR/temp should have near-zero slope (not post-exertion recovery or rapid rise).
    3. Heat penalty: calibration should be in cool/ambient conditions.
    4. Missing data penalty: low dropout rate.
    """
    cal_hr = hr[:cal_len]
    cal_temp = temp[:cal_len]
    cal_heat = heat[:cal_len]
    cal_q = qflags[:cal_len]

    valid_mask = (cal_q == 1) & (~np.isnan(cal_hr)) & (~np.isnan(cal_temp))
    n_valid = int(np.sum(valid_mask))
    missing_frac = float(1.0 - (n_valid / max(1, cal_len)))

    if n_valid < 5:
        # Extremely poor / unusable calibration
        return CalibrationQualityResult(
            quality_score=0.1,
            slope_hr=0.0,
            level_penalty=1.0,
            heat_penalty=1.0,
            missing_fraction=missing_frac,
            uncertainty_multiplier=2.5,
        )

    t_valid = np.arange(cal_len)[valid_mask]
    hr_valid = cal_hr[valid_mask]
    temp_valid = cal_temp[valid_mask]
    heat_valid = np.nan_to_num(cal_heat[valid_mask], nan=0.2)

    # 1. Level penalty (distance from normal resting range [60, 85])
    median_hr = float(np.median(hr_valid))
    if median_hr < 55.0:
        level_pen = min(1.0, (55.0 - median_hr) / 15.0)
    elif median_hr > 85.0:
        level_pen = min(1.0, (median_hr - 85.0) / 25.0)
    else:
        level_pen = 0.0

    # 2. Trend / Slope penalty (linear regression on HR)
    slope_hr = 0.0
    if len(t_valid) >= 5:
        res = stats.linregress(t_valid, hr_valid)
        slope_hr = float(res.slope)
    # A slope magnitude > 0.3 bpm/min indicates non-stationary settling/recovery
    trend_pen = float(np.clip(abs(slope_hr) / 0.8, 0.0, 1.0))

    # 3. Heat penalty (ambient heat > 0.35 during calibration)
    mean_heat = float(np.mean(heat_valid))
    heat_pen = float(np.clip((mean_heat - 0.25) / 0.40, 0.0, 1.0))

    # 4. Composite quality score in [0.1, 1.0]
    total_penalty = (
        0.35 * level_pen +
        0.30 * trend_pen +
        0.20 * heat_pen +
        0.15 * min(1.0, missing_frac / 0.3)
    )
    quality = float(np.clip(1.0 - total_penalty, 0.1, 1.0))
    uncertainty_mult = float(1.0 + 1.2 * (1.0 - quality))

    return CalibrationQualityResult(
        quality_score=quality,
        slope_hr=slope_hr,
        level_penalty=level_pen,
        heat_penalty=heat_pen,
        missing_fraction=missing_frac,
        uncertainty_multiplier=uncertainty_mult,
    )


class GuardedAdaptiveMethod(BaseMethod):
    """Proposed Guarded Baseline Adaptation Early Warning Method.

    Features 6 switchable components (A, B, C, D, E, F) for ablation studies:
    - Component A: Calibration quality score & conservative prior fallback.
    - Component B: Update gate (risk, trend, heat, data quality).
    - Component C: Freeze on warning (alert state + cooldown).
    - Component D: Rate limiter / drift cap (bounds max shift/hour).
    - Component E: Uncertainty-aware risk scaling.
    - Component F: Cross-shift baseline memory with gated exponential forgetting.
    """

    def __init__(
        self,
        name: str = "guarded_adaptive",
        calibration_minutes: int = 30,
        ewma_alpha: float = 0.02,
        w_hr: float = 0.50,
        w_temp: float = 0.30,
        w_heat: float = 0.20,
        threshold: float = 0.55,
        persistence_k: int = 3,
        hysteresis_ratio: float = 0.8,
        cooldown_minutes: int = 10,
        # Ablation component toggles:
        use_quality_score: bool = True,       # Component A
        use_update_gate: bool = True,         # Component B
        use_freeze_on_warning: bool = True,   # Component C
        use_rate_limiter: bool = True,        # Component D
        use_uncertainty_scale: bool = True,   # Component E
        use_cross_shift_memory: bool = False, # Component F
        # Gate parameters:
        gate_max_risk: float = 0.35,
        gate_max_heat_load: float = 0.50,
        drift_cap_hr_per_hour: float = 1.5,
        drift_cap_temp_per_hour: float = 0.15,
        prior_hr: float = 72.0,
        prior_temp: float = 33.5,
        long_term_prior_hr: Optional[float] = None,
        memory_gamma: float = 0.70,
        use_spo2: bool = True,
    ):
        super().__init__(
            name=name,
            threshold=threshold,
            persistence_k=persistence_k,
            hysteresis_ratio=hysteresis_ratio,
            cooldown_minutes=cooldown_minutes,
        )
        self.calibration_minutes = calibration_minutes
        self.ewma_alpha = ewma_alpha
        self.w_hr = w_hr
        self.w_temp = w_temp
        self.w_heat = w_heat

        self.use_quality_score = use_quality_score
        self.use_update_gate = use_update_gate
        self.use_freeze_on_warning = use_freeze_on_warning
        self.use_rate_limiter = use_rate_limiter
        self.use_uncertainty_scale = use_uncertainty_scale
        self.use_cross_shift_memory = use_cross_shift_memory
        self.use_spo2 = use_spo2

        self.gate_max_risk = gate_max_risk
        self.gate_max_heat_load = gate_max_heat_load
        self.drift_cap_hr_per_min = drift_cap_hr_per_hour / 60.0
        self.drift_cap_temp_per_min = drift_cap_temp_per_hour / 60.0
        self.prior_hr = prior_hr
        self.prior_temp = prior_temp
        self.long_term_prior_hr = long_term_prior_hr
        self.memory_gamma = memory_gamma

    def run(
        self,
        signals_df: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> MethodResult:
        self.validate_input(signals_df)
        thresh = threshold if threshold is not None else self.threshold

        n = len(signals_df)
        cal_len = min(self.calibration_minutes, n)

        hr = signals_df["hr"].to_numpy(dtype=float)
        temp = signals_df["skin_temp"].to_numpy(dtype=float)
        heat = signals_df["heat_load_observed"].to_numpy(dtype=float)
        qflags = signals_df["quality_flag"].to_numpy(dtype=int)

        # -------------------------------------------------------------
        # Component A & F: Calibration Quality Assessment & Memory Prior
        # -------------------------------------------------------------
        effective_prior_hr = (
            self.long_term_prior_hr
            if (self.use_cross_shift_memory and self.long_term_prior_hr is not None)
            else self.prior_hr
        )

        cal_hr = hr[:cal_len][~np.isnan(hr[:cal_len])]
        cal_temp = temp[:cal_len][~np.isnan(temp[:cal_len])]

        raw_hr_med = float(np.median(cal_hr)) if len(cal_hr) > 0 else effective_prior_hr
        hr_mad = float(stats.median_abs_deviation(cal_hr, scale="normal")) if len(cal_hr) > 3 else 3.0
        raw_hr_scale = max(hr_mad * 3.0, 10.0)

        raw_temp_med = float(np.median(cal_temp)) if len(cal_temp) > 0 else self.prior_temp
        temp_mad = float(stats.median_abs_deviation(cal_temp, scale="normal")) if len(cal_temp) > 3 else 0.2
        raw_temp_scale = max(temp_mad * 3.0, 0.8)

        if self.use_quality_score:
            qual_res = evaluate_calibration_quality(
                hr=hr,
                temp=temp,
                heat=heat,
                qflags=qflags,
                cal_len=cal_len,
                prior_hr=effective_prior_hr,
                prior_temp=self.prior_temp,
            )
            q = qual_res.quality_score
            # Blend empirical baseline with prior based on quality (Component A & F)
            curr_hr_base = q * raw_hr_med + (1.0 - q) * effective_prior_hr
            curr_temp_base = q * raw_temp_med + (1.0 - q) * self.prior_temp
            unc_mult = qual_res.uncertainty_multiplier if self.use_uncertainty_scale else 1.0
        else:
            qual_res = None
            q = 1.0
            curr_hr_base = raw_hr_med
            curr_temp_base = raw_temp_med
            unc_mult = 1.0

        hr_scale = raw_hr_scale * unc_mult
        temp_scale = raw_temp_scale * unc_mult

        # Optional SpO2 channel (Component I)
        has_spo2 = ("spo2" in signals_df.columns) and self.use_spo2
        spo2 = signals_df["spo2"].to_numpy(dtype=float) if has_spo2 else None

        # Containers
        hr_baseline_series = np.zeros(n, dtype=float)
        temp_baseline_series = np.zeros(n, dtype=float)
        risk = np.zeros(n, dtype=float)
        alerts = np.zeros(n, dtype=int)
        update_allowed = np.zeros(n, dtype=bool)

        # Dynamic state tracking
        is_alerting = False
        consecutive_high_count = 0
        cooldown_counter = 0
        clear_threshold = thresh * self.hysteresis_ratio

        for t in range(n):
            hr_baseline_series[t] = curr_hr_base
            temp_baseline_series[t] = curr_temp_base

            # 1. Compute instantaneous deviation risk
            hr_t = hr[t] if not np.isnan(hr[t]) else curr_hr_base
            temp_t = temp[t] if not np.isnan(temp[t]) else curr_temp_base
            heat_t = heat[t] if not np.isnan(heat[t]) else 0.0

            z_hr = np.clip((hr_t - curr_hr_base) / hr_scale, 0.0, 2.0)
            z_temp = np.clip((temp_t - curr_temp_base) / temp_scale, 0.0, 2.0)

            if has_spo2 and not np.isnan(spo2[t]):
                # Component I: Multi-Modal SpO2 Fusion (eq 15)
                # Activates only when SpO2 < 94%, associated with mild hypoxaemia in thermal environments
                r_spo2 = 0.10 * np.clip((94.0 - spo2[t]) / 4.0, 0.0, 2.0)
                risk_t = (
                    0.90 * (self.w_hr * z_hr + self.w_temp * z_temp) +
                    self.w_heat * np.clip(heat_t, 0.0, 1.0) +
                    r_spo2
                )
            else:
                risk_t = (
                    self.w_hr * z_hr +
                    self.w_temp * z_temp +
                    self.w_heat * np.clip(heat_t, 0.0, 1.0)
                )
            risk[t] = risk_t

            # 2. Update Alert State Machine (persistence & hysteresis)
            if not is_alerting:
                if risk_t >= thresh:
                    consecutive_high_count += 1
                    if consecutive_high_count >= self.persistence_k:
                        is_alerting = True
                        alerts[t] = 1
                        consecutive_high_count = 0
                        cooldown_counter = self.cooldown_minutes
                else:
                    consecutive_high_count = 0
            else:
                if risk_t < clear_threshold:
                    is_alerting = False
                    consecutive_high_count = 0
                    alerts[t] = 0
                    cooldown_counter = self.cooldown_minutes
                else:
                    alerts[t] = 1
                    cooldown_counter = self.cooldown_minutes

            # Decrement cooldown counter when not alerting
            if not is_alerting and cooldown_counter > 0:
                cooldown_counter -= 1

            # 3. Adaptation Gating & Update Decision
            if t < cal_len:
                # Still in calibration window: do not update baseline dynamically
                update_allowed[t] = False
                continue

            can_update = (qflags[t] == 1)

            # Component C: Freeze on Warning
            if self.use_freeze_on_warning:
                if is_alerting or cooldown_counter > 0:
                    can_update = False

            # Component B: Update Gate (check risk, heat load, rising trend)
            if self.use_update_gate and can_update:
                if risk_t >= self.gate_max_risk:
                    can_update = False
                elif heat_t >= self.gate_max_heat_load:
                    can_update = False
                elif t >= 5:
                    # Recent 5-minute trend check on HR
                    recent_hr = hr[t-4:t+1]
                    recent_valid = recent_hr[~np.isnan(recent_hr)]
                    if len(recent_valid) >= 3 and (recent_valid[-1] - recent_valid[0]) > 6.0:
                        can_update = False

            update_allowed[t] = can_update

            # 4. Perform Baseline Adaptation
            if can_update:
                # Raw EWMA proposal
                proposed_hr = (1.0 - self.ewma_alpha) * curr_hr_base + self.ewma_alpha * hr_t
                proposed_temp = (1.0 - self.ewma_alpha) * curr_temp_base + self.ewma_alpha * temp_t

                # Component D: Rate Limiter / Drift Cap
                if self.use_rate_limiter:
                    hr_step = np.clip(
                        proposed_hr - curr_hr_base,
                        -self.drift_cap_hr_per_min,
                        self.drift_cap_hr_per_min,
                    )
                    curr_hr_base = curr_hr_base + hr_step

                    temp_step = np.clip(
                        proposed_temp - curr_temp_base,
                        -self.drift_cap_temp_per_min,
                        self.drift_cap_temp_per_min,
                    )
                    curr_temp_base = curr_temp_base + temp_step
                else:
                    curr_hr_base = proposed_hr
                    curr_temp_base = proposed_temp

        # Component F: Cross-Shift Baseline Memory update at shift end
        tail_len = min(60, n)
        if tail_len > 0:
            final_60_allowed = update_allowed[-tail_len:]
            pass_fraction = float(np.mean(final_60_allowed))
        else:
            pass_fraction = 0.0

        anchor_hr = effective_prior_hr
        memory_gated = (pass_fraction >= 0.60)
        if self.use_cross_shift_memory and memory_gated:
            updated_long_term_hr = float(
                self.memory_gamma * anchor_hr + (1.0 - self.memory_gamma) * curr_hr_base
            )
        else:
            updated_long_term_hr = float(anchor_hr)

        return MethodResult(
            risk_score=risk,
            alert_flag=alerts,
            current_baseline={
                "hr": hr_baseline_series,
                "skin_temp": temp_baseline_series,
            },
            metadata={
                "quality_assessment": qual_res,
                "calibration_quality": q,
                "uncertainty_multiplier": unc_mult,
                "hr_scale": hr_scale,
                "temp_scale": temp_scale,
                "update_allowed": update_allowed,
                "threshold_used": thresh,
                "final_hr_baseline": curr_hr_base,
                "final_temp_baseline": curr_temp_base,
                "gate_pass_fraction_final_60": pass_fraction,
                "memory_gated": memory_gated,
                "updated_long_term_hr": updated_long_term_hr,
            },
        )
