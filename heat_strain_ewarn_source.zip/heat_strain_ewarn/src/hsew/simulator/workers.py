"""Virtual worker physiological parameter sampling and representation."""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import numpy as np


@dataclass
class VirtualWorker:
    """Represents an individual virtual worker with personalized baseline parameters.

    All parameters are synthetic research assumptions, not clinically validated limits.
    """

    worker_id: str
    resting_hr: float            # bpm (beats per minute)
    resting_skin_temp: float     # degrees Celsius
    resting_eda: float           # microSiemens
    heat_sensitivity: float      # dimensionless multiplier (how fast signals rise under heat)
    fitness_factor: float        # dimensionless multiplier (higher fitness dampens fatigue/lag)
    noise_level: float           # multiplier for sensor noise
    hr_drift_rate_per_hour: float    # bpm / hour (benign baseline drift)
    temp_drift_rate_per_hour: float  # deg C / hour (benign baseline drift)


def sample_worker(
    worker_id: str,
    rng: np.random.Generator,
    config: Optional[Dict[str, Any]] = None,
) -> VirtualWorker:
    """Sample personalized physiological parameters for a single virtual worker.

    Parameters
    ----------
    worker_id : str
        Unique identifier for the worker.
    rng : np.random.Generator
        Numpy random generator instance for reproducibility.
    config : dict, optional
        Configuration dictionary containing population parameter distributions.

    Returns
    -------
    VirtualWorker
        Instantiated virtual worker.
    """
    cfg = config or {}
    pop_cfg = cfg.get("worker_population", {})
    drift_cfg = cfg.get("drift", {})

    # Resting HR
    hr_mean = pop_cfg.get("resting_hr_mean", 72.0)
    hr_std = pop_cfg.get("resting_hr_std", 8.0)
    hr_min = pop_cfg.get("resting_hr_min", 55.0)
    hr_max = pop_cfg.get("resting_hr_max", 95.0)
    resting_hr = float(np.clip(rng.normal(hr_mean, hr_std), hr_min, hr_max))

    # Resting skin temperature
    temp_mean = pop_cfg.get("resting_skin_temp_mean", 33.5)
    temp_std = pop_cfg.get("resting_skin_temp_std", 0.6)
    temp_min = pop_cfg.get("resting_skin_temp_min", 31.5)
    temp_max = pop_cfg.get("resting_skin_temp_max", 35.0)
    resting_skin_temp = float(np.clip(rng.normal(temp_mean, temp_std), temp_min, temp_max))

    # Resting EDA (log-normal distribution)
    eda_mean = pop_cfg.get("resting_eda_mean", 2.0)
    eda_std = pop_cfg.get("resting_eda_std", 0.8)
    eda_min = pop_cfg.get("resting_eda_min", 0.5)
    eda_max = pop_cfg.get("resting_eda_max", 5.0)
    resting_eda = float(np.clip(rng.normal(eda_mean, eda_std), eda_min, eda_max))

    # Heat sensitivity
    sens_mean = pop_cfg.get("heat_sensitivity_mean", 1.0)
    sens_std = pop_cfg.get("heat_sensitivity_std", 0.25)
    sens_min = pop_cfg.get("heat_sensitivity_min", 0.5)
    sens_max = pop_cfg.get("heat_sensitivity_max", 1.8)
    heat_sensitivity = float(np.clip(rng.normal(sens_mean, sens_std), sens_min, sens_max))

    # Fitness factor
    fit_mean = pop_cfg.get("fitness_factor_mean", 1.0)
    fit_std = pop_cfg.get("fitness_factor_std", 0.2)
    fit_min = pop_cfg.get("fitness_factor_min", 0.6)
    fit_max = pop_cfg.get("fitness_factor_max", 1.5)
    fitness_factor = float(np.clip(rng.normal(fit_mean, fit_std), fit_min, fit_max))

    # Noise level multiplier (typically around 1.0)
    noise_level = float(np.clip(rng.normal(1.0, 0.15), 0.5, 2.0))

    # Drift rates
    hr_drift_base = drift_cfg.get("hr_drift_rate_per_hour", 0.5)
    hr_drift_rate = float(rng.uniform(0.0, 2.0 * hr_drift_base))

    temp_drift_base = drift_cfg.get("temp_drift_rate_per_hour", 0.05)
    temp_drift_rate = float(rng.uniform(0.0, 2.0 * temp_drift_base))

    return VirtualWorker(
        worker_id=worker_id,
        resting_hr=resting_hr,
        resting_skin_temp=resting_skin_temp,
        resting_eda=resting_eda,
        heat_sensitivity=heat_sensitivity,
        fitness_factor=fitness_factor,
        noise_level=noise_level,
        hr_drift_rate_per_hour=hr_drift_rate,
        temp_drift_rate_per_hour=temp_drift_rate,
    )


def sample_population(
    n_workers: int,
    rng: np.random.Generator,
    config: Optional[Dict[str, Any]] = None,
) -> List[VirtualWorker]:
    """Sample a cohort of virtual workers."""
    return [
        sample_worker(worker_id=f"W{i:03d}", rng=rng, config=config)
        for i in range(n_workers)
    ]
