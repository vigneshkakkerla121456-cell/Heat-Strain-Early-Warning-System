"""Environmental heat load and non-heat confounder time-series generators."""

from dataclasses import dataclass
from typing import Optional
import numpy as np


@dataclass
class EnvironmentProfile:
    """Represents the external heat exposure and physical exertion across a shift."""
    heat_load: np.ndarray       # per-minute values in [0, 1]
    exertion: np.ndarray        # per-minute physical work intensity in [0, 1]
    scenario: str


def generate_heat_load(
    scenario: str,
    shift_length: int = 480,
    calibration_length: int = 30,
    rng: Optional[np.random.Generator] = None,
    target_peak: float = 0.85,
) -> np.ndarray:
    """Generate per-minute environmental heat load series H(t) in [0, 1].

    Parameters
    ----------
    scenario : str
        One of {'cool', 'ramp', 'plateau', 'intermittent', 'moderate_no_event'}.
    shift_length : int
        Total shift duration in minutes (default 480).
    calibration_length : int
        Calibration duration in minutes (default 30).
    rng : np.random.Generator, optional
        Random generator for stochastic variations.
    target_peak : float
        Peak heat load magnitude (default 0.85).

    Returns
    -------
    np.ndarray
        Array of length `shift_length` with environmental heat load in [0, 1].
    """
    if rng is None:
        rng = np.random.default_rng()

    t = np.arange(shift_length)
    heat = np.zeros(shift_length, dtype=float)

    # Base cool ambient level during normal/calibration conditions
    cool_level = 0.15 + 0.05 * rng.uniform(-1, 1)

    if scenario == "cool":
        # Consistently cool/air-conditioned environment
        heat = np.full(shift_length, cool_level) + rng.normal(0, 0.02, size=shift_length)

    elif scenario == "ramp":
        # Gradual solar / ambient warming after calibration
        heat[:calibration_length] = cool_level
        ramp_duration = shift_length - calibration_length
        ramp = np.linspace(cool_level, target_peak, ramp_duration)
        heat[calibration_length:] = ramp + rng.normal(0, 0.02, size=ramp_duration)

    elif scenario == "plateau":
        # Rapid transition into hot zone after calibration, followed by sustained plateau
        heat[:calibration_length] = cool_level
        transition_len = 30
        trans_end = calibration_length + transition_len
        heat[calibration_length:trans_end] = np.linspace(cool_level, target_peak, transition_len)
        plateau_len = shift_length - trans_end
        if plateau_len > 0:
            heat[trans_end:] = target_peak + rng.normal(0, 0.02, size=plateau_len)

    elif scenario == "intermittent":
        # Alternating hot work and shaded/cool breaks
        heat[:calibration_length] = cool_level
        wave_period = 60  # 60 minute cycle
        for minute in range(calibration_length, shift_length):
            phase = (minute - calibration_length) % wave_period
            if phase < 35:
                # Hot work phase
                val = target_peak + rng.normal(0, 0.03)
            else:
                # Break / cooler zone
                val = cool_level + 0.1 + rng.normal(0, 0.02)
            heat[minute] = val

    elif scenario in ("moderate_no_event", "heat_wave_no_event"):
        # Elevated heat that stresses but stays below tipping threshold (~0.45)
        peak = min(target_peak, 0.50)
        heat[:calibration_length] = cool_level
        heat[calibration_length:] = np.linspace(cool_level, peak, shift_length - calibration_length)
        heat[calibration_length:] += rng.normal(0, 0.02, size=shift_length - calibration_length)

    else:
        # Default fallback to moderate ramp
        heat = np.linspace(cool_level, target_peak, shift_length)

    # Smooth slightly and clip to [0.0, 1.0]
    heat = np.clip(heat, 0.0, 1.0)
    return heat


def generate_exertion_confounders(
    shift_length: int = 480,
    calibration_length: int = 30,
    rng: Optional[np.random.Generator] = None,
    burst_probability: float = 0.015,
) -> np.ndarray:
    """Generate per-minute physical exertion confounding bursts E(t) in [0, 1].

    These represent heavy manual lifting or stair climbing that elevate heart rate
    independently of thermal strain.
    """
    if rng is None:
        rng = np.random.default_rng()

    exertion = np.zeros(shift_length, dtype=float)
    minute = calibration_length  # Clean during baseline calibration by default
    while minute < shift_length:
        if rng.random() < burst_probability:
            burst_len = rng.integers(3, 12)
            burst_intensity = rng.uniform(0.35, 0.85)
            end_min = min(shift_length, minute + burst_len)
            exertion[minute:end_min] = burst_intensity
            minute = end_min + rng.integers(10, 30)  # refractory recovery
        else:
            minute += 1

    return exertion


def create_environment_profile(
    scenario: str,
    shift_length: int = 480,
    calibration_length: int = 30,
    rng: Optional[np.random.Generator] = None,
    target_peak: float = 0.85,
    include_exertion: bool = True,
) -> EnvironmentProfile:
    """Create complete environment profile including heat and exertion."""
    if rng is None:
        rng = np.random.default_rng()

    heat = generate_heat_load(
        scenario=scenario,
        shift_length=shift_length,
        calibration_length=calibration_length,
        rng=rng,
        target_peak=target_peak,
    )
    if include_exertion:
        exertion = generate_exertion_confounders(
            shift_length=shift_length,
            calibration_length=calibration_length,
            rng=rng,
        )
    else:
        exertion = np.zeros(shift_length, dtype=float)

    return EnvironmentProfile(heat_load=heat, exertion=exertion, scenario=scenario)
