"""Dynamical physiological signal generation, sensor noise, and dropout simulation."""

from typing import Any, Dict, Optional, Tuple
import numpy as np
import pandas as pd

from hsew.simulator.workers import VirtualWorker
from hsew.simulator.environment import EnvironmentProfile
from hsew.simulator.contamination import apply_calibration_contamination


def simulate_physiological_signals(
    worker: VirtualWorker,
    env: EnvironmentProfile,
    shift_length: int = 480,
    calibration_length: int = 30,
    contamination_mode: str = "clean",
    contamination_strength: float = 0.0,
    rng: Optional[np.random.Generator] = None,
    config: Optional[Dict[str, Any]] = None,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    """Generate physiological signals (HR, Skin Temp, EDA) using first-order lag dynamics.

    Returns
    -------
    signals_df : pd.DataFrame
        Table with columns [worker_id, shift_id, minute, hr, skin_temp, eda, heat_load_observed, quality_flag].
        Contains NO ground truth event labels.
    effective_heat : np.ndarray
        Heat load series used for internal physics.
    effective_exertion : np.ndarray
        Exertion series used for internal physics.
    """
    if rng is None:
        rng = np.random.default_rng()

    cfg = config or {}
    sensor_cfg = cfg.get("sensor_noise", {})
    latent_cfg = cfg.get("latent_strain", {})

    # Time constants (minutes)
    tau_hr = latent_cfg.get("tau_hr", 6.0) / worker.fitness_factor
    tau_temp = latent_cfg.get("tau_temp", 18.0)
    tau_eda = latent_cfg.get("tau_eda", 5.0)

    # 1. Apply calibration contamination if requested
    mod_heat, mod_exertion, hr_offset_contam, temp_offset_contam = apply_calibration_contamination(
        heat_load=env.heat_load,
        exertion=env.exertion,
        mode=contamination_mode,
        strength=contamination_strength,
        calibration_length=calibration_length,
        rng=rng,
    )

    # 2. Benign linear drift across shift (per hour -> per minute)
    hr_drift_per_min = worker.hr_drift_rate_per_hour / 60.0
    temp_drift_per_min = worker.temp_drift_rate_per_hour / 60.0
    time_minutes = np.arange(shift_length)
    hr_drift = hr_drift_per_min * time_minutes
    temp_drift = temp_drift_per_min * time_minutes

    # 3. Simulate first-order lag state trajectories
    hr_clean = np.zeros(shift_length, dtype=float)
    temp_clean = np.zeros(shift_length, dtype=float)
    eda_clean = np.zeros(shift_length, dtype=float)

    # Initial condition at t=0
    hr_state = worker.resting_hr + hr_offset_contam[0]
    temp_state = worker.resting_skin_temp + temp_offset_contam[0]
    eda_state = worker.resting_eda

    alpha_hr = 1.0 - np.exp(-1.0 / max(1.0, tau_hr))
    alpha_temp = 1.0 - np.exp(-1.0 / max(1.0, tau_temp))
    alpha_eda = 1.0 - np.exp(-1.0 / max(1.0, tau_eda))

    for t in range(shift_length):
        # Target instantaneous values
        delta_hr_heat = 45.0 * worker.heat_sensitivity * mod_heat[t]
        delta_hr_work = 55.0 * mod_exertion[t]
        target_hr = (
            worker.resting_hr
            + delta_hr_heat
            + delta_hr_work
            + hr_drift[t]
            + hr_offset_contam[t]
        )

        delta_temp_heat = 3.5 * worker.heat_sensitivity * mod_heat[t]
        delta_temp_work = 0.4 * mod_exertion[t]
        target_temp = (
            worker.resting_skin_temp
            + delta_temp_heat
            + delta_temp_work
            + temp_drift[t]
            + temp_offset_contam[t]
        )

        delta_eda_heat = 6.0 * worker.heat_sensitivity * mod_heat[t]
        delta_eda_work = 3.0 * mod_exertion[t]
        target_eda = (
            worker.resting_eda
            + delta_eda_heat
            + delta_eda_work
        )

        # Discrete-time exponential filter update
        hr_state = hr_state + alpha_hr * (target_hr - hr_state)
        temp_state = temp_state + alpha_temp * (target_temp - temp_state)
        eda_state = eda_state + alpha_eda * (target_eda - eda_state)

        hr_clean[t] = hr_state
        temp_clean[t] = temp_state
        eda_clean[t] = max(0.1, eda_state)

    # 4. Add sensor noise and occasional artifact spikes
    hr_noise_std = sensor_cfg.get("hr_gaussian_std", 1.5) * worker.noise_level
    temp_noise_std = sensor_cfg.get("skin_temp_gaussian_std", 0.1) * worker.noise_level
    eda_noise_std = sensor_cfg.get("eda_gaussian_std", 0.15) * worker.noise_level
    p_spike = sensor_cfg.get("spike_probability", 0.01)

    hr_noisy = hr_clean + rng.normal(0, hr_noise_std, size=shift_length)
    temp_noisy = temp_clean + rng.normal(0, temp_noise_std, size=shift_length)
    eda_noisy = eda_clean + rng.normal(0, eda_noise_std, size=shift_length)

    # Inject occasional spikes
    spike_mask = rng.random(shift_length) < p_spike
    hr_noisy[spike_mask] += rng.choice([-1, 1], size=np.sum(spike_mask)) * rng.uniform(10, 25, size=np.sum(spike_mask))
    temp_noisy[spike_mask] += rng.choice([-1, 1], size=np.sum(spike_mask)) * rng.uniform(0.5, 1.2, size=np.sum(spike_mask))

    # Observed environmental heat load has slight sensor measurement noise
    heat_observed = np.clip(mod_heat + rng.normal(0, 0.02, size=shift_length), 0.0, 1.0)

    # 5. Missing data and dropout simulation
    p_dropout = sensor_cfg.get("dropout_probability", 0.02)
    p_burst = sensor_cfg.get("burst_gap_probability", 0.002)
    max_burst_len = sensor_cfg.get("burst_gap_length_max", 10)

    quality_flag = np.ones(shift_length, dtype=int)
    dropout_mask = rng.random(shift_length) < p_dropout
    quality_flag[dropout_mask] = 0

    # Bursty gaps
    t = 0
    while t < shift_length:
        if rng.random() < p_burst:
            gap_len = rng.integers(3, max_burst_len + 1)
            gap_end = min(shift_length, t + gap_len)
            quality_flag[t:gap_end] = 0
            t = gap_end
        else:
            t += 1

    # Replace dropped samples with NaN
    hr_observed = hr_noisy.copy()
    temp_observed = temp_noisy.copy()
    eda_observed = eda_noisy.copy()

    hr_observed[quality_flag == 0] = np.nan
    temp_observed[quality_flag == 0] = np.nan
    eda_observed[quality_flag == 0] = np.nan

    # Create signals DataFrame
    signals_df = pd.DataFrame({
        "worker_id": worker.worker_id,
        "minute": time_minutes,
        "hr": np.round(hr_observed, 2),
        "skin_temp": np.round(temp_observed, 3),
        "eda": np.round(np.clip(eda_observed, 0.05, 50.0), 3),
        "heat_load_observed": np.round(heat_observed, 3),
        "quality_flag": quality_flag,
    })

    return signals_df, mod_heat, mod_exertion
