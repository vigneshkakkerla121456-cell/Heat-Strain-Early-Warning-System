"""Simulator subpackage for generating synthetic virtual workers and shifts."""

from hsew.simulator.workers import VirtualWorker, sample_worker, sample_population
from hsew.simulator.environment import create_environment_profile, generate_heat_load, generate_exertion_confounders
from hsew.simulator.contamination import apply_calibration_contamination, ContaminationConfig
from hsew.simulator.events import compute_latent_strain_and_events, format_labels_df
from hsew.simulator.signals import simulate_physiological_signals
from hsew.simulator.runner import simulate_shift, simulate_cohort

__all__ = [
    "VirtualWorker",
    "sample_worker",
    "sample_population",
    "create_environment_profile",
    "generate_heat_load",
    "generate_exertion_confounders",
    "apply_calibration_contamination",
    "ContaminationConfig",
    "compute_latent_strain_and_events",
    "format_labels_df",
    "simulate_physiological_signals",
    "simulate_shift",
    "simulate_cohort",
]
