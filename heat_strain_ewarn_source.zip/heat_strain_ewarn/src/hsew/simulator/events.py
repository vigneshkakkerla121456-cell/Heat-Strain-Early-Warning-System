"""Latent physiological heat-strain dynamics and hidden ground-truth event labels."""

from dataclasses import dataclass
from typing import Optional
import numpy as np
import pandas as pd


@dataclass
class LatentEventGroundTruth:
    """Hidden ground truth labels. NEVER to be exposed to detection algorithms."""
    event_present: bool
    event_onset_minute: int          # -1 if no event
    event_active: np.ndarray         # boolean array of shape (shift_length,)
    latent_strain_trajectory: np.ndarray  # float array in [0, 1] of shape (shift_length,)


def compute_latent_strain_and_events(
    heat_load: np.ndarray,
    exertion: np.ndarray,
    heat_sensitivity: float,
    fitness_factor: float,
    event_threshold: float = 0.70,
    calibration_length: int = 30,
    cooling_capacity: float = 0.35,
    tau_minutes: float = 40.0,
) -> LatentEventGroundTruth:
    """Compute latent heat-strain index and ground truth event labels.

    The latent strain S(t) acts as a leaky integrator of environmental heat
    and physical exertion minus thermoregulatory compensation capacity.
    This represents latent physiological distress, not a core temperature claim.

    Parameters
    ----------
    heat_load : np.ndarray
        Environmental heat load H(t) in [0, 1].
    exertion : np.ndarray
        Exertion intensity E(t) in [0, 1].
    heat_sensitivity : float
        Individual sensitivity multiplier beta.
    fitness_factor : float
        Individual fitness multiplier phi (improves cooling/dissipation).
    event_threshold : float
        Latent strain threshold defining heat-strain onset (default 0.70).
    calibration_length : int
        Calibration duration in minutes (events cannot begin in calibration).
    cooling_capacity : float
        Base heat dissipation rate.
    tau_minutes : float
        Accumulation time constant.

    Returns
    -------
    LatentEventGroundTruth
        Separated ground-truth container.
    """
    n = len(heat_load)
    strain = np.zeros(n, dtype=float)

    # Effective cooling capacity scaled by fitness
    eff_cooling = cooling_capacity * np.clip(fitness_factor, 0.7, 1.4)
    alpha = np.exp(-1.0 / tau_minutes)

    current_s = 0.0
    for t in range(n):
        # Net thermal drive
        net_drive = (heat_sensitivity * heat_load[t]) + (0.35 * exertion[t])
        target_s = np.clip(net_drive - eff_cooling + 0.1, 0.0, 1.0)
        current_s = alpha * current_s + (1.0 - alpha) * target_s
        strain[t] = current_s

    # An event occurs only if threshold is crossed AFTER the calibration period
    post_cal_strain = strain[calibration_length:]
    crossings = np.where(post_cal_strain >= event_threshold)[0]

    if len(crossings) > 0:
        event_present = True
        onset_min = int(crossings[0] + calibration_length)
        event_active = strain >= event_threshold
        # Calibration minutes are never considered part of an event
        event_active[:calibration_length] = False
    else:
        event_present = False
        onset_min = -1
        event_active = np.zeros(n, dtype=bool)

    return LatentEventGroundTruth(
        event_present=event_present,
        event_onset_minute=onset_min,
        event_active=event_active,
        latent_strain_trajectory=strain,
    )


def format_labels_df(
    worker_id: str,
    shift_id: str,
    ground_truth: LatentEventGroundTruth,
) -> pd.DataFrame:
    """Format ground truth labels into a standardized labels DataFrame."""
    n = len(ground_truth.event_active)
    minutes = np.arange(n)
    return pd.DataFrame({
        "worker_id": worker_id,
        "shift_id": shift_id,
        "minute": minutes,
        "event_present": ground_truth.event_present,
        "event_onset_minute": ground_truth.event_onset_minute,
        "event_active": ground_truth.event_active.astype(int),
    })
