"""Orchestration for generating shifts, cohort simulations, and saving data."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
import pandas as pd

from hsew.simulator.workers import VirtualWorker, sample_worker, sample_population
from hsew.simulator.environment import create_environment_profile, EnvironmentProfile
from hsew.simulator.contamination import ContaminationConfig
from hsew.simulator.signals import simulate_physiological_signals
from hsew.simulator.events import compute_latent_strain_and_events, format_labels_df


def simulate_shift(
    worker: VirtualWorker,
    shift_id: str,
    scenario: str = "ramp",
    contamination_mode: str = "clean",
    contamination_strength: float = 0.0,
    seed: Optional[int] = None,
    config: Optional[Dict[str, Any]] = None,
    environment_profile: Optional[EnvironmentProfile] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Simulate a single worker shift of 480 minutes.

    Returns
    -------
    signals_df : pd.DataFrame
        Signals table: (worker_id, shift_id, minute, hr, skin_temp, eda, heat_load_observed, quality_flag).
        GUARANTEED to contain zero event label information.
    labels_df : pd.DataFrame
        Labels table: (worker_id, shift_id, minute, event_present, event_onset_minute, event_active).
    """
    rng = np.random.default_rng(seed)
    cfg = config or {}
    shift_len = cfg.get("shift_length_minutes", 480)
    cal_len = cfg.get("calibration_minutes", 30)

    # 1. Environment profile
    if environment_profile is not None:
        env = environment_profile
    else:
        env = create_environment_profile(
            scenario=scenario,
            shift_length=shift_len,
            calibration_length=cal_len,
            rng=rng,
        )

    # 2. Physiological signals & effective inputs
    signals_df, eff_heat, eff_exertion = simulate_physiological_signals(
        worker=worker,
        env=env,
        shift_length=shift_len,
        calibration_length=cal_len,
        contamination_mode=contamination_mode,
        contamination_strength=contamination_strength,
        rng=rng,
        config=cfg,
    )
    signals_df.insert(1, "shift_id", shift_id)

    # 3. Hidden ground-truth latent strain & events
    latent_cfg = cfg.get("latent_strain", {})
    event_thresh = latent_cfg.get("event_threshold", 0.70)
    ground_truth = compute_latent_strain_and_events(
        heat_load=eff_heat,
        exertion=eff_exertion,
        heat_sensitivity=worker.heat_sensitivity,
        fitness_factor=worker.fitness_factor,
        event_threshold=event_thresh,
        calibration_length=cal_len,
    )
    labels_df = format_labels_df(
        worker_id=worker.worker_id,
        shift_id=shift_id,
        ground_truth=ground_truth,
    )

    # Strictly check that NO event labels leaked into signals_df
    forbidden_terms = {"event", "onset", "label", "strain"}
    for col in signals_df.columns:
        for term in forbidden_terms:
            assert term not in col.lower(), f"Label leakage detected in signals column: {col}"

    return signals_df, labels_df


def simulate_cohort(
    n_workers: int = 10,
    scenarios: Optional[List[str]] = None,
    contamination_mode: str = "clean",
    contamination_strength: float = 0.0,
    seed: int = 42,
    config: Optional[Dict[str, Any]] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Simulate a cohort of virtual workers across multiple scenarios."""
    rng = np.random.default_rng(seed)
    workers = sample_population(n_workers=n_workers, rng=rng, config=config)

    scenarios_list = scenarios or ["ramp", "plateau", "intermittent", "cool", "heat_wave_no_event"]

    all_signals = []
    all_labels = []

    shift_counter = 0
    for w in workers:
        for sc in scenarios_list:
            shift_counter += 1
            shift_id = f"S{shift_counter:04d}_{w.worker_id}_{sc}"
            shift_seed = int(rng.integers(0, 2**31 - 1))

            sig_df, lbl_df = simulate_shift(
                worker=w,
                shift_id=shift_id,
                scenario=sc,
                contamination_mode=contamination_mode,
                contamination_strength=contamination_strength,
                seed=shift_seed,
                config=config,
            )
            all_signals.append(sig_df)
            all_labels.append(lbl_df)

    cohort_signals = pd.concat(all_signals, ignore_index=True)
    cohort_labels = pd.concat(all_labels, ignore_index=True)
    return cohort_signals, cohort_labels
