"""Calibration contamination modes and perturbation models."""

from dataclasses import dataclass
from typing import Optional, Tuple
import numpy as np


@dataclass
class ContaminationConfig:
    """Specification of calibration contamination.

    Parameters
    ----------
    mode : str
        One of {'clean', 'post_exertion', 'already_hot', 'partial'}.
    strength : float
        Continuous intensity parameter in [0.0, 1.0]. 0.0 is completely clean.
    """
    mode: str = "clean"
    strength: float = 0.0


def apply_calibration_contamination(
    heat_load: np.ndarray,
    exertion: np.ndarray,
    mode: str = "clean",
    strength: float = 0.0,
    calibration_length: int = 30,
    rng: Optional[np.random.Generator] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Modify calibration window inputs to simulate contaminated baseline conditions.

    Parameters
    ----------
    heat_load : np.ndarray
        Array of length N with baseline heat load.
    exertion : np.ndarray
        Array of length N with baseline exertion.
    mode : str
        Contamination mode: 'clean', 'post_exertion', 'already_hot', 'partial'.
    strength : float
        Contamination strength in [0.0, 1.0].
    calibration_length : int
        Calibration duration in minutes (default 30).
    rng : np.random.Generator, optional
        Random generator instance.

    Returns
    -------
    tuple of (modified_heat, modified_exertion, hr_offset_series, temp_offset_series)
        Offsets are in physical units (bpm for HR, deg C for temperature).
    """
    if rng is None:
        rng = np.random.default_rng()

    n = len(heat_load)
    mod_heat = heat_load.copy()
    mod_exertion = exertion.copy()
    hr_offset = np.zeros(n, dtype=float)
    temp_offset = np.zeros(n, dtype=float)

    if strength <= 0.0 or mode == "clean":
        return mod_heat, mod_exertion, hr_offset, temp_offset

    cal_len = min(calibration_length, n)

    if mode == "post_exertion":
        # Worker arrives right after heavy exertion; HR starts elevated by +15 to +35 bpm
        # and exponentially decays back toward rest over ~25 minutes.
        peak_hr_bump = 30.0 * strength
        decay_time_constant = 10.0  # minutes
        decay_curve = np.exp(-np.arange(cal_len) / decay_time_constant)
        hr_offset[:cal_len] = peak_hr_bump * decay_curve
        # Slight skin temp elevation due to metabolic heat
        temp_offset[:cal_len] = 0.5 * strength * decay_curve

    elif mode == "already_hot":
        # Worker sits in hot / poorly ventilated environment during calibration
        # Heat load is elevated and skin temp is already warm
        heat_boost = 0.6 * strength
        mod_heat[:cal_len] = np.clip(mod_heat[:cal_len] + heat_boost, 0.0, 1.0)
        temp_offset[:cal_len] = 1.8 * strength
        hr_offset[:cal_len] = 12.0 * strength

    elif mode == "partial":
        # Contamination present during only the second half of the calibration window
        mid = cal_len // 2
        partial_len = cal_len - mid
        # Transient activity / heat spike during calibration
        mod_heat[mid:cal_len] = np.clip(mod_heat[mid:cal_len] + 0.5 * strength, 0.0, 1.0)
        hr_offset[mid:cal_len] = 20.0 * strength
        temp_offset[mid:cal_len] = 1.0 * strength

    return mod_heat, mod_exertion, hr_offset, temp_offset
