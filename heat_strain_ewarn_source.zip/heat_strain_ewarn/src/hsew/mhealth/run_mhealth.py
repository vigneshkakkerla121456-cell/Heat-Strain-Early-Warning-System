"""CLI runner for PhysioNet MHEALTH validation."""

import argparse
from pathlib import Path
import pandas as pd

from hsew.mhealth.loader import load_mhealth_subject
from hsew.mhealth.analysis import evaluate_mhealth_guard_mechanics


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run PhysioNet MHEALTH Validation (Physical Activity Baseline Dynamics)."
    )
    parser.add_argument(
        "--data_dir",
        type=str,
        default="data/mhealth",
        help="Path to directory containing MHEALTH subject files.",
    )
    parser.add_argument(
        "--out_dir",
        type=str,
        default="results/mhealth_validation",
        help="Path to save output CSVs.",
    )
    parser.add_argument(
        "--num_subjects",
        type=int,
        default=10,
        help="Number of subjects (default 10).",
    )
    args = parser.parse_args()

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print("==========================================================================")
    print("PHYSIONET MHEALTH VALIDATION (PHYSICAL ACTIVITY ECG & WRIST SIGNALS)")
    print("Evaluating Guarded Adaptive Baseline Integrity across 12 Activities")
    print("==========================================================================")

    # 1. Load subjects (m01 through m10)
    subjects = []
    for i in range(1, args.num_subjects + 1):
        sub_id = f"m{i:02d}"
        sub_df = load_mhealth_subject(args.data_dir, subject_id=sub_id)
        subjects.append(sub_df)

    # 2. Evaluate Guard Mechanics (Table VIII)
    print(f"\nLoaded {len(subjects)} subjects. Evaluating guard mechanics...")
    tbl_df = evaluate_mhealth_guard_mechanics(subjects)

    csv_path = out_path / "guard_mechanics.csv"
    tbl_df.to_csv(csv_path, index=False)

    print(f"\nResults saved to: {csv_path}")
    print("\n" + "=" * 65)
    print("TABLE VIII: PHYSIONET MHEALTH GUARD-MECHANICS STATISTICS")
    print("=" * 65)
    print(tbl_df.to_string(index=False))
    print("=" * 65)


if __name__ == "__main__":
    main()

