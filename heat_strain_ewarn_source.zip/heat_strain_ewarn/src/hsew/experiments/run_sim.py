"""Command-line script to run synthetic simulation and export signals and labels."""

import argparse
from pathlib import Path
import pandas as pd

from hsew.utils.config import load_config
from hsew.simulator.runner import simulate_cohort


def main() -> None:
    parser = argparse.ArgumentParser(description="Run synthetic worker simulation.")
    parser.add_argument(
        "--config",
        type=str,
        default="configs/simulator.yaml",
        help="Path to simulator configuration YAML.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=5,
        help="Number of virtual workers to simulate.",
    )
    parser.add_argument(
        "--out_dir",
        type=str,
        default="results/sim_sample",
        help="Directory to save generated signals and labels.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Master random seed.",
    )
    parser.add_argument(
        "--contamination_mode",
        type=str,
        default="clean",
        help="Calibration contamination mode (clean, post_exertion, already_hot, partial).",
    )
    parser.add_argument(
        "--contamination_strength",
        type=float,
        default=0.0,
        help="Contamination strength in [0.0, 1.0].",
    )

    args = parser.parse_args()
    config = load_config(args.config)

    print(f"Running simulation with {args.workers} workers, seed={args.seed}...")
    signals_df, labels_df = simulate_cohort(
        n_workers=args.workers,
        contamination_mode=args.contamination_mode,
        contamination_strength=args.contamination_strength,
        seed=args.seed,
        config=config,
    )

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    sig_csv = out_path / "signals.csv"
    lbl_csv = out_path / "labels.csv"

    signals_df.to_csv(sig_csv, index=False)
    labels_df.to_csv(lbl_csv, index=False)

    # Also save parquet if pyarrow/fastparquet is available
    try:
        signals_df.to_parquet(out_path / "signals.parquet", index=False)
    except Exception:
        pass

    print(f"Simulation completed successfully.")
    print(f"Signals saved to: {sig_csv} ({len(signals_df)} rows)")
    print(f"Labels saved to:  {lbl_csv} ({len(labels_df)} rows)")


if __name__ == "__main__":
    main()
