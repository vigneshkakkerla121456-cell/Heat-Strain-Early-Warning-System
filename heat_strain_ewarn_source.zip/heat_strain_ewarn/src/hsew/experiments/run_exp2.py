"""Experiment 2: Contaminated Calibration sweep across contamination modes and strengths."""

import argparse
from pathlib import Path
import pandas as pd
from tqdm import tqdm

from hsew.utils.config import load_config
from hsew.methods import get_method
from hsew.metrics.matched_fa import calibrate_matched_thresholds, evaluate_method_on_dataset
from hsew.metrics.alarm_metrics import aggregate_evaluation_results
from hsew.experiments.experiment_base import generate_experiment_dataset


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Experiment 2: Contaminated Calibration.")
    parser.add_argument("--config", type=str, default="configs/experiments.yaml")
    parser.add_argument("--sim_config", type=str, default="configs/simulator.yaml")
    parser.add_argument("--methods_config", type=str, default="configs/methods.yaml")
    parser.add_argument("--out_dir", type=str, default="results/exp2_contamination")
    parser.add_argument("--fast", action="store_true", help="Run fast test.")
    args = parser.parse_args()

    exp_cfg = load_config(args.config)
    sim_cfg = load_config(args.sim_config)
    meth_cfg = load_config(args.methods_config)

    seeds_cfg = exp_cfg.get("seeds", {})
    tuning_seeds = seeds_cfg.get("tuning_seeds", [101, 102])[:2] if args.fast else seeds_cfg.get("tuning_seeds", [101, 102, 103])
    test_seeds = seeds_cfg.get("test_seeds", [201, 202])[:2] if args.fast else seeds_cfg.get("test_seeds", [201, 202, 203, 204, 205])

    e2_cfg = exp_cfg.get("exp2_contamination", {})
    modes = ["post_exertion", "already_hot"] if args.fast else e2_cfg.get("modes", ["clean", "post_exertion", "already_hot", "partial"])
    strengths = [0.0, 0.5, 1.0] if args.fast else e2_cfg.get("strengths", [0.0, 0.25, 0.50, 0.75, 1.0])
    scenarios = ["event_ramp", "no_event_cool"]
    n_workers = 2 if args.fast else 5

    target_fa = 0.50  # evaluate at standard matched FA operating point

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    methods_to_compare = [
        "oneshot_personalized",
        "unguarded_adaptive",
        "guarded_adaptive",
    ]
    methods = {m: get_method(m, config=meth_cfg) for m in methods_to_compare}

    # 1. Calibrate thresholds on clean no-event tuning data
    print("Calibrating methods on clean tuning set at target FA = 0.50...")
    tune_sigs, tune_lbls = generate_experiment_dataset(
        n_workers_per_seed=n_workers,
        seeds=tuning_seeds,
        scenarios=["no_event_cool"],
        sim_config=sim_cfg,
        contamination_mode="clean",
        contamination_strength=0.0,
    )
    no_ev_ids = tune_lbls[tune_lbls["event_present"] == False]["shift_id"].unique()
    clean_no_ev_sigs = tune_sigs[tune_sigs["shift_id"].isin(no_ev_ids)]

    calibrated_thresholds = {}
    for m_name, m in methods.items():
        calib_dict = calibrate_matched_thresholds(m, clean_no_ev_sigs, target_fas=[target_fa])
        calibrated_thresholds[m_name] = calib_dict[target_fa]

    records = []
    print("\nSweeping contamination modes and strengths...")
    for mode in modes:
        for strength in strengths:
            # Generate contaminated test set
            test_sigs, test_lbls = generate_experiment_dataset(
                n_workers_per_seed=n_workers,
                seeds=test_seeds,
                scenarios=scenarios,
                sim_config=sim_cfg,
                contamination_mode=mode,
                contamination_strength=strength,
            )

            for m_name, m in methods.items():
                thresh = calibrated_thresholds[m_name]
                evals = evaluate_method_on_dataset(m, test_sigs, test_lbls, threshold=thresh)
                metrics = aggregate_evaluation_results(evals)

                records.append({
                    "contamination_mode": mode,
                    "contamination_strength": strength,
                    "method": m_name,
                    "early_warning_rate": metrics["early_warning_rate"],
                    "lead_time_mean": metrics["mean_lead_time"],
                    "detection_delay_mean": metrics["mean_detection_delay"],
                    "missed_event_rate": metrics["missed_event_rate"],
                    "fa_per_shift": metrics["fa_per_shift"],
                })

    summary_df = pd.DataFrame(records)
    summary_csv = out_path / "summary.csv"
    summary_df.to_csv(summary_csv, index=False)

    print(f"\nExperiment 2 complete. Saved to: {summary_csv}")


if __name__ == "__main__":
    main()
