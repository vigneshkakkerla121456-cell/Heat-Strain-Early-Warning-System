"""Experiment 4: Noise and Missingness sweep across sensor noise multipliers and dropout rates."""

import argparse
from pathlib import Path
import pandas as pd

from hsew.utils.config import load_config
from hsew.methods import get_method
from hsew.metrics.matched_fa import calibrate_matched_thresholds, evaluate_method_on_dataset
from hsew.metrics.alarm_metrics import aggregate_evaluation_results
from hsew.experiments.experiment_base import generate_experiment_dataset


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Experiment 4: Noise and Missingness.")
    parser.add_argument("--config", type=str, default="configs/experiments.yaml")
    parser.add_argument("--sim_config", type=str, default="configs/simulator.yaml")
    parser.add_argument("--methods_config", type=str, default="configs/methods.yaml")
    parser.add_argument("--out_dir", type=str, default="results/exp4_noise_missingness")
    parser.add_argument("--fast", action="store_true", help="Run fast test.")
    args = parser.parse_args()

    exp_cfg = load_config(args.config)
    sim_cfg = load_config(args.sim_config)
    meth_cfg = load_config(args.methods_config)

    seeds_cfg = exp_cfg.get("seeds", {})
    tuning_seeds = seeds_cfg.get("tuning_seeds", [101, 102])[:2] if args.fast else seeds_cfg.get("tuning_seeds", [101, 102, 103])
    test_seeds = seeds_cfg.get("test_seeds", [201, 202])[:2] if args.fast else seeds_cfg.get("test_seeds", [201, 202, 203, 204, 205])

    e4_cfg = exp_cfg.get("exp4_noise_missingness", {})
    noise_levels = [1.0, 2.5] if args.fast else e4_cfg.get("noise_levels", [0.5, 1.0, 2.0, 3.0])
    dropout_rates = [0.02, 0.15] if args.fast else e4_cfg.get("dropout_rates", [0.0, 0.05, 0.10, 0.20])
    scenarios = ["event_ramp", "no_event_cool"]
    n_workers = 2 if args.fast else 5
    target_fa = 0.50

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    methods = {
        "oneshot_personalized": get_method("oneshot_personalized", config=meth_cfg),
        "unguarded_adaptive": get_method("unguarded_adaptive", config=meth_cfg),
        "guarded_adaptive": get_method("guarded_adaptive", config=meth_cfg),
    }

    tune_sigs, tune_lbls = generate_experiment_dataset(
        n_workers_per_seed=n_workers,
        seeds=tuning_seeds,
        scenarios=["no_event_cool"],
        sim_config=sim_cfg,
    )
    no_ev_ids = tune_lbls[tune_lbls["event_present"] == False]["shift_id"].unique()
    clean_no_ev_sigs = tune_sigs[tune_sigs["shift_id"].isin(no_ev_ids)]

    calibrated_thresholds = {}
    for m_name, m in methods.items():
        calib_dict = calibrate_matched_thresholds(m, clean_no_ev_sigs, target_fas=[target_fa])
        calibrated_thresholds[m_name] = calib_dict[target_fa]

    records = []
    print("Sweeping noise levels and dropout missingness rates...")
    for noise in noise_levels:
        for drop in dropout_rates:
            test_sigs, test_lbls = generate_experiment_dataset(
                n_workers_per_seed=n_workers,
                seeds=test_seeds,
                scenarios=scenarios,
                sim_config=sim_cfg,
                noise_multiplier=noise,
                dropout_rate=drop,
            )

            for m_name, m in methods.items():
                thresh = calibrated_thresholds[m_name]
                evals = evaluate_method_on_dataset(m, test_sigs, test_lbls, threshold=thresh)
                metrics = aggregate_evaluation_results(evals)

                records.append({
                    "noise_level": noise,
                    "dropout_rate": drop,
                    "method": m_name,
                    "early_warning_rate": metrics["early_warning_rate"],
                    "lead_time_mean": metrics["mean_lead_time"],
                    "fa_per_shift": metrics["fa_per_shift"],
                })

    summary_df = pd.DataFrame(records)
    summary_csv = out_path / "summary.csv"
    summary_df.to_csv(summary_csv, index=False)

    print(f"\nExperiment 4 complete. Saved to: {summary_csv}")


if __name__ == "__main__":
    main()
