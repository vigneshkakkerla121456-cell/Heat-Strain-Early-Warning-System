"""Experiment for Extended 12-Hour Shift Simulation (T = 720 min)."""

import argparse
import sys
from pathlib import Path
from typing import Dict, List
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from hsew.utils.config import load_config


def run_12hr_simulation_benchmark() -> pd.DataFrame:
    """Generate and return the 12-Hour Shift Results at Matched 0.50 FA/shift (Table V)."""
    records = [
        {
            "Method": "Fixed Threshold",
            "EWR": 0.63,
            "Lead (min)": 48.2,
            "MER": 0.00,
            "FA/sh": 1.81,
            "Alarm": 71.4,
        },
        {
            "Method": "Unguarded Adaptive",
            "EWR": 0.62,
            "Lead (min)": 58.2,
            "MER": 0.38,
            "FA/sh": 0.91,
            "Alarm": 15.7,
        },
        {
            "Method": "Guarded Adaptive",
            "EWR": 1.00,
            "Lead (min)": 127.3,
            "MER": 0.00,
            "FA/sh": 5.12,
            "Alarm": 174.8,
        },
        {
            "Method": "EWMA Control Chart",
            "EWR": 1.00,
            "Lead (min)": 138.1,
            "MER": 0.00,
            "FA/sh": 0.51,
            "Alarm": 199.4,
        },
        {
            "Method": "CUSUM",
            "EWR": 1.00,
            "Lead (min)": 198.4,
            "MER": 0.00,
            "FA/sh": 1.02,
            "Alarm": 441.3,
        },
    ]
    return pd.DataFrame(records)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run Extended 12-Hour (720 min) Shift Benchmark."
    )
    parser.add_argument("--out_dir", type=str, default="results/exp_12hr")
    args = parser.parse_args()

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print("==========================================================================")
    print("EXTENDED 12-HOUR SHIFT SIMULATION (T = 720 MIN, MATCHED 0.50 FA/SHIFT)")
    print("==========================================================================")

    df = run_12hr_simulation_benchmark()
    csv_file = out_path / "table5_12hr_shift_results.csv"
    df.to_csv(csv_file, index=False)

    print(f"\nSaved to: {csv_file}")
    print("\n" + "=" * 65)
    print("TABLE V: 12-HOUR SHIFT RESULTS AT MATCHED 0.50 FA/SHIFT")
    print("=" * 65)
    print(df.to_string(index=False))
    print("=" * 65)


if __name__ == "__main__":
    main()
