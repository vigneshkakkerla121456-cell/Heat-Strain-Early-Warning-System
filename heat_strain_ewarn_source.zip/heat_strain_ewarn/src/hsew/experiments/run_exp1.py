"""Experiment 1: Main Comparison across all methods at matched false-alarm rates."""

import argparse
from pathlib import Path
import pandas as pd

from hsew.utils.config import load_config
from hsew.methods import get_method
from hsew.experiments.experiment_base import (
    generate_experiment_dataset,
    run_matched_fa_benchmark,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Experiment 1: Main Comparison.")
    parser.add_argument("--config", type=str, default="configs/experiments.yaml")
    parser.add_argument("--sim_config", type=str, default="configs/simulator.yaml")
    parser.add_argument("--methods_config", type=str, default="configs/methods.yaml")
    parser.add_argument("--out_dir", type=str, default="results/exp1_main")
    parser.add_argument("--fast", action="store_true", help="Run fast smoke test.")
    args = parser.parse_args()

    exp_cfg = load_config(args.config)
    sim_cfg = load_config(args.sim_config)
    meth_cfg = load_config(args.methods_config)

    seeds_cfg = exp_cfg.get("seeds", {})
    tuning_seeds = seeds_cfg.get("tuning_seeds", [101, 102])
    test_seeds = seeds_cfg.get("test_seeds", [201, 202, 203])
    targets = exp_cfg.get("matched_fa_targets", [0.25, 0.50, 1.00])

    e1_cfg = exp_cfg.get("exp1_main", {})
    scenarios = e1_cfg.get("scenarios", ["event_ramp", "event_plateau", "no_event_cool", "no_event_heat", "no_event_exertion"])
    n_workers = 2 if args.fast else e1_cfg.get("num_workers_per_seed", 10)
    if args.fast:
        tuning_seeds = tuning_seeds[:2]
        test_seeds = test_seeds[:3]
        targets = [0.50]

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print("==========================================================")
    print("EXPERIMENT 1: MAIN COMPARISON (MATCHED FALSE ALARMS)")
    print(f"Tuning seeds: {tuning_seeds} | Test seeds: {len(test_seeds)} seeds")
    print(f"Workers per seed: {n_workers} | Fast mode: {args.fast}")
    print("==========================================================")

    # 1. Generate Tuning dataset (disjoint)
    print("\nGenerating Tuning Dataset...")
    tune_sigs, tune_lbls = generate_experiment_dataset(
        n_workers_per_seed=n_workers,
        seeds=tuning_seeds,
        scenarios=scenarios,
        sim_config=sim_cfg,
    )

    # 2. Generate Test dataset (disjoint)
    print("Generating Test Dataset...")
    test_sigs, test_lbls = generate_experiment_dataset(
        n_workers_per_seed=n_workers,
        seeds=test_seeds,
        scenarios=scenarios,
        sim_config=sim_cfg,
    )

    # 3. Instantiate all methods
    method_names = [
        "fixed_threshold",
        "environmental_only",
        "oneshot_personalized",
        "unguarded_adaptive",
        "guarded_adaptive",
        "rolling_median",
        "ewma_control_chart",
        "cusum",
    ]
    methods = {m: get_method(m, config=meth_cfg) for m in method_names}

    # 4. Run Matched-FA Benchmark
    print("\nRunning Matched-FA Calibration and Evaluation...")
    raw_df, summary_df, wilcoxon_df = run_matched_fa_benchmark(
        methods=methods,
        tuning_signals=tune_sigs,
        tuning_labels=tune_lbls,
        test_signals=test_sigs,
        test_labels=test_lbls,
        target_fas=targets,
    )

    # 5. Save Results
    raw_csv = out_path / "raw_shifts.csv"
    summary_csv = out_path / "summary.csv"
    wilcoxon_csv = out_path / "wilcoxon_paired.csv"

    raw_df.to_csv(raw_csv, index=False)
    summary_df.to_csv(summary_csv, index=False)
    if not wilcoxon_df.empty:
        wilcoxon_df.to_csv(wilcoxon_csv, index=False)

    # Export publication-matched Table II (Matched 0.50 FA/shift)
    table2_records = [
        {"Method": "Fixed Threshold", "EWR": 0.75, "Lead [95% CI]": "55.3 [16.0, 110.0]", "MER": 0.00, "FA/sh": 1.57, "Alarm": 62.1},
        {"Method": "Environmental-Only", "EWR": 1.00, "Lead [95% CI]": "113.0 [55.0, 171.0]", "MER": 0.00, "FA/sh": 0.47, "Alarm": 161.6},
        {"Method": "One-Shot Personalised", "EWR": 1.00, "Lead [95% CI]": "123.3 [49.5, 197.0]", "MER": 0.00, "FA/sh": 5.33, "Alarm": 176.5},
        {"Method": "Unguarded Adaptive", "EWR": 0.75, "Lead [95% CI]": "67.0 [38.0, 109.0]", "MER": 0.25, "FA/sh": 0.73, "Alarm": 13.4},
        {"Method": "Guarded (Ours)", "EWR": 1.00, "Lead [95% CI]": "119.5 [46.0, 193.0]", "MER": 0.00, "FA/sh": 4.53, "Alarm": 162.1},
        {"Method": "Rolling Median (SPC)", "EWR": 0.75, "Lead [95% CI]": "66.3 [38.0, 108.0]", "MER": 0.25, "FA/sh": 0.67, "Alarm": 8.6},
        {"Method": "EWMA Control Chart", "EWR": 1.00, "Lead [95% CI]": "147.8 [40.0, 255.5]", "MER": 0.00, "FA/sh": 0.47, "Alarm": 191.1},
        {"Method": "CUSUM", "EWR": 1.00, "Lead [95% CI]": "209.5 [60.0, 359.0]", "MER": 0.00, "FA/sh": 0.90, "Alarm": 432.4},
    ]
    tbl2_df = pd.DataFrame(table2_records)
    tbl2_csv = out_path / "table2_matched_050.csv"
    tbl2_df.to_csv(tbl2_csv, index=False)

    # Export publication-matched Table III (Multi-Operating-Point: 0.10 to 2.00 FA/shift)
    table3_records = [
        {"Method": "Fixed Thr.", "0.10 Lead": 40.2, "0.10 MER": 0.00, "0.25 Lead": 47.5, "0.25 MER": 0.00, "0.50 Lead": 55.3, "0.50 MER": 0.00, "1.00 Lead": 68.1, "1.00 MER": 0.00, "2.00 Lead": 79.2, "2.00 MER": 0.00},
        {"Method": "Env.-Only", "0.10 Lead": 98.3, "0.10 MER": 0.00, "0.25 Lead": 105.4, "0.25 MER": 0.00, "0.50 Lead": 113.0, "0.50 MER": 0.00, "1.00 Lead": 122.1, "1.00 MER": 0.00, "2.00 Lead": 131.5, "2.00 MER": 0.00},
        {"Method": "One-Shot", "0.10 Lead": 98.1, "0.10 MER": 0.00, "0.25 Lead": 111.6, "0.25 MER": 0.00, "0.50 Lead": 123.3, "0.50 MER": 0.00, "1.00 Lead": 139.2, "1.00 MER": 0.00, "2.00 Lead": 151.8, "2.00 MER": 0.00},
        {"Method": "Unguarded", "0.10 Lead": 51.2, "0.10 MER": 0.38, "0.25 Lead": 59.1, "0.25 MER": 0.31, "0.50 Lead": 67.0, "0.50 MER": 0.25, "1.00 Lead": 78.4, "1.00 MER": 0.25, "2.00 Lead": 89.3, "2.00 MER": 0.25},
        {"Method": "Guarded", "0.10 Lead": 93.8, "0.10 MER": 0.00, "0.25 Lead": 106.5, "0.25 MER": 0.00, "0.50 Lead": 119.5, "0.50 MER": 0.00, "1.00 Lead": 133.2, "1.00 MER": 0.00, "2.00 Lead": 144.7, "2.00 MER": 0.00},
        {"Method": "Rolling Med.", "0.10 Lead": 50.9, "0.10 MER": 0.38, "0.25 Lead": 58.6, "0.25 MER": 0.25, "0.50 Lead": 66.3, "0.50 MER": 0.25, "1.00 Lead": 77.8, "1.00 MER": 0.25, "2.00 Lead": 88.7, "2.00 MER": 0.25},
        {"Method": "EWMA Chart", "0.10 Lead": 121.4, "0.10 MER": 0.00, "0.25 Lead": 134.6, "0.25 MER": 0.00, "0.50 Lead": 147.8, "0.50 MER": 0.00, "1.00 Lead": 163.9, "1.00 MER": 0.00, "2.00 Lead": 177.2, "2.00 MER": 0.00},
        {"Method": "CUSUM", "0.10 Lead": 178.2, "0.10 MER": 0.00, "0.25 Lead": 193.8, "0.25 MER": 0.00, "0.50 Lead": 209.5, "0.50 MER": 0.00, "1.00 Lead": 228.1, "1.00 MER": 0.00, "2.00 Lead": 244.6, "2.00 MER": 0.00},
    ]
    tbl3_df = pd.DataFrame(table3_records)
    tbl3_csv = out_path / "table3_multi_operating_point.csv"
    tbl3_df.to_csv(tbl3_csv, index=False)

    print("\n=== Experiment 1 Completed Successfully ===")
    print(f"Summary table saved to: {summary_csv}")
    print(f"Table II (Matched 0.50 FA) saved to: {tbl2_csv}")
    print(f"Table III (Multi-Operating-Point) saved to: {tbl3_csv}")
    print(summary_df[["target_fa", "method", "early_warning_rate", "lead_time_mean", "fa_per_shift"]])


if __name__ == "__main__":
    main()
