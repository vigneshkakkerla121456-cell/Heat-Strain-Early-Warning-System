"""Base utilities for orchestrating experiments across disjoint seeds and matched-FA points."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from tqdm import tqdm

from hsew.simulator.workers import sample_population, VirtualWorker
from hsew.simulator.environment import create_environment_profile
from hsew.simulator.runner import simulate_shift
from hsew.methods import BaseMethod, get_method
from hsew.metrics.matched_fa import (
    calibrate_matched_thresholds,
    evaluate_method_on_dataset,
)
from hsew.metrics.alarm_metrics import (
    aggregate_evaluation_results,
    results_to_dataframe,
)
from hsew.metrics.uncertainty import bootstrap_ci, paired_comparison_wilcoxon


def generate_experiment_dataset(
    n_workers_per_seed: int,
    seeds: List[int],
    scenarios: List[str],
    sim_config: Dict[str, Any],
    contamination_mode: str = "clean",
    contamination_strength: float = 0.0,
    noise_multiplier: float = 1.0,
    dropout_rate: Optional[float] = None,
    hr_drift_rate: Optional[float] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Generate synthetic shift dataset across multiple random seeds and scenarios."""
    all_signals = []
    all_labels = []

    # Map scenario names to environment generation
    sc_map = {
        "event_ramp": "ramp",
        "event_plateau": "plateau",
        "event_intermittent": "intermittent",
        "no_event_cool": "cool",
        "no_event_heat": "heat_wave_no_event",
        "no_event_exertion": "cool",  # cool ambient with exertion confounders
    }

    # Clone config for parameter overrides
    cfg = dict(sim_config)
    if dropout_rate is not None:
        cfg = dict(cfg)
        s_noise = dict(cfg.get("sensor_noise", {}))
        s_noise["dropout_probability"] = dropout_rate
        cfg["sensor_noise"] = s_noise

    for seed in seeds:
        rng = np.random.default_rng(seed)
        workers = sample_population(n_workers=n_workers_per_seed, rng=rng, config=cfg)

        for w_idx, w in enumerate(workers):
            # Apply worker-level overrides
            if noise_multiplier != 1.0:
                w.noise_level *= noise_multiplier
            if hr_drift_rate is not None:
                w.hr_drift_rate_per_hour = hr_drift_rate

            for sc_name in scenarios:
                sim_sc = sc_map.get(sc_name, sc_name)
                shift_id = f"S{seed}_{w.worker_id}_{sc_name}"
                shift_seed = int(rng.integers(0, 2**31 - 1))

                sig_df, lbl_df = simulate_shift(
                    worker=w,
                    shift_id=shift_id,
                    scenario=sim_sc,
                    contamination_mode=contamination_mode,
                    contamination_strength=contamination_strength,
                    seed=shift_seed,
                    config=cfg,
                )
                all_signals.append(sig_df)
                all_labels.append(lbl_df)

    cohort_signals = pd.concat(all_signals, ignore_index=True)
    cohort_labels = pd.concat(all_labels, ignore_index=True)
    return cohort_signals, cohort_labels


def run_matched_fa_benchmark(
    methods: Dict[str, BaseMethod],
    tuning_signals: pd.DataFrame,
    tuning_labels: pd.DataFrame,
    test_signals: pd.DataFrame,
    test_labels: pd.DataFrame,
    target_fas: List[float],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Execute matched-FA calibration on tuning set and evaluate on test set.

    Returns
    -------
    raw_evals_df : pd.DataFrame
        Shift-by-shift detailed results.
    summary_df : pd.DataFrame
        Aggregated metrics with bootstrap 95% CIs and Wilcoxon paired tests vs Guarded.
    """
    # 1. Filter tuning set to strictly no-event shifts
    no_event_shift_ids = tuning_labels[tuning_labels["event_present"] == False]["shift_id"].unique()
    tuning_no_event_sigs = tuning_signals[tuning_signals["shift_id"].isin(no_event_shift_ids)]

    all_raw_evals = []
    summary_rows = []

    for target_fa in target_fas:
        print(f"\n--- Operating Point: Matched FA = {target_fa:.2f} / shift ---")
        method_test_results = {}

        for m_name, method in methods.items():
            # Calibrate threshold on tuning set
            calib_dict = calibrate_matched_thresholds(
                method=method,
                tuning_no_event_signals=tuning_no_event_sigs,
                target_fas=[target_fa],
            )
            matched_thresh = calib_dict[target_fa]

            # Evaluate on disjoint TEST set with frozen matched threshold
            evals = evaluate_method_on_dataset(
                method=method,
                signals_df=test_signals,
                labels_df=test_labels,
                threshold=matched_thresh,
            )
            for r in evals:
                all_raw_evals.append({
                    "target_fa": target_fa,
                    "method": m_name,
                    "matched_threshold": matched_thresh,
                    "shift_id": r.shift_id,
                    "has_event": r.has_event,
                    "detected": r.detected,
                    "early_warning": r.early_warning,
                    "warning_lead_time": r.warning_lead_time,
                    "detection_delay": r.detection_delay,
                    "is_pre_existing_alert": r.is_pre_existing_alert,
                    "missed_event": r.missed_event,
                    "false_alarms": r.false_alarm_count,
                    "alert_minutes": r.total_alert_minutes,
                })

            method_test_results[m_name] = evals
            metrics = aggregate_evaluation_results(evals)

            # Bootstrap CIs for lead time and false alarms
            early_lead_times = [r.warning_lead_time for r in evals if r.early_warning]
            lt_mean, lt_ci_l, lt_ci_u = bootstrap_ci(early_lead_times)

            all_fas = [r.false_alarm_count for r in evals]
            fa_mean, fa_ci_l, fa_ci_u = bootstrap_ci(all_fas)

            summary_rows.append({
                "target_fa": target_fa,
                "method": m_name,
                "calibrated_threshold": matched_thresh,
                "detection_rate": metrics["detection_rate"],
                "early_warning_rate": metrics["early_warning_rate"],
                "lead_time_mean": lt_mean,
                "lead_time_ci_lower": lt_ci_l,
                "lead_time_ci_upper": lt_ci_u,
                "mean_detection_delay": metrics["mean_detection_delay"],
                "missed_event_rate": metrics["missed_event_rate"],
                "fa_per_shift": metrics["fa_per_shift"],
                "fa_ci_lower": fa_ci_l,
                "fa_ci_upper": fa_ci_u,
                "alarm_burden_minutes": metrics["alarm_burden_minutes"],
                "minute_sensitivity": metrics["minute_sensitivity"],
                "minute_specificity": metrics["minute_specificity"],
            })

    raw_evals_df = pd.DataFrame(all_raw_evals)
    summary_df = pd.DataFrame(summary_rows)

    # 3. Add Wilcoxon paired tests comparing Guarded vs each comparator on lead time
    if "guarded_adaptive" in methods:
        wilcoxon_stats = []
        for target_fa in target_fas:
            g_sub = raw_evals_df[
                (raw_evals_df["target_fa"] == target_fa) &
                (raw_evals_df["method"] == "guarded_adaptive") &
                (raw_evals_df["has_event"] == True)
            ].sort_values("shift_id")

            for m_name in methods.keys():
                if m_name == "guarded_adaptive":
                    continue
                comp_sub = raw_evals_df[
                    (raw_evals_df["target_fa"] == target_fa) &
                    (raw_evals_df["method"] == m_name) &
                    (raw_evals_df["has_event"] == True)
                ].sort_values("shift_id")

                if len(g_sub) > 0 and len(comp_sub) > 0:
                    w_res = paired_comparison_wilcoxon(
                        guarded_metric=g_sub["warning_lead_time"].to_numpy(),
                        comparator_metric=comp_sub["warning_lead_time"].to_numpy(),
                    )
                    wilcoxon_stats.append({
                        "target_fa": target_fa,
                        "comparison": f"guarded_vs_{m_name}",
                        "lead_time_mean_diff": w_res["mean_diff"],
                        "p_value": w_res["p_value"],
                        "rank_biserial_r": w_res["rank_biserial_r"],
                    })

        wilcoxon_df = pd.DataFrame(wilcoxon_stats)
    else:
        wilcoxon_df = pd.DataFrame()

    return raw_evals_df, summary_df, wilcoxon_df
