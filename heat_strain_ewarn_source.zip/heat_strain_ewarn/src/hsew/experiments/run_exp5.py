"""Experiment 5: Ablation study removing components A, B, C, D, E individually and in pairs."""

import argparse
from pathlib import Path
import pandas as pd

from hsew.utils.config import load_config
from hsew.methods import GuardedAdaptiveMethod
from hsew.metrics.matched_fa import calibrate_matched_thresholds, evaluate_method_on_dataset
from hsew.metrics.alarm_metrics import aggregate_evaluation_results
from hsew.metrics.uncertainty import bootstrap_ci
from hsew.experiments.experiment_base import generate_experiment_dataset


def build_ablation_variants(meth_cfg: dict) -> dict:
    sub = meth_cfg.get("guarded_adaptive", {})
    common = meth_cfg.get("common", {})
    k = common.get("persistence_k", 3)
    hyst = common.get("hysteresis_ratio", 0.8)
    cooldown = common.get("cooldown_minutes", 10)

    base_kwargs = dict(
        calibration_minutes=sub.get("calibration_minutes", 30),
        ewma_alpha=sub.get("ewma_alpha", 0.02),
        persistence_k=k,
        hysteresis_ratio=hyst,
        cooldown_minutes=cooldown,
    )

    variants = {
        "Full Guarded A-F": GuardedAdaptiveMethod(use_cross_shift_memory=True, **base_kwargs),
        "Without A (Quality)": GuardedAdaptiveMethod(use_quality_score=False, use_cross_shift_memory=True, **base_kwargs),
        "Without B (Gate)": GuardedAdaptiveMethod(use_update_gate=False, use_cross_shift_memory=True, **base_kwargs),
        "Without C (Freeze)": GuardedAdaptiveMethod(use_freeze_on_warning=False, use_cross_shift_memory=True, **base_kwargs),
        "Without D (Rate Limiter)": GuardedAdaptiveMethod(use_rate_limiter=False, use_cross_shift_memory=True, **base_kwargs),
        "Without E (Uncertainty)": GuardedAdaptiveMethod(use_uncertainty_scale=False, use_cross_shift_memory=True, **base_kwargs),
        "Without F (Memory)": GuardedAdaptiveMethod(use_cross_shift_memory=False, **base_kwargs),
        "Without B & C (Gate+Freeze)": GuardedAdaptiveMethod(use_update_gate=False, use_freeze_on_warning=False, use_cross_shift_memory=True, **base_kwargs),
        "Unguarded (All Off)": GuardedAdaptiveMethod(
            use_quality_score=False,
            use_update_gate=False,
            use_freeze_on_warning=False,
            use_rate_limiter=False,
            use_uncertainty_scale=False,
            use_cross_shift_memory=False,
            **base_kwargs
        ),
    }
    return variants


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Experiment 5: Ablation Study.")
    parser.add_argument("--config", type=str, default="configs/experiments.yaml")
    parser.add_argument("--sim_config", type=str, default="configs/simulator.yaml")
    parser.add_argument("--methods_config", type=str, default="configs/methods.yaml")
    parser.add_argument("--out_dir", type=str, default="results/exp5_ablation")
    parser.add_argument("--fast", action="store_true", help="Run fast test.")
    args = parser.parse_args()

    exp_cfg = load_config(args.config)
    sim_cfg = load_config(args.sim_config)
    meth_cfg = load_config(args.methods_config)

    seeds_cfg = exp_cfg.get("seeds", {})
    tuning_seeds = seeds_cfg.get("tuning_seeds", [101, 102])[:2] if args.fast else seeds_cfg.get("tuning_seeds", [101, 102, 103])
    test_seeds = seeds_cfg.get("test_seeds", [201, 202])[:2] if args.fast else seeds_cfg.get("test_seeds", [201, 202, 203, 204, 205])

    scenarios = ["event_ramp", "no_event_cool"]
    n_workers = 2 if args.fast else 5
    target_fa = 0.50

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    variants = build_ablation_variants(meth_cfg)

    # Tuning set with slight post-exertion contamination to test quality handling
    tune_sigs, tune_lbls = generate_experiment_dataset(
        n_workers_per_seed=n_workers,
        seeds=tuning_seeds,
        scenarios=["no_event_cool"],
        sim_config=sim_cfg,
    )
    no_ev_ids = tune_lbls[tune_lbls["event_present"] == False]["shift_id"].unique()
    clean_no_ev_sigs = tune_sigs[tune_sigs["shift_id"].isin(no_ev_ids)]

    # Test set
    test_sigs, test_lbls = generate_experiment_dataset(
        n_workers_per_seed=n_workers,
        seeds=test_seeds,
        scenarios=scenarios,
        sim_config=sim_cfg,
        contamination_mode="post_exertion",
        contamination_strength=0.5,
    )

    records = []
    print("Evaluating ablation variants under calibrated target FA = 0.50...")
    for var_name, var_method in variants.items():
        calib_dict = calibrate_matched_thresholds(var_method, clean_no_ev_sigs, target_fas=[target_fa])
        matched_thresh = calib_dict[target_fa]

        evals = evaluate_method_on_dataset(var_method, test_sigs, test_lbls, threshold=matched_thresh)
        metrics = aggregate_evaluation_results(evals)

        early_lts = [r.warning_lead_time for r in evals if r.early_warning]
        lt_mean, lt_ci_l, lt_ci_u = bootstrap_ci(early_lts)

        records.append({
            "variant": var_name,
            "calibrated_threshold": matched_thresh,
            "detection_rate": metrics["detection_rate"],
            "early_warning_rate": metrics["early_warning_rate"],
            "lead_time_mean": lt_mean,
            "lead_time_ci_lower": lt_ci_l,
            "lead_time_ci_upper": lt_ci_u,
            "fa_per_shift": metrics["fa_per_shift"],
            "missed_event_rate": metrics["missed_event_rate"],
        })

    summary_df = pd.DataFrame(records)
    summary_csv = out_path / "summary.csv"
    summary_df.to_csv(summary_csv, index=False)

    print(f"\nExperiment 5 complete. Saved to: {summary_csv}")
    print(summary_df[["variant", "early_warning_rate", "lead_time_mean", "fa_per_shift"]])


if __name__ == "__main__":
    main()
