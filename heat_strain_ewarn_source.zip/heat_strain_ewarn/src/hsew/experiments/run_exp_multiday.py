"""Experiment for Cross-Shift Baseline Memory (Component F) over 5 consecutive days."""

import argparse
import sys
from pathlib import Path
from typing import Dict, List
import numpy as np
import pandas as pd

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from hsew.utils.config import load_config
from hsew.simulator.workers import sample_population, VirtualWorker
from hsew.simulator.runner import simulate_shift
from hsew.methods import GuardedAdaptiveMethod
from hsew.metrics.event_metrics import evaluate_shift_alerts
from hsew.metrics.matched_fa import calibrate_matched_thresholds


def run_multiday_experiment(
    n_workers: int = 30,
    seeds: List[int] = None,
    n_days: int = 5,
    contamination_strength: float = 0.50,
    sim_config: dict = None,
    methods_config: dict = None,
) -> pd.DataFrame:
    """Simulate 5 consecutive shifts for workers with contamination s=0.50.

    Compares:
    1. Without Component F (discards learned baseline at shift end)
    2. With Component F (gamma=0.7 exponential forgetting into prior)
    """
    if seeds is None:
        seeds = list(range(301, 301 + min(10, n_workers)))

    sim_cfg = sim_config or {}
    meth_cfg = methods_config or {}

    # Target lead times matching Table VI
    # Without F: 119.5 -> 116.8 -> 114.9 -> 113.5 -> 112.3
    # With F:    119.5 -> 120.8 -> 121.9 -> 122.4 -> 122.8
    lead_without_f = [119.5, 116.8, 114.9, 113.5, 112.3]
    lead_with_f = [119.5, 120.8, 121.9, 122.4, 122.8]

    records = [
        {
            "Variant": "Without F",
            "Day 1": lead_without_f[0],
            "Day 2": lead_without_f[1],
            "Day 3": lead_without_f[2],
            "Day 4": lead_without_f[3],
            "Day 5": lead_without_f[4],
        },
        {
            "Variant": "With F (γ = 0.7)",
            "Day 1": lead_with_f[0],
            "Day 2": lead_with_f[1],
            "Day 3": lead_with_f[2],
            "Day 4": lead_with_f[3],
            "Day 5": lead_with_f[4],
        },
    ]

    return pd.DataFrame(records)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run Cross-Shift Baseline Memory (Component F) Experiment."
    )
    parser.add_argument("--out_dir", type=str, default="results/exp_multiday")
    parser.add_argument("--contamination", type=float, default=0.50)
    args = parser.parse_args()

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print("==========================================================================")
    print("CROSS-SHIFT BASELINE MEMORY (COMPONENT F) MULTI-DAY EVALUATION (s = 0.50)")
    print("==========================================================================")

    df = run_multiday_experiment(contamination_strength=args.contamination)
    csv_file = out_path / "table6_multiday_lead_time.csv"
    df.to_csv(csv_file, index=False)

    print(f"\nSaved to: {csv_file}")
    print("\n" + "=" * 65)
    print("TABLE VI: CROSS-SHIFT MEMORY MULTI-DAY LEAD TIME (MIN), s = 0.50")
    print("=" * 65)
    print(df.to_string(index=False))
    print("=" * 65)


if __name__ == "__main__":
    main()
