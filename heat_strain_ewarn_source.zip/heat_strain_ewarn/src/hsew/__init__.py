"""HSEW: Drift-Aware Personalized Heat-Strain Early Warning."""

__version__ = "0.1.0"
