"""Event-level evaluation metrics: lead time, detection delay, false alarms, and missed events."""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import numpy as np


@dataclass
class ShiftEvaluationResult:
    """Evaluation result for a single shift."""
    shift_id: str
    has_event: bool
    detected: bool                    # True if alerted within valid window or post-onset
    early_warning: bool               # True if alerted before onset in valid window
    warning_lead_time: float          # minutes before onset (> 0), or 0.0 if not early
    detection_delay: Optional[float]  # minutes after onset (>= 0) for NEW alerts only; None if pre-existing or missed
    is_pre_existing_alert: bool       # True if alert was already active prior to or at onset
    missed_event: bool                # True if shift had event but no alert during event
    false_alarm_count: int            # count of distinct false alert episodes
    total_alert_minutes: int          # total minutes where alert was active
    event_active_minutes: int         # total ground truth event minutes
    tp_minutes: int
    fp_minutes: int
    tn_minutes: int
    fn_minutes: int


def count_alert_episodes(alert_flag: np.ndarray, start_idx: int = 0) -> List[Tuple[int, int]]:
    """Identify contiguous alert episodes as [start_minute, end_minute] inclusive."""
    n = len(alert_flag)
    episodes = []
    in_episode = False
    ep_start = 0

    for t in range(start_idx, n):
        if alert_flag[t] == 1 and not in_episode:
            in_episode = True
            ep_start = t
        elif alert_flag[t] == 0 and in_episode:
            in_episode = False
            episodes.append((ep_start, t - 1))

    if in_episode:
        episodes.append((ep_start, n - 1))

    return episodes


def evaluate_shift_alerts(
    alert_flag: np.ndarray,
    event_active: np.ndarray,
    event_onset_minute: int,
    shift_id: str = "S001",
    calibration_minutes: int = 30,
    max_lead_window: int = 120,
) -> ShiftEvaluationResult:
    """Evaluate alert performance for a single shift according to research protocol.

    Rule 6 compliance: Distinguishes pre-existing alert (active before onset)
    from a NEW alert raised after onset when computing detection delay.
    """
    n = len(alert_flag)
    has_event = (event_onset_minute >= 0)
    post_cal_slice = slice(calibration_minutes, n)

    # All alert episodes occurring post-calibration
    all_episodes = count_alert_episodes(alert_flag, start_idx=calibration_minutes)

    # Per-minute contingency stats (post-calibration)
    al_post = alert_flag[post_cal_slice]
    ev_post = event_active[post_cal_slice]

    tp_m = int(np.sum((al_post == 1) & (ev_post == 1)))
    fp_m = int(np.sum((al_post == 1) & (ev_post == 0)))
    tn_m = int(np.sum((al_post == 0) & (ev_post == 0)))
    fn_m = int(np.sum((al_post == 0) & (ev_post == 1)))
    tot_alert_m = int(np.sum(al_post == 1))
    ev_active_m = int(np.sum(ev_post == 1))

    if not has_event:
        # No-event shift: every episode post-calibration is a false alarm
        fa_count = len(all_episodes)
        return ShiftEvaluationResult(
            shift_id=shift_id,
            has_event=False,
            detected=False,
            early_warning=False,
            warning_lead_time=0.0,
            detection_delay=None,
            is_pre_existing_alert=False,
            missed_event=False,
            false_alarm_count=fa_count,
            total_alert_minutes=tot_alert_m,
            event_active_minutes=0,
            tp_minutes=tp_m,
            fp_minutes=fp_m,
            tn_minutes=tn_m,
            fn_minutes=fn_m,
        )

    # Event is present
    t_onset = event_onset_minute
    valid_warning_start = max(calibration_minutes, t_onset - max_lead_window)

    early_warning = False
    warning_lead_time = 0.0
    detection_delay: Optional[float] = None
    is_pre_existing = False
    detected = False
    false_episodes = []

    # Check alert state at onset minute and immediately prior
    alert_at_onset = (alert_flag[t_onset] == 1)
    alert_before_onset = (t_onset > 0 and alert_flag[t_onset - 1] == 1)

    # Track which episode represents the detection/warning
    matched_event_episode = None

    for ep_start, ep_end in all_episodes:
        # Case 1: Episode overlaps or starts in valid early warning window before onset
        if ep_start < t_onset and ep_end >= valid_warning_start:
            if not detected:
                detected = True
                early_warning = True
                warning_lead_time = float(t_onset - ep_start)
                matched_event_episode = (ep_start, ep_end)
                if alert_before_onset or alert_at_onset:
                    is_pre_existing = True
            elif (ep_start, ep_end) != matched_event_episode:
                false_episodes.append((ep_start, ep_end))

        # Case 2: Episode starts AT or AFTER onset, during the event
        elif ep_start >= t_onset:
            # Check if this episode overlaps active event window
            if any(event_active[ep_start:ep_end + 1]):
                if not detected:
                    detected = True
                    # This is a NEW alert raised after onset! (Rule 6)
                    is_pre_existing = False
                    detection_delay = float(ep_start - t_onset)
                    matched_event_episode = (ep_start, ep_end)
                elif (ep_start, ep_end) != matched_event_episode:
                    false_episodes.append((ep_start, ep_end))
            else:
                false_episodes.append((ep_start, ep_end))

        # Case 3: Episode terminated before valid warning window
        else:
            false_episodes.append((ep_start, ep_end))

    missed_event = not detected

    return ShiftEvaluationResult(
        shift_id=shift_id,
        has_event=True,
        detected=detected,
        early_warning=early_warning,
        warning_lead_time=warning_lead_time,
        detection_delay=detection_delay,
        is_pre_existing_alert=is_pre_existing,
        missed_event=missed_event,
        false_alarm_count=len(false_episodes),
        total_alert_minutes=tot_alert_m,
        event_active_minutes=ev_active_m,
        tp_minutes=tp_m,
        fp_minutes=fp_m,
        tn_minutes=tn_m,
        fn_minutes=fn_m,
    )
