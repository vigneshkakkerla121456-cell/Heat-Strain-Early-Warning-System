"""Matched False-Alarm calibration procedure and lead-time vs FA trade-off curve generator."""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

from hsew.methods.base import BaseMethod
from hsew.metrics.event_metrics import evaluate_shift_alerts, ShiftEvaluationResult
from hsew.metrics.alarm_metrics import aggregate_evaluation_results


def evaluate_method_on_dataset(
    method: BaseMethod,
    signals_df: pd.DataFrame,
    labels_df: pd.DataFrame,
    threshold: Optional[float] = None,
    calibration_minutes: int = 30,
) -> List[ShiftEvaluationResult]:
    """Run an early warning method across all shifts in a signals table and evaluate against hidden labels."""
    shift_ids = signals_df["shift_id"].unique()
    results = []

    # Map labels by shift_id
    labels_by_shift = dict(tuple(labels_df.groupby("shift_id")))

    for s_id in shift_ids:
        s_sig = signals_df[signals_df["shift_id"] == s_id].sort_values("minute")
        s_lbl = labels_by_shift.get(s_id)

        if s_lbl is None:
            continue

        s_lbl = s_lbl.sort_values("minute")
        event_active = s_lbl["event_active"].to_numpy(dtype=int)
        event_onset = int(s_lbl["event_onset_minute"].iloc[0])

        res = method.run(s_sig, threshold=threshold)

        shift_eval = evaluate_shift_alerts(
            alert_flag=res.alert_flag,
            event_active=event_active,
            event_onset_minute=event_onset,
            shift_id=s_id,
            calibration_minutes=calibration_minutes,
        )
        results.append(shift_eval)

    return results


def sweep_thresholds_on_no_event_shifts(
    method: BaseMethod,
    no_event_signals_df: pd.DataFrame,
    threshold_grid: Optional[np.ndarray] = None,
    calibration_minutes: int = 30,
) -> pd.DataFrame:
    """Sweep decision thresholds on a NO-EVENT tuning dataset to measure empirical false-alarm rates."""
    if threshold_grid is None:
        threshold_grid = np.linspace(0.10, 1.20, 45)

    shift_ids = no_event_signals_df["shift_id"].unique()
    n_shifts = len(shift_ids)
    if n_shifts == 0:
        raise ValueError("no_event_signals_df contains 0 shifts.")

    # Pre-run methods to extract continuous risk score for each shift (efficiency optimization)
    risk_scores = {}
    for s_id in shift_ids:
        s_sig = no_event_signals_df[no_event_signals_df["shift_id"] == s_id].sort_values("minute")
        res = method.run(s_sig)
        risk_scores[s_id] = res.risk_score

    sweep_records = []
    dummy_labels = np.zeros(len(next(iter(risk_scores.values()))), dtype=int)

    for thresh in threshold_grid:
        total_fa = 0
        total_alert_mins = 0

        for s_id, r_score in risk_scores.items():
            # Re-run alert logic for this threshold
            from hsew.methods.base import apply_alert_logic
            alerts = apply_alert_logic(
                risk_score=r_score,
                threshold=thresh,
                persistence_k=method.persistence_k,
                hysteresis_ratio=method.hysteresis_ratio,
            )
            eval_res = evaluate_shift_alerts(
                alert_flag=alerts,
                event_active=dummy_labels,
                event_onset_minute=-1,
                shift_id=s_id,
                calibration_minutes=calibration_minutes,
            )
            total_fa += eval_res.false_alarm_count
            total_alert_mins += eval_res.total_alert_minutes

        sweep_records.append({
            "threshold": thresh,
            "fa_per_shift": total_fa / n_shifts,
            "alert_minutes_per_shift": total_alert_mins / n_shifts,
        })

    return pd.DataFrame(sweep_records)


def find_matched_threshold(
    sweep_df: pd.DataFrame,
    target_fa: float,
) -> float:
    """Interpolate the calibrated decision threshold that matches target_fa."""
    df_sorted = sweep_df.sort_values("threshold")
    thresholds = df_sorted["threshold"].to_numpy()
    fas = df_sorted["fa_per_shift"].to_numpy()

    # Monotonically enforce non-increasing FA with increasing threshold
    fas_clean = np.maximum.accumulate(fas[::-1])[::-1]

    if target_fa >= fas_clean[0]:
        return float(thresholds[0])
    if target_fa <= fas_clean[-1]:
        return float(thresholds[-1])

    # Linear interpolation
    # Note: fas_clean is descending with respect to thresholds
    thresh_interp = float(np.interp(target_fa, fas_clean[::-1], thresholds[::-1]))
    return thresh_interp


def calibrate_matched_thresholds(
    method: BaseMethod,
    tuning_no_event_signals: pd.DataFrame,
    target_fas: Optional[List[float]] = None,
) -> Dict[float, float]:
    """Calibrate decision thresholds on tuning set to achieve target false-alarm rates."""
    targets = target_fas or [0.25, 0.50, 1.00]
    sweep_df = sweep_thresholds_on_no_event_shifts(method, tuning_no_event_signals)

    matched_dict = {}
    for t_fa in targets:
        matched_dict[t_fa] = find_matched_threshold(sweep_df, t_fa)

    return matched_dict
