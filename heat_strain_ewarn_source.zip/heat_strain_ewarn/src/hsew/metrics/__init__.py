"""Metrics, evaluation harness, matched-FA calibration, and significance testing."""

from hsew.metrics.event_metrics import (
    ShiftEvaluationResult,
    count_alert_episodes,
    evaluate_shift_alerts,
)
from hsew.metrics.alarm_metrics import (
    aggregate_evaluation_results,
    results_to_dataframe,
)
from hsew.metrics.matched_fa import (
    evaluate_method_on_dataset,
    sweep_thresholds_on_no_event_shifts,
    find_matched_threshold,
    calibrate_matched_thresholds,
)
from hsew.metrics.uncertainty import (
    bootstrap_ci,
    paired_comparison_wilcoxon,
)

__all__ = [
    "ShiftEvaluationResult",
    "count_alert_episodes",
    "evaluate_shift_alerts",
    "aggregate_evaluation_results",
    "results_to_dataframe",
    "evaluate_method_on_dataset",
    "sweep_thresholds_on_no_event_shifts",
    "find_matched_threshold",
    "calibrate_matched_thresholds",
    "bootstrap_ci",
    "paired_comparison_wilcoxon",
]
