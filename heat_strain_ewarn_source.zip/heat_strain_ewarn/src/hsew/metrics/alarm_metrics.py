"""Cohort-level summary metrics aggregation."""

from typing import Dict, List, Optional
import numpy as np
import pandas as pd

from hsew.metrics.event_metrics import ShiftEvaluationResult


def aggregate_evaluation_results(
    results: List[ShiftEvaluationResult],
) -> Dict[str, float]:
    """Aggregate a collection of ShiftEvaluationResult objects into a metric summary dictionary."""
    if not results:
        return {}

    n_total_shifts = len(results)
    event_shifts = [r for r in results if r.has_event]
    no_event_shifts = [r for r in results if not r.has_event]
    n_events = len(event_shifts)

    # Event-level detection metrics
    if n_events > 0:
        detected_shifts = [r for r in event_shifts if r.detected]
        detection_rate = len(detected_shifts) / n_events
        missed_event_rate = sum(1 for r in event_shifts if r.missed_event) / n_events

        early_shifts = [r for r in event_shifts if r.early_warning]
        early_warning_rate = len(early_shifts) / n_events
        mean_lead_time = (
            float(np.mean([r.warning_lead_time for r in early_shifts]))
            if early_shifts else 0.0
        )

        # Detection delay calculated strictly from NEW alerts after onset (Rule 6)
        new_alert_delays = [
            r.detection_delay for r in event_shifts
            if r.detection_delay is not None
        ]
        mean_detection_delay = (
            float(np.mean(new_alert_delays))
            if new_alert_delays else np.nan
        )
        pre_existing_count = sum(1 for r in event_shifts if r.is_pre_existing_alert)
        pre_existing_rate = pre_existing_count / n_events
    else:
        detection_rate = np.nan
        missed_event_rate = np.nan
        early_warning_rate = np.nan
        mean_lead_time = np.nan
        mean_detection_delay = np.nan
        pre_existing_rate = np.nan

    # False alarm metrics
    fa_total_episodes = sum(r.false_alarm_count for r in results)
    fa_per_shift = fa_total_episodes / n_total_shifts

    if no_event_shifts:
        fa_no_event_episodes = sum(r.false_alarm_count for r in no_event_shifts)
        fa_per_no_event_shift = fa_no_event_episodes / len(no_event_shifts)
    else:
        fa_per_no_event_shift = np.nan

    # Alarm burden (alert minutes per shift)
    alarm_burden_mins = float(np.mean([r.total_alert_minutes for r in results]))

    # Per-minute sample sensitivity and specificity
    tot_tp = sum(r.tp_minutes for r in results)
    tot_fp = sum(r.fp_minutes for r in results)
    tot_tn = sum(r.tn_minutes for r in results)
    tot_fn = sum(r.fn_minutes for r in results)

    minute_sensitivity = tot_tp / (tot_tp + tot_fn) if (tot_tp + tot_fn) > 0 else np.nan
    minute_specificity = tot_tn / (tot_tn + tot_fp) if (tot_tn + tot_fp) > 0 else np.nan

    return {
        "n_total_shifts": n_total_shifts,
        "n_events": n_events,
        "detection_rate": detection_rate,
        "early_warning_rate": early_warning_rate,
        "mean_lead_time": mean_lead_time,
        "mean_detection_delay": mean_detection_delay,
        "pre_existing_rate": pre_existing_rate,
        "missed_event_rate": missed_event_rate,
        "fa_per_shift": fa_per_shift,
        "fa_per_no_event_shift": fa_per_no_event_shift,
        "alarm_burden_minutes": alarm_burden_mins,
        "minute_sensitivity": minute_sensitivity,
        "minute_specificity": minute_specificity,
    }


def results_to_dataframe(results: List[ShiftEvaluationResult]) -> pd.DataFrame:
    """Convert list of shift evaluation results to a tabular DataFrame."""
    records = []
    for r in results:
        records.append({
            "shift_id": r.shift_id,
            "has_event": r.has_event,
            "detected": r.detected,
            "early_warning": r.early_warning,
            "warning_lead_time": r.warning_lead_time,
            "detection_delay": r.detection_delay,
            "is_pre_existing_alert": r.is_pre_existing_alert,
            "missed_event": r.missed_event,
            "false_alarms": r.false_alarm_count,
            "alert_minutes": r.total_alert_minutes,
            "event_minutes": r.event_active_minutes,
            "tp_minutes": r.tp_minutes,
            "fp_minutes": r.fp_minutes,
            "tn_minutes": r.tn_minutes,
            "fn_minutes": r.fn_minutes,
        })
    return pd.DataFrame(records)
