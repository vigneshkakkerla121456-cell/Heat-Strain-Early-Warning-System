"""Bootstrap confidence intervals and Wilcoxon signed-rank paired comparison tests."""

from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
from scipy import stats


def bootstrap_ci(
    data: Union[np.ndarray, List[float]],
    n_boot: int = 1000,
    ci: float = 0.95,
    seed: int = 42,
) -> Tuple[float, float, float]:
    """Calculate mean and non-parametric bootstrap confidence interval (percentile method).

    Parameters
    ----------
    data : array-like
        Sample values (e.g., lead times or FA rates across seeds/workers).
    n_boot : int
        Number of bootstrap resamples (default 1000).
    ci : float
        Confidence level (default 0.95 for 95% CI).
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    mean : float
    ci_lower : float
    ci_upper : float
    """
    arr = np.asarray(data, dtype=float)
    arr = arr[~np.isnan(arr)]

    if len(arr) == 0:
        return np.nan, np.nan, np.nan
    if len(arr) == 1:
        val = float(arr[0])
        return val, val, val

    rng = np.random.default_rng(seed)
    n = len(arr)
    boot_means = np.empty(n_boot, dtype=float)

    for i in range(n_boot):
        sample = rng.choice(arr, size=n, replace=True)
        boot_means[i] = np.mean(sample)

    alpha = (1.0 - ci) / 2.0
    lower = float(np.percentile(boot_means, 100.0 * alpha))
    upper = float(np.percentile(boot_means, 100.0 * (1.0 - alpha)))
    mean_val = float(np.mean(arr))

    return mean_val, lower, upper


def paired_comparison_wilcoxon(
    guarded_metric: Union[np.ndarray, List[float]],
    comparator_metric: Union[np.ndarray, List[float]],
    alternative: str = "two-sided",
) -> Dict[str, float]:
    """Perform Wilcoxon signed-rank paired test between Guarded and comparator with effect size.

    Computes:
    - statistic: Wilcoxon test statistic
    - p_value: Two-sided or one-sided p-value
    - mean_diff: mean(guarded - comparator)
    - median_diff: median(guarded - comparator)
    - effect_size: Matched-pairs rank-biserial correlation r in [-1, 1]
    """
    g = np.asarray(guarded_metric, dtype=float)
    c = np.asarray(comparator_metric, dtype=float)

    valid_mask = (~np.isnan(g)) & (~np.isnan(c))
    g_valid = g[valid_mask]
    c_valid = c[valid_mask]

    diffs = g_valid - c_valid
    non_zero_diffs = diffs[diffs != 0]
    n = len(non_zero_diffs)

    if n < 3:
        return {
            "n_pairs": len(diffs),
            "statistic": 0.0,
            "p_value": 1.0,
            "mean_diff": float(np.mean(diffs)) if len(diffs) > 0 else 0.0,
            "median_diff": float(np.median(diffs)) if len(diffs) > 0 else 0.0,
            "rank_biserial_r": 0.0,
        }

    # Rank the absolute differences to compute Kerby rank-biserial correlation: r = (W+ - W-) / (W+ + W-)
    abs_d = np.abs(non_zero_diffs)
    ranks = stats.rankdata(abs_d)
    w_pos = np.sum(ranks[non_zero_diffs > 0])
    w_neg = np.sum(ranks[non_zero_diffs < 0])
    total_ranks = w_pos + w_neg
    r_biserial = float((w_pos - w_neg) / total_ranks) if total_ranks > 0 else 0.0

    try:
        res = stats.wilcoxon(g_valid, c_valid, alternative=alternative)
        stat = float(res.statistic)
        pval = float(res.pvalue)
    except Exception:
        stat = 0.0
        pval = 1.0

    return {
        "n_pairs": len(diffs),
        "statistic": stat,
        "p_value": pval,
        "mean_diff": float(np.mean(diffs)),
        "median_diff": float(np.median(diffs)),
        "rank_biserial_r": r_biserial,
    }
