"""Edge deployment profiling subpackage."""

from hsew.edge.profile_edge import profile_edge_execution

__all__ = ["profile_edge_execution"]

