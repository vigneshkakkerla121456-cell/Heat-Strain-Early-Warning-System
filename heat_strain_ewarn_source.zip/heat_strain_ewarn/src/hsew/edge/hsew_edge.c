/**
 * @file hsew_edge.c
 * @brief Guarded Adaptive Early Warning Framework - C Implementation
 */

#include "hsew_edge.h"
#include <math.h>
#include <string.h>

static inline float clipf(float val, float min_val, float max_val) {
    if (val < min_val) return min_val;
    if (val > max_val) return max_val;
    return val;
}

void hsew_init(hsew_state_t *state, const hsew_config_t *config, float initial_lt_hr) {
    memset(state, 0, sizeof(hsew_state_t));
    state->long_term_hr = (initial_lt_hr > 0.0f) ? initial_lt_hr : config->prior_hr;
    state->curr_hr_base = state->long_term_hr;
    state->curr_temp_base = config->prior_temp;
    state->quality_score = 1.0f;
    state->hr_scale = 10.0f;
    state->temp_scale = 0.8f;
    state->sample_index = 0;
}

void hsew_process_sample(
    hsew_state_t *state,
    const hsew_config_t *config,
    const hsew_sample_t *sample,
    hsew_output_t *output
) {
    float hr_t = sample->hr;
    float temp_t = sample->skin_temp;
    float heat_t = clipf(sample->heat_load_observed, 0.0f, 1.0f);

    /* 1. Component E: Uncertainty-Aware Risk Scoring (eq 7) */
    float z_hr = clipf((hr_t - state->curr_hr_base) / state->hr_scale, 0.0f, 2.0f);
    float z_temp = clipf((temp_t - state->curr_temp_base) / state->temp_scale, 0.0f, 2.0f);

    float risk_t;
    if (sample->spo2 > 0.0f && sample->spo2 <= 100.0f) {
        /* Component I: SpO2 Fusion (eq 15) */
        float r_spo2 = 0.10f * clipf((94.0f - sample->spo2) / 4.0f, 0.0f, 2.0f);
        risk_t = 0.90f * (config->w_hr * z_hr + config->w_temp * z_temp) +
                 config->w_heat * heat_t + r_spo2;
    } else {
        risk_t = config->w_hr * z_hr + config->w_temp * z_temp + config->w_heat * heat_t;
    }

    /* 2. Alert State Machine */
    float clear_thresh = config->threshold * config->hysteresis_ratio;
    if (!state->is_alerting) {
        if (risk_t >= config->threshold) {
            state->consecutive_high_count++;
            if (state->consecutive_high_count >= config->persistence_k) {
                state->is_alerting = true;
                state->consecutive_high_count = 0;
                state->cooldown_counter = config->cooldown_minutes;
            }
        } else {
            state->consecutive_high_count = 0;
        }
    } else {
        if (risk_t < clear_thresh) {
            state->is_alerting = false;
            state->consecutive_high_count = 0;
            state->cooldown_counter = config->cooldown_minutes;
        } else {
            state->cooldown_counter = config->cooldown_minutes;
        }
    }

    if (!state->is_alerting && state->cooldown_counter > 0) {
        state->cooldown_counter--;
    }

    output->risk_score = risk_t;
    output->alert_flag = state->is_alerting;
    output->hr_baseline = state->curr_hr_base;
    output->temp_baseline = state->curr_temp_base;

    /* Update recent HR buffer */
    state->recent_hr_buf[state->recent_hr_head] = hr_t;
    state->recent_hr_head = (state->recent_hr_head + 1) % HSEW_TREND_WINDOW;

    /* 3. Calibration window & update gating */
    state->sample_index++;
    if (state->sample_index <= HSEW_CALIBRATION_MINUTES) {
        output->update_allowed = false;
        return;
    }

    bool can_update = (sample->quality_flag == 1);

    /* Component C: Alert-triggered baseline freezing (eq 9) */
    if (state->is_alerting || state->cooldown_counter > 0) {
        can_update = false;
    }

    /* Component B: Multi-condition update gate (eq 8) */
    if (can_update) {
        if (risk_t >= config->gate_max_risk) {
            can_update = false;
        } else if (heat_t >= config->gate_max_heat_load) {
            can_update = false;
        } else {
            /* 5-minute trend check */
            uint8_t oldest_idx = state->recent_hr_head; /* oldest in ring */
            float hr_old = state->recent_hr_buf[oldest_idx];
            if ((hr_t - hr_old) > 6.0f) {
                can_update = false;
            }
        }
    }

    output->update_allowed = can_update;

    /* Track final 60-minute window for Component F */
    if (can_update) {
        state->final_gate_passes++;
    }
    state->final_window_count++;

    /* 4. Component D: Rate-Limiting Drift Cap (eq 10) */
    if (can_update) {
        float prop_hr = (1.0f - config->ewma_alpha) * state->curr_hr_base + config->ewma_alpha * hr_t;
        float prop_temp = (1.0f - config->ewma_alpha) * state->curr_temp_base + config->ewma_alpha * temp_t;

        float hr_step = clipf(prop_hr - state->curr_hr_base,
                              -config->drift_cap_hr_per_min,
                              config->drift_cap_hr_per_min);
        float temp_step = clipf(prop_temp - state->curr_temp_base,
                                -config->drift_cap_temp_per_min,
                                config->drift_cap_temp_per_min);

        state->curr_hr_base += hr_step;
        state->curr_temp_base += temp_step;
    }
}

void hsew_finish_shift(
    hsew_state_t *state,
    const hsew_config_t *config
) {
    /* Component F: Cross-shift baseline memory update (eq 11) */
    if (state->final_window_count > 0) {
        float pass_ratio = (float)state->final_gate_passes / (float)state->final_window_count;
        if (pass_ratio >= 0.60f) {
            state->long_term_hr = config->memory_gamma * state->long_term_hr +
                                  (1.0f - config->memory_gamma) * state->curr_hr_base;
        }
    }
}

