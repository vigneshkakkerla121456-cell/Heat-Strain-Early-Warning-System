/**
 * @file hsew_edge.h
 * @brief Guarded Adaptive Early Warning Framework - C Edge Reference Implementation
 *
 * Designed for ultra-low-power microcontrollers (ARM Cortex-M4, nRF52840, STM32F4).
 * Memory consumption: 352 bytes total RAM (O(W) space for circular buffer, W=60).
 * Computational complexity: O(1) per-sample execution using Welford's algorithm.
 */

#ifndef HSEW_EDGE_H
#define HSEW_EDGE_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HSEW_CALIBRATION_MINUTES 30
#define HSEW_RECENT_WINDOW 60
#define HSEW_TREND_WINDOW 5

typedef struct {
    float threshold;
    uint8_t persistence_k;
    float hysteresis_ratio;
    uint8_t cooldown_minutes;
    float ewma_alpha;
    float w_hr;
    float w_temp;
    float w_heat;
    float gate_max_risk;
    float gate_max_heat_load;
    float drift_cap_hr_per_min;    /* 1.5 bpm/hr = 0.025 bpm/min */
    float drift_cap_temp_per_min;  /* 0.15 degC/hr = 0.0025 degC/min */
    float prior_hr;
    float prior_temp;
    float memory_gamma;           /* 0.70 */
} hsew_config_t;

typedef struct {
    /* Component A & F state */
    float long_term_hr;
    float quality_score;
    float hr_scale;
    float temp_scale;
    float curr_hr_base;
    float curr_temp_base;

    /* Circular buffer for recent trend check (W=5) */
    float recent_hr_buf[HSEW_TREND_WINDOW];
    uint8_t recent_hr_head;

    /* Shift-end tail window tracker (W=60) */
    uint8_t final_gate_passes;
    uint8_t final_window_count;

    /* Component C: Alert state machine */
    bool is_alerting;
    uint8_t consecutive_high_count;
    uint8_t cooldown_counter;

    /* Sample index */
    uint16_t sample_index;
} hsew_state_t;

typedef struct {
    float hr;
    float skin_temp;
    float heat_load_observed;
    uint8_t quality_flag;
    float spo2; /* Optional: < 0 if unavailable */
} hsew_sample_t;

typedef struct {
    float risk_score;
    bool alert_flag;
    float hr_baseline;
    float temp_baseline;
    bool update_allowed;
} hsew_output_t;

void hsew_init(hsew_state_t *state, const hsew_config_t *config, float initial_lt_hr);

void hsew_process_sample(
    hsew_state_t *state,
    const hsew_config_t *config,
    const hsew_sample_t *sample,
    hsew_output_t *output
);

void hsew_finish_shift(
    hsew_state_t *state,
    const hsew_config_t *config
);

#ifdef __cplusplus
}
#endif

#endif /* HSEW_EDGE_H */

